import {
  readFile,
  readdir,
  stat,
  access,
} from "node:fs/promises";
import { join, basename, resolve, relative } from "node:path";
import { constants } from "node:fs";
import type {
  DiscoveredProject,
  PackageManager,
} from "@workspace/kilobuild-types";

interface PackageJson {
  name?: string;
  version?: string;
  main?: string;
  scripts?: Record<string, string>;
  dependencies?: Record<string, string>;
  devDependencies?: Record<string, string>;
  engines?: { node?: string };
}

const ENTRY_POINT_CANDIDATES = [
  "index.js",
  "index.ts",
  "main.js",
  "main.ts",
  "server.js",
  "server.ts",
  "app.js",
  "app.ts",
  "start.js",
  "start.ts",
  "dist/index.js",
  "dist/main.js",
  "dist/server.js",
  "src/index.js",
  "src/index.ts",
  "src/main.js",
  "src/main.ts",
  "src/server.js",
  "src/server.ts",
];

async function fileExists(p: string): Promise<boolean> {
  try {
    await access(p, constants.F_OK);
    return true;
  } catch {
    return false;
  }
}

async function readJson<T>(p: string): Promise<T | null> {
  try {
    const raw = await readFile(p, "utf8");
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

/** Detect package manager from lock files. */
async function detectPackageManager(
  dir: string,
): Promise<PackageManager | null> {
  if (await fileExists(join(dir, "pnpm-lock.yaml"))) return "pnpm";
  if (await fileExists(join(dir, "bun.lockb"))) return "bun";
  if (await fileExists(join(dir, "yarn.lock"))) return "yarn";
  if (await fileExists(join(dir, "package-lock.json"))) return "npm";
  return null;
}

/** Resolve start entry point from package.json scripts and file candidates. */
async function detectEntryPoint(
  dir: string,
  pkg: PackageJson | null,
): Promise<string | null> {
  // Prefer npm start script
  if (pkg?.scripts?.["start"]) {
    return `npm start`;
  }
  // Check well-known files
  for (const candidate of ENTRY_POINT_CANDIDATES) {
    if (await fileExists(join(dir, candidate))) {
      return candidate;
    }
  }
  // Fall back to "main" in package.json
  if (pkg?.main) {
    return pkg.main;
  }
  return null;
}

/** Extract Node version from .nvmrc, .node-version, engines field. */
async function detectNodeVersion(
  dir: string,
  pkg: PackageJson | null,
): Promise<string | null> {
  for (const f of [".nvmrc", ".node-version"]) {
    if (await fileExists(join(dir, f))) {
      const content = (await readFile(join(dir, f), "utf8")).trim();
      return content.replace(/^v/, "");
    }
  }
  if (pkg?.engines?.node) {
    // Strip semver range markers
    return pkg.engines.node.replace(/[^0-9.]/g, "").split(".")[0] ?? null;
  }
  return null;
}

/** Discover env files in a directory. */
async function detectEnvFiles(dir: string): Promise<string[]> {
  const candidates = [
    ".env",
    "config.env",
    ".kilobuild/config.env",
    ".env.local",
    ".env.example",
    ".env.template",
    ".env.production",
    ".env.development",
  ];
  const found: string[] = [];
  for (const f of candidates) {
    if (await fileExists(join(dir, f))) found.push(f);
  }
  return found;
}

/**
 * Analyse a single directory and produce a DiscoveredProject descriptor.
 * Returns null if the directory doesn't look like a Node.js project.
 */
export async function analyzeDirectory(
  dirPath: string,
  managedSlugs: Set<string> = new Set(),
): Promise<DiscoveredProject | null> {
  const absPath = resolve(dirPath);
  const hasPackageJson = await fileExists(join(absPath, "package.json"));
  if (!hasPackageJson) return null;

  const pkg = await readJson<PackageJson>(join(absPath, "package.json"));
  if (!pkg) return null;

  const name = pkg.name ?? basename(absPath);
  const packageManager = await detectPackageManager(absPath);
  const hasDockerfile = await fileExists(join(absPath, "Dockerfile"));
  const hasDockerCompose =
    (await fileExists(join(absPath, "docker-compose.yml"))) ||
    (await fileExists(join(absPath, "docker-compose.yaml")));
  const nodeVersion = await detectNodeVersion(absPath, pkg);
  const entryPoint = await detectEntryPoint(absPath, pkg);
  const hasTypeScript =
    (await fileExists(join(absPath, "tsconfig.json"))) ||
    Boolean(pkg.devDependencies?.typescript) ||
    Boolean(pkg.dependencies?.typescript);
  const envFiles = await detectEnvFiles(absPath);

  // Derive a slug from directory name
  const slug = basename(absPath).toLowerCase().replace(/[^a-z0-9-]/g, "-");

  return {
    path: absPath,
    name,
    packageManager,
    hasDockerfile,
    hasDockerCompose,
    nodeVersion,
    entryPoint,
    scripts: pkg.scripts ?? {},
    hasTypeScript,
    envFiles,
    dependencies: pkg.dependencies ?? {},
    devDependencies: pkg.devDependencies ?? {},
    isAlreadyManaged: managedSlugs.has(slug),
  };
}

export interface ScanOptions {
  /** Directories to scan. Defaults to current working directory. */
  roots?: string[];
  /** Max depth to recurse. Defaults to 3. */
  maxDepth?: number;
  /** Set of slugs already managed by KiloBuild (to mark duplicates). */
  managedSlugs?: Set<string>;
  /** Directories to skip (absolute paths or names). */
  ignore?: string[];
}

const DEFAULT_IGNORE = new Set([
  "node_modules",
  ".git",
  ".pnpm-store",
  "dist",
  "build",
  "out",
  "artifacts",
  ".cache",
  "coverage",
  ".turbo",
]);

/**
 * Given a list of discovered projects from a scan, pick the one that is
 * most likely to be the application root: the project whose path is
 * shallowest relative to the scan root. Emits a descriptive error when
 * multiple candidates exist so the caller can surface it clearly instead
 * of hard-failing with a generic message.
 *
 * Returns { project, ambiguous: false } when there is a clear winner, or
 * { project, ambiguous: true, candidates } when multiple were found and
 * the shallowest was chosen heuristically.
 */
export function selectApplicationProject(
  projects: DiscoveredProject[],
  scanRoot: string,
): {
  project: DiscoveredProject;
  ambiguous: boolean;
  candidates: string[];
} | null {
  if (projects.length === 0) return null;
  if (projects.length === 1) {
    return { project: projects[0]!, ambiguous: false, candidates: [projects[0]!.path] };
  }

  // Sort by path depth (fewest segments = shallowest)
  const root = resolve(scanRoot);
  const sorted = [...projects].sort((a, b) => {
    const depthA = relative(root, a.path).split("/").filter(Boolean).length;
    const depthB = relative(root, b.path).split("/").filter(Boolean).length;
    return depthA - depthB;
  });

  return {
    project: sorted[0]!,
    ambiguous: true,
    candidates: sorted.map((p) => p.path),
  };
}

/**
 * Recursively scan directories and return all discovered Node.js projects.
 */
export async function scanForProjects(
  opts: ScanOptions = {},
): Promise<DiscoveredProject[]> {
  const roots = opts.roots ?? [process.cwd()];
  const maxDepth = opts.maxDepth ?? 3;
  const managedSlugs = opts.managedSlugs ?? new Set<string>();
  const ignoreSet = new Set([
    ...DEFAULT_IGNORE,
    ...(opts.ignore ?? []),
  ]);
  const results: DiscoveredProject[] = [];

  async function recurse(dir: string, depth: number): Promise<void> {
    if (depth > maxDepth) return;

    const discovered = await analyzeDirectory(dir, managedSlugs);
    if (discovered) {
      results.push(discovered);
      return; // Don't recurse into a project directory
    }

    let entries: string[] = [];
    try {
      entries = await readdir(dir);
    } catch {
      return;
    }

    await Promise.all(
      entries.map(async (entry) => {
        if (ignoreSet.has(entry)) return;
        const fullPath = join(dir, entry);
        try {
          const s = await stat(fullPath);
          if (s.isDirectory()) await recurse(fullPath, depth + 1);
        } catch {
          // Ignore permission errors
        }
      }),
    );
  }

  await Promise.all(roots.map((r) => recurse(r, 0)));
  return results;
}

export type { DiscoveredProject, PackageManager };
