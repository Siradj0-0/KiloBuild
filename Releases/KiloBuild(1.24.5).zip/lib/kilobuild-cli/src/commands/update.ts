import { Command } from "commander";
import { cp, mkdtemp, mkdir, readFile, readdir, rm, writeFile, copyFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import { basename, dirname, join, resolve } from "node:path";
import { tmpdir } from "node:os";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { createHash } from "node:crypto";
import { createInterface } from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import ora from "ora";
import chalk from "chalk";
import { KILOBUILD_VERSION } from "../version.js";
import { err, info, ok, warn, dim } from "../utils/formatter.js";
import { api, ApiError } from "../utils/api-client.js";
import type { ProjectDetail, BuildResult } from "@workspace/kilobuild-types";

const execFileAsync = promisify(execFile);
const IDENTIFIER = /^[A-Za-z0-9._-]+$/;
const VERSIONED_RELEASE = /^KiloBuild\((\d+\.\d+\.\d+)\)\.zip$/i;
const DEFAULT_OWNER = "Siradj0-0";
const DEFAULT_REPOSITORY = "KiloBuild";
const DEFAULT_BRANCH = "main";

interface UpdateConfig {
  owner: string;
  repository: string;
  branch: string;
  installPath: string;
}

interface Release {
  version: string;
  downloadUrl: string;
  fileName: string;
}

function defaultDataDir(): string {
  if (process.env["KILOBUILD_DATA_DIR"]) return resolve(process.env["KILOBUILD_DATA_DIR"]);
  const standardInstall = "/opt/kilobuild/.kilobuild";
  return existsSync(standardInstall) ? standardInstall : resolve(join(process.cwd(), ".kilobuild"));
}

function dataDir(): string {
  return defaultDataDir();
}

function updateConfigPath(): string {
  return join(dataDir(), "update.json");
}

async function readUpdateConfig(): Promise<UpdateConfig | null> {
  try {
    const raw = JSON.parse(await readFile(updateConfigPath(), "utf8")) as Partial<UpdateConfig>;
    if (
      typeof raw.owner === "string" &&
      typeof raw.repository === "string" &&
      typeof raw.branch === "string" &&
      typeof raw.installPath === "string"
    ) {
      return raw as UpdateConfig;
    }
  } catch {
    // A missing or malformed setup file is handled by the guided setup.
  }
  return null;
}

async function askForConfig(existing?: Partial<UpdateConfig>): Promise<UpdateConfig> {
  const rl = createInterface({ input, output });
  try {
    const answer = async (label: string, fallback: string) => {
      const value = (await rl.question(`${label} [${fallback}]: `)).trim();
      return value || fallback;
    };
    const owner = await answer("GitHub owner or organization", existing?.owner ?? DEFAULT_OWNER);
    const repository = await answer("Public repository name", existing?.repository ?? DEFAULT_REPOSITORY);
    const branch = await answer("Release branch", existing?.branch ?? DEFAULT_BRANCH);
    const installPath = resolve(
      await answer(
        "Local KiloBuild installation path",
        existing?.installPath ?? (existsSync("/opt/kilobuild") ? "/opt/kilobuild" : process.cwd()),
      ),
    );

    if (!IDENTIFIER.test(owner) || !IDENTIFIER.test(repository) || !IDENTIFIER.test(branch)) {
      throw new Error(
        "Owner, repository, and branch may contain only letters, numbers, dots, underscores, and hyphens.",
      );
    }
    if (!existsSync(join(installPath, "package.json")) || !existsSync(join(installPath, "VERSION"))) {
      throw new Error(`No KiloBuild installation was found at ${installPath}.`);
    }

    const config = { owner, repository, branch, installPath };
    await mkdir(dataDir(), { recursive: true });
    await writeFile(updateConfigPath(), `${JSON.stringify(config, null, 2)}\n`, { mode: 0o600 });
    ok(`Saved public release source: https://github.com/${owner}/${repository}`);
    return config;
  } finally {
    rl.close();
  }
}

function compareVersions(left: string, right: string): number {
  const a = left.split(".").map(Number);
  const b = right.split(".").map(Number);
  for (let index = 0; index < 3; index += 1) {
    if (a[index] !== b[index]) return (a[index] ?? 0) - (b[index] ?? 0);
  }
  return 0;
}

function isVersion(value: string): boolean {
  return /^\d+\.\d+\.\d+$/.test(value);
}

async function githubJson<T>(url: string): Promise<T> {
  const response = await fetch(url, {
    headers: {
      Accept: "application/vnd.github+json",
      "User-Agent": "KiloBuild-updater",
    },
  });
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 300);
    throw new Error(`GitHub returned ${response.status} for ${url}${detail ? `: ${detail}` : ""}`);
  }
  return (await response.json()) as T;
}

async function findLatestRelease(config: UpdateConfig): Promise<Release | null> {
  const endpoint =
    `https://api.github.com/repos/${encodeURIComponent(config.owner)}` +
    `/${encodeURIComponent(config.repository)}/contents?ref=${encodeURIComponent(config.branch)}`;
  let entries: Array<{ name?: string; download_url?: string | null }>;
  try {
    entries = await githubJson<Array<{ name?: string; download_url?: string | null }>>(endpoint);
  } catch (error) {
    // GitHub returns 404 for the contents of an empty repository. Treat that
    // as "no releases yet" so the first manual upload has a clear workflow.
    if (error instanceof Error && error.message.startsWith("GitHub returned 404")) return null;
    throw error;
  }
  const releases = entries.flatMap((entry) => {
    const match = entry.name?.match(VERSIONED_RELEASE);
    if (!match || !entry.download_url || !isVersion(match[1]!)) return [];
    return [{ version: match[1]!, downloadUrl: entry.download_url, fileName: entry.name! }];
  });
  releases.sort((left, right) => compareVersions(right.version, left.version));
  return releases[0] ?? null;
}

async function downloadRelease(release: Release, target: string): Promise<void> {
  const response = await fetch(release.downloadUrl, {
    headers: { Accept: "application/octet-stream", "User-Agent": "KiloBuild-updater" },
  });
  if (!response.ok) throw new Error(`Could not download ${release.fileName} (${response.status}).`);
  await writeFile(target, Buffer.from(await response.arrayBuffer()), { mode: 0o600 });
}

async function validateArchive(archive: string, stagingDir: string, release: Release): Promise<void> {
  await execFileAsync("unzip", ["-t", archive], { maxBuffer: 2 * 1024 * 1024 });
  const { stdout } = await execFileAsync("unzip", ["-Z1", archive], { maxBuffer: 8 * 1024 * 1024 });
  for (const entry of stdout.split(/\r?\n/).filter(Boolean)) {
    if (entry.startsWith("/") || entry.split("/").includes("..")) {
      throw new Error(`Release archive contains an unsafe path: ${entry}`);
    }
  }

  await execFileAsync("unzip", ["-q", archive, "-d", stagingDir], { maxBuffer: 2 * 1024 * 1024 });
  const version = (await readFile(join(stagingDir, "VERSION"), "utf8")).trim();
  if (version !== release.version) {
    throw new Error(
      `Release filename and VERSION disagree: ${release.fileName} declares ${release.version}, archive declares ${version}.`,
    );
  }
}

async function backupData(): Promise<string> {
  const source = dataDir();
  if (!existsSync(source)) return "";
  const backup = `${source}-update-backup-${new Date().toISOString().replace(/[:.]/g, "-")}`;
  await cp(source, backup, { recursive: true, errorOnExist: true });
  return backup;
}

async function syncRelease(source: string, destination: string): Promise<void> {
  await mkdir(destination, { recursive: true });
  const entries = await readdir(source, { withFileTypes: true });
  for (const entry of entries) {
    // Runtime state is never part of a release and is never replaced by one.
    if (entry.name === ".kilobuild" || entry.name === ".git") continue;
    const sourcePath = join(source, entry.name);
    const destinationPath = join(destination, entry.name);
    if (entry.isDirectory()) {
      await mkdir(destinationPath, { recursive: true });
      await syncRelease(sourcePath, destinationPath);
      continue;
    }
    await rm(destinationPath, { force: true });
    await cp(sourcePath, destinationPath, { force: true });
  }
}

async function installRelease(config: UpdateConfig, release: Release): Promise<void> {
  const workingDir = await mkdtemp(join(tmpdir(), "kilobuild-update-"));
  const archive = join(workingDir, release.fileName);
  const stagingDir = join(workingDir, "release");
  await mkdir(stagingDir);

  try {
    await downloadRelease(release, archive);
    await validateArchive(archive, stagingDir, release);
    const backup = await backupData();
    if (backup) info(`Protected project data with a backup at ${backup}`);

    await syncRelease(stagingDir, config.installPath);
    const installer = join(config.installPath, "scripts", "install-vps.sh");
    if (!existsSync(installer)) throw new Error("The downloaded release is missing scripts/install-vps.sh.");

    const spinner = ora(`Installing KiloBuild ${release.version}...`).start();
    try {
      await execFileAsync("bash", [installer], {
        cwd: config.installPath,
        env: { ...process.env, KILOBUILD_DATA_DIR: dataDir() },
        maxBuffer: 8 * 1024 * 1024,
      });
      spinner.succeed(`KiloBuild updated to ${release.version}`);
    } catch (error) {
      spinner.fail("The update installer failed");
      throw error;
    }
  } finally {
    await rm(workingDir, { recursive: true, force: true });
  }
}

async function resolveConfig(setup: boolean): Promise<UpdateConfig> {
  const existing = await readUpdateConfig();
  if (setup || !existing) return askForConfig(existing ?? undefined);
  return existing;
}

// ── Bot (project) update: "kilo update <bot> <archive>" ──────────────
//
// Updates a single bot's code from a new release archive in place, without
// touching anything that holds runtime state: node_modules, dist/build
// output, data directories, or database files. Unlike the self-updater
// above (which always overwrites), this does a content diff against what's
// already on disk and only writes files that actually changed.

// Top-level directories under a project root that are never touched, no
// matter what the new archive contains — matches the data/build paths
// KiloBuild's own templates already know about (see kilobuild-templates'
// wellKnownDataDirs) plus the obvious build/dependency output.
const PROTECTED_TOP_LEVEL_DIRS = new Set([
  "node_modules",
  "dist",
  "build",
  ".git",
  ".kilobuild",
  "data",
  ".data",
  "db",
  "database",
  "storage",
  ".cache",
  "backups",
]);

// Database and environment files are protected wherever they appear in the
// tree, not just at the top level (e.g. a nested "src/data/local.sqlite").
const DB_FILE_RE = /\.(sqlite3?|db)(-journal|-wal|-shm)?$/i;
const ENV_FILE_RE = /^\.env(\..+)?$/i;

interface BotUpdateOptions {
  dryRun?: boolean;
  prune?: boolean;
  rebuild?: boolean;
  yes?: boolean;
}

interface FileEntry {
  relPath: string;
  absPath: string;
  hash: string;
}

/** Extra protected paths from a project-root `.kiloupdateignore` file, one relative path per line. */
async function readCustomIgnore(projectPath: string): Promise<string[]> {
  try {
    const raw = await readFile(join(projectPath, ".kiloupdateignore"), "utf8");
    return raw
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter((line) => line && !line.startsWith("#"))
      .map((line) => line.replace(/^\/+/, "").replace(/\/+$/, ""));
  } catch {
    return [];
  }
}

function isProtectedPath(relPath: string, customPrefixes: string[]): boolean {
  const top = relPath.split("/")[0]!;
  if (PROTECTED_TOP_LEVEL_DIRS.has(top)) return true;
  const base = basename(relPath);
  if (DB_FILE_RE.test(base) || ENV_FILE_RE.test(base)) return true;
  return customPrefixes.some((prefix) => relPath === prefix || relPath.startsWith(`${prefix}/`));
}

async function walkFiles(root: string, customPrefixes: string[]): Promise<Map<string, FileEntry>> {
  const out = new Map<string, FileEntry>();

  async function recurse(dir: string, relDir: string): Promise<void> {
    let entries;
    try {
      entries = await readdir(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const rel = relDir ? `${relDir}/${entry.name}` : entry.name;
      if (isProtectedPath(rel, customPrefixes)) continue;
      const abs = join(dir, entry.name);
      if (entry.isDirectory()) {
        await recurse(abs, rel);
      } else if (entry.isFile()) {
        const buf = await readFile(abs);
        out.set(rel, { relPath: rel, absPath: abs, hash: createHash("sha256").update(buf).digest("hex") });
      }
      // Symlinks are intentionally skipped: a bot release has no legitimate
      // reason to ship one, and following them risks writing outside the
      // project directory.
    }
  }

  await recurse(root, "");
  return out;
}

/** If the archive extracted to a single wrapping folder (npm-pack style), descend into it. */
async function effectiveRoot(dir: string): Promise<string> {
  const entries = await readdir(dir, { withFileTypes: true });
  if (entries.length === 1 && entries[0]!.isDirectory()) {
    return join(dir, entries[0]!.name);
  }
  return dir;
}

function assertSafeEntries(entries: string[]): void {
  for (const entry of entries) {
    if (entry.startsWith("/") || entry.split("/").includes("..")) {
      throw new Error(`Archive contains an unsafe path: ${entry}`);
    }
  }
}

async function extractBotArchive(archive: string, destDir: string): Promise<void> {
  const lower = archive.toLowerCase();
  if (lower.endsWith(".zip")) {
    await execFileAsync("unzip", ["-t", archive], { maxBuffer: 2 * 1024 * 1024 });
    const { stdout } = await execFileAsync("unzip", ["-Z1", archive], { maxBuffer: 8 * 1024 * 1024 });
    assertSafeEntries(stdout.split(/\r?\n/).filter(Boolean));
    await execFileAsync("unzip", ["-q", archive, "-d", destDir], { maxBuffer: 4 * 1024 * 1024 });
    return;
  }
  if (lower.endsWith(".tar.gz") || lower.endsWith(".tgz")) {
    const { stdout } = await execFileAsync("tar", ["-tzf", archive], { maxBuffer: 8 * 1024 * 1024 });
    assertSafeEntries(stdout.split(/\r?\n/).filter(Boolean));
    await execFileAsync("tar", ["-xzf", archive, "-C", destDir], { maxBuffer: 4 * 1024 * 1024 });
    return;
  }
  throw new Error(`Unsupported archive type: ${basename(archive)} (use a .zip or .tar.gz/.tgz file).`);
}

async function runBotUpdate(name: string, archiveArg: string, opts: BotUpdateOptions): Promise<void> {
  const archive = resolve(archiveArg);
  if (!existsSync(archive)) {
    err(`Archive not found: ${archive}`);
    process.exitCode = 1;
    return;
  }

  let project: ProjectDetail;
  try {
    project = await api.get<ProjectDetail>(`/projects/${name}`);
  } catch (error) {
    err(error instanceof ApiError ? error.message : String(error));
    process.exitCode = 1;
    return;
  }

  info(`Updating ${chalk.bold(project.name)} from ${basename(archive)}`);
  dim(
    `Protected (never touched): ${[...PROTECTED_TOP_LEVEL_DIRS].sort().join(", ")}, ` +
      `*.sqlite*/*.db files, .env* files`,
  );

  const workingDir = await mkdtemp(join(tmpdir(), "kilobuild-bot-update-"));
  try {
    const stagingDir = join(workingDir, "release");
    await mkdir(stagingDir, { recursive: true });

    const spinner = ora("Extracting archive...").start();
    try {
      await extractBotArchive(archive, stagingDir);
      spinner.succeed("Archive extracted");
    } catch (error) {
      spinner.fail("Failed to extract archive");
      throw error;
    }

    const releaseRoot = await effectiveRoot(stagingDir);
    const customPrefixes = await readCustomIgnore(project.path);
    if (customPrefixes.length > 0) {
      dim(`Also protected via .kiloupdateignore: ${customPrefixes.join(", ")}`);
    }

    const diffSpinner = ora("Comparing against the installed bot...").start();
    const [staged, current] = await Promise.all([
      walkFiles(releaseRoot, customPrefixes),
      walkFiles(project.path, customPrefixes),
    ]);
    diffSpinner.succeed("Comparison complete");

    let added = 0;
    let updated = 0;
    let unchanged = 0;
    const toWrite: FileEntry[] = [];
    for (const [rel, file] of staged) {
      const existing = current.get(rel);
      if (!existing) {
        added += 1;
        toWrite.push(file);
      } else if (existing.hash !== file.hash) {
        updated += 1;
        toWrite.push(file);
      } else {
        unchanged += 1;
      }
    }

    const toRemove: FileEntry[] = [];
    if (opts.prune) {
      for (const [rel, file] of current) {
        if (!staged.has(rel)) toRemove.push(file);
      }
    }

    console.log();
    ok(`${added} file(s) to add, ${updated} to update, ${unchanged} unchanged.`);
    if (opts.prune) ok(`${toRemove.length} file(s) to remove (not present in the new release).`);
    if (added + updated + toRemove.length === 0) {
      ok("Already up to date — nothing to change.");
      return;
    }

    if (opts.dryRun) {
      for (const file of toWrite) dim(`  would write  ${file.relPath}`);
      for (const file of toRemove) dim(`  would remove ${file.relPath}`);
      info("Dry run — no files were changed.");
      return;
    }

    if (!opts.yes) {
      const rl = createInterface({ input, output });
      const answer = await rl
        .question(chalk.yellow(`Apply these changes to "${project.name}"? [y/N] `))
        .finally(() => rl.close());
      if (answer.trim().toLowerCase() !== "y") {
        console.log(chalk.dim("Cancelled."));
        return;
      }
    }

    const applySpinner = ora("Applying changes...").start();
    try {
      for (const file of toWrite) {
        const target = join(project.path, file.relPath);
        await mkdir(dirname(target), { recursive: true });
        await copyFile(file.absPath, target);
      }
      for (const file of toRemove) {
        await rm(file.absPath, { force: true });
      }
      applySpinner.succeed(`Updated ${project.name}: +${added} ~${updated}${opts.prune ? ` -${toRemove.length}` : ""}`);
    } catch (error) {
      applySpinner.fail("Failed to apply changes");
      throw error;
    }

    if (opts.rebuild === false) {
      info("Skipped rebuild (--no-rebuild). Run `kilo rebuild " + project.name + "` when ready.");
      return;
    }

    const rebuildSpinner = ora(`Rebuilding ${chalk.bold(project.name)}...`).start();
    try {
      const result = await api.post<BuildResult>(`/projects/${name}/rebuild`);
      if (result.status === "success") {
        rebuildSpinner.succeed(`${project.name} rebuilt and restarted`);
      } else if (result.status === "pending" || result.status === "running") {
        rebuildSpinner.succeed(`Build for ${project.name} queued`);
        info("The daemon is building in the background. Check `kilo inspect` or `kilo list` for status.");
      } else {
        rebuildSpinner.fail(`Rebuild reported status "${result.status}"`);
        if (result.error) err(result.error);
      }
    } catch (error) {
      rebuildSpinner.fail("Update applied, but the rebuild failed");
      throw error;
    }
  } finally {
    await rm(workingDir, { recursive: true, force: true });
  }
}

export function updateCommand(): Command {
  return new Command("update")
    .description(
      "Update KiloBuild itself (no args), or safely update one bot's code from a release " +
        "archive without touching its data: kilo update <bot-name> <archive.zip|.tar.gz>",
    )
    .argument("[botName]", "Bot project name or ID — omit to update KiloBuild itself")
    .argument("[archive]", "Path to the bot's updated .zip or .tar.gz release")
    .option("--setup", "Ask for or replace the public GitHub repository details (KiloBuild self-update only)")
    .option("--check", "Check for updates without installing one (KiloBuild self-update only)")
    .option("--dry-run", "Preview a bot update without changing any files")
    .option("--prune", "Also remove bot files that aren't in the new release (outside protected paths)")
    .option("--no-rebuild", "Skip rebuilding the bot's container after syncing files")
    .option("-y, --yes", "Skip the confirmation prompt for a bot update")
    .action(async (
      botName: string | undefined,
      archiveArg: string | undefined,
      opts: { setup?: boolean; check?: boolean; dryRun?: boolean; prune?: boolean; rebuild?: boolean; yes?: boolean },
    ) => {
      if (botName && archiveArg) {
        await runBotUpdate(botName, archiveArg, opts);
        return;
      }
      if (botName && !archiveArg) {
        err("Updating a bot needs both a name and an archive: kilo update <bot-name> <archive.zip|.tar.gz>");
        process.exitCode = 1;
        return;
      }

      try {
        const config = await resolveConfig(Boolean(opts.setup));
        const installedVersion = (await readFile(join(config.installPath, "VERSION"), "utf8")).trim();
        if (!isVersion(installedVersion)) {
          throw new Error(`The installed VERSION file is invalid: "${installedVersion}"`);
        }

        const latest = await findLatestRelease(config);
        if (!latest) {
          warn(`No KiloBuild(x.y.z).zip releases were found in https://github.com/${config.owner}/${config.repository}.`);
          return;
        }

        info(`Installed KiloBuild ${installedVersion}; highest available ZIP is ${latest.version}.`);
        const comparison = compareVersions(latest.version, installedVersion);
        if (comparison <= 0) {
          ok(`KiloBuild ${installedVersion} is up to date.`);
          return;
        }
        if (opts.check) {
          warn(`A newer KiloBuild release is available: ${latest.fileName}`);
          return;
        }

        await installRelease(config, latest);
      } catch (error) {
        err(error instanceof Error ? error.message : String(error));
        process.exitCode = 1;
      }
    });
}