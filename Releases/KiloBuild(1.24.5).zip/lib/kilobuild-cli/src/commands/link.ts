import { Command } from "commander";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { err, info } from "../utils/formatter.js";
import type { StatusUrlResponse } from "@workspace/kilobuild-types";

export function linkCommand(): Command {
  return new Command("link")
    .description("Print the current public status URL for a project, without going through Discord")
    .argument("<name>", "Project name or ID")
    .option("--json", "Output as JSON")
    .action(async (name: string, opts: { json?: boolean }) => {
      try {
        const result = await api.get<StatusUrlResponse>(`/projects/${name}/status-url`);

        if (opts.json) {
          console.log(JSON.stringify(result, null, 2));
          return;
        }

        console.log(chalk.bold(result.url));
        info(`Expires ${new Date(result.expiresAt).toLocaleString()} — the link rotates automatically, so re-run this command for a fresh one.`);
      } catch (error) {
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });
}
