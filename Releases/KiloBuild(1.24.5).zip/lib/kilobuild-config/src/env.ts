import { existsSync } from "node:fs";
import { readFile } from "node:fs/promises";
import { join, relative } from "node:path";

/**
 * Project environment files are deliberately ordered. A real project-root
 * `.env` is the primary source; the legacy `config.env` locations are only
 * fallbacks for projects that do not have one.
 */
export const PROJECT_ENV_FILE_CANDIDATES = [
  ".env",
  "config.env",
  ".kilobuild/config.env",
] as const;

export interface ProjectEnv {
  values: Record<string, string>;
  source: string | null;
}

function unquote(value: string): string {
  if (value.length < 2) return value;
  const first = value[0];
  const last = value[value.length - 1];
  if ((first !== `"` && first !== "'") || last !== first) return value;

  const body = value.slice(1, -1);
  if (first === "'") return body;
  return body.replace(/\\(["\\$nrt])/g, (_match, escaped: string) => {
    switch (escaped) {
      case "n": return "\n";
      case "r": return "\r";
      case "t": return "\t";
      default: return escaped;
    }
  });
}

function stripInlineComment(value: string): string {
  let quote: `"` | "'" | null = null;
  for (let index = 0; index < value.length; index += 1) {
    const char = value[index];
    if ((char === `"` || char === "'") && value[index - 1] !== "\\") {
      quote = quote === char ? null : quote ?? char;
      continue;
    }
    if (char === "#" && !quote && (index === 0 || /\s/.test(value[index - 1]!))) {
      return value.slice(0, index).trimEnd();
    }
  }
  return value.trim();
}

/**
 * Parse the useful dotenv syntax without expanding variables or evaluating
 * shell code. This keeps secrets such as tokens containing `#` or `=` intact.
 */
export function parseEnvFile(contents: string, source = ".env"): Record<string, string> {
  const values: Record<string, string> = {};
  const lines = contents.replace(/^\uFEFF/, "").split(/\r?\n/);

  for (let index = 0; index < lines.length; index += 1) {
    const lineNumber = index + 1;
    const raw = lines[index]!.trim();
    if (!raw || raw.startsWith("#")) continue;

    const assignment = raw.startsWith("export ") ? raw.slice(7).trimStart() : raw;
    const equals = assignment.indexOf("=");
    if (equals < 1) {
      throw new Error(`${source}:${lineNumber}: expected KEY=VALUE`);
    }

    const key = assignment.slice(0, equals).trim();
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) {
      throw new Error(`${source}:${lineNumber}: invalid environment variable name "${key}"`);
    }

    const rawValue = stripInlineComment(assignment.slice(equals + 1).trim());
    values[key] = unquote(rawValue);
  }

  return values;
}

/**
 * Load a project's environment using the stable precedence contract:
 * project/.env, then project/config.env, then project/.kilobuild/config.env.
 */
export async function loadProjectEnv(projectPath: string): Promise<ProjectEnv> {
  for (const relativePath of PROJECT_ENV_FILE_CANDIDATES) {
    const filePath = join(projectPath, relativePath);
    if (!existsSync(filePath)) continue;
    const contents = await readFile(filePath, "utf8");
    return {
      values: parseEnvFile(contents, relativePath),
      source: relative(projectPath, filePath),
    };
  }

  return { values: {}, source: null };
}