import { readFile, writeFile, mkdir } from "node:fs/promises";
import { existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { z } from "zod/v4";
import type {
  GlobalConfig,
  ProjectConfig,
  RestartPolicy,
  PackageManager,
} from "@workspace/kilobuild-types";
export {
  PROJECT_ENV_FILE_CANDIDATES,
  loadProjectEnv,
  parseEnvFile,
} from "./env.js";
export type { ProjectEnv } from "./env.js";

const defaultDataDir =
  process.env["KILOBUILD_DATA_DIR"] ?? join(process.cwd(), ".kilobuild");

// ── Zod schemas ───────────────────────────────

const portBindingSchema = z.object({
  containerPort: z.number().int().min(1).max(65535),
  hostPort: z.number().int().min(1).max(65535).nullable().default(null),
  protocol: z.enum(["tcp", "udp"]).default("tcp"),
});

const volumeBindingSchema = z.object({
  containerPath: z.string().min(1),
  hostPath: z.string().min(1),
  readOnly: z.boolean().default(false),
});

export const projectConfigSchema = z.object({
  cpuLimit: z.string().default("0.1"),
  memoryLimit: z.string().default("128m"),
  memorySwapLimit: z.string().nullable().default(null),
  restartPolicy: z
    .enum(["no", "always", "on-failure", "unless-stopped"])
    .default("unless-stopped"),
  maxRestarts: z.number().int().min(0).default(10),
  restartWindowSeconds: z.number().int().min(1).default(300),
  backoffMultiplier: z.number().min(1).default(2.0),
  cooldownSeconds: z.number().int().min(0).default(5),
  healthCheckEnabled: z.boolean().default(false),
  healthCheckPath: z.string().nullable().default(null),
  healthCheckIntervalSeconds: z.number().int().min(1).default(30),
  healthCheckTimeoutSeconds: z.number().int().min(1).default(10),
  healthCheckRetries: z.number().int().min(1).default(3),
  envVars: z.record(z.string(), z.string()).default({}),
  portBindings: z.array(portBindingSchema).default([]),
  volumeBindings: z.array(volumeBindingSchema).default([]),
  networkMode: z.string().default("bridge"),
  labels: z.record(z.string(), z.string()).default({}),
  autoInstall: z.boolean().default(true),
  autoBuild: z.boolean().default(false),
  autoMigrate: z.boolean().default(false),
  logRotationEnabled: z.boolean().default(true),
  logMaxSizeMb: z.number().int().min(1).default(100),
  logRetentionDays: z.number().int().min(1).default(30),
  buildArgs: z.record(z.string(), z.string()).default({}),
  nodeArgs: z.array(z.string()).default([]),
  extraDockerfileLines: z.array(z.string()).default([]),
});

export const globalConfigSchema = z.object({
  dataDir: z.string().default(defaultDataDir),
  projectsDir: z.string().default(join(defaultDataDir, "projects")),
  projectsRootDir: z.string().default(join(defaultDataDir, "projects")),
  logDir: z.string().default(join(defaultDataDir, "logs")),
  backupDir: z.string().default(join(defaultDataDir, "backups")),
  dockerSocket: z.string().default("/var/run/docker.sock"),
  defaultNodeVersion: z.string().default("22"),
  defaultPackageManager: z
    .enum(["npm", "pnpm", "yarn", "bun"])
    .default("npm"),
  defaults: projectConfigSchema.partial().default({}),
  monitoringIntervalMs: z.number().int().min(1000).default(10_000),
  healthCheckIntervalMs: z.number().int().min(1000).default(30_000),
  statsRetentionDays: z.number().int().min(1).default(7),
  eventsRetentionDays: z.number().int().min(1).default(30),
  pluginsDir: z.string().default(join(defaultDataDir, "plugins")),
  apiPort: z.number().int().min(1024).max(65535).default(3001),
  apiHost: z.string().default("127.0.0.1"),
  publicStatusPort: z.number().int().min(1024).max(65535).nullable().default(null),
  publicStatusHost: z.string().default("127.0.0.1"),
  publicBaseUrl: z.string().url().nullable().default(null),
  apiSecret: z.string().nullable().default(null),
  internalToken: z.string().nullable().default(null),
  discordWebhookUrl: z.string().url().nullable().default(null),
  discordBotsDir: z.string().default(join(process.env["HOME"] ?? "/root", "Discord-Bots")),
});

export type ProjectConfigInput = z.input<typeof projectConfigSchema>;
export type GlobalConfigInput = z.input<typeof globalConfigSchema>;

// ── Default values ────────────────────────────

export const DEFAULT_PROJECT_CONFIG: ProjectConfig =
  projectConfigSchema.parse({});

export const DEFAULT_GLOBAL_CONFIG: GlobalConfig = globalConfigSchema.parse({});

function normalizeProjectConfigInput(value: unknown): unknown {
  if (!value || typeof value !== "object" || Array.isArray(value)) return value;
  const config = { ...(value as Record<string, unknown>) };
  if (config["cpuLimit"] === null) config["cpuLimit"] = DEFAULT_PROJECT_CONFIG.cpuLimit;
  if (config["memoryLimit"] === null) config["memoryLimit"] = DEFAULT_PROJECT_CONFIG.memoryLimit;
  return config;
}

// ── ConfigManager ─────────────────────────────

export class ConfigManager {
  private globalConfig: GlobalConfig;
  private projectConfigs = new Map<string, ProjectConfig>();
  private readonly configPath: string;

  constructor(configPath?: string) {
    this.configPath =
      configPath ??
      join(defaultDataDir, "config.json");
    this.globalConfig = DEFAULT_GLOBAL_CONFIG;
  }

  async load(): Promise<void> {
    if (!existsSync(this.configPath)) {
      await this.save();
      return;
    }
    try {
      const raw = await readFile(this.configPath, "utf8");
      const parsed = JSON.parse(raw) as { global?: unknown; projects?: Record<string, unknown> };
      const rawGlobal = { ...((parsed.global ?? {}) as Record<string, unknown>) };
      if (rawGlobal["projectsDir"] && !rawGlobal["projectsRootDir"]) {
        rawGlobal["projectsRootDir"] = rawGlobal["projectsDir"];
      }
      if (rawGlobal["defaults"]) {
        rawGlobal["defaults"] = normalizeProjectConfigInput(rawGlobal["defaults"]);
      }
      this.globalConfig = globalConfigSchema.parse(rawGlobal);
      if (parsed.projects) {
        for (const [id, cfg] of Object.entries(parsed.projects)) {
          this.projectConfigs.set(id, projectConfigSchema.parse(normalizeProjectConfigInput(cfg)));
        }
      }
    } catch (err) {
      throw new Error(`Failed to load KiloBuild config: ${String(err)}`);
    }
  }

  async save(): Promise<void> {
    await mkdir(dirname(this.configPath), { recursive: true });
    const data = {
      global: this.globalConfig,
      projects: Object.fromEntries(this.projectConfigs.entries()),
    };
    await writeFile(this.configPath, JSON.stringify(data, null, 2), "utf8");
  }

  getGlobal(): GlobalConfig {
    return this.globalConfig;
  }

  async setGlobal(partial: Partial<GlobalConfigInput>): Promise<GlobalConfig> {
    this.globalConfig = globalConfigSchema.parse({
      ...this.globalConfig,
      ...partial,
    });
    await this.save();
    return this.globalConfig;
  }

  getProject(projectId: string): ProjectConfig {
    const override = this.projectConfigs.get(projectId);
    if (!override) return this.getEffectiveDefaults();
    return { ...this.getEffectiveDefaults(), ...override };
  }

  async setProject(
    projectId: string,
    partial: Partial<ProjectConfigInput>,
  ): Promise<ProjectConfig> {
    const current = this.projectConfigs.get(projectId) ?? {};
    const updated = projectConfigSchema.parse({ ...current, ...partial });
    this.projectConfigs.set(projectId, updated);
    await this.save();
    return updated;
  }

  async deleteProject(projectId: string): Promise<void> {
    this.projectConfigs.delete(projectId);
    await this.save();
  }

  /** Merge global defaults with DEFAULT_PROJECT_CONFIG. */
  getEffectiveDefaults(): ProjectConfig {
    return projectConfigSchema.parse({
      ...DEFAULT_PROJECT_CONFIG,
      ...this.globalConfig.defaults,
    });
  }
}

/** Process-wide singleton. */
let _manager: ConfigManager | null = null;

export function getConfigManager(configPath?: string): ConfigManager {
  if (!_manager) _manager = new ConfigManager(configPath);
  return _manager;
}

export type { GlobalConfig, ProjectConfig, RestartPolicy, PackageManager };
