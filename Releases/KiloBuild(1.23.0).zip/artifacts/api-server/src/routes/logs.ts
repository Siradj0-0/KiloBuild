import { Router, type IRouter } from "express";
import { getConfigManager } from "@workspace/kilobuild-config";
import { LogManager } from "@workspace/kilobuild-logging";
import { ContainerManager } from "@workspace/kilobuild-docker";
import Dockerode from "dockerode";
import { findProject } from "./projects.js";
import type { LogSource } from "@workspace/kilobuild-types";

const router: IRouter = Router();

function getLogManager(): LogManager {
  const cfg = getConfigManager().getGlobal();
  return new LogManager(cfg.logDir);
}

function getDocker(): Dockerode {
  return new Dockerode({ socketPath: getConfigManager().getGlobal().dockerSocket });
}

// ── GET /projects/:id/logs ────────────────────
router.get("/projects/:id/logs", async (req, res) => {
  const project = await findProject(req.params["id"]!);
  if (!project) return res.status(404).json({ error: "Project not found" });

  const tail = parseInt(String(req.query["tail"] ?? "200"), 10);
  const source = req.query["source"] as LogSource | undefined;
  const since = req.query["since"] ? new Date(String(req.query["since"])) : undefined;
  const follow = String(req.query["follow"] ?? "false") === "true";

  // First try the log manager (for historical logs)
  const lm = getLogManager();
  const entries = await lm.query({
    projectId: project.id,
    source,
    tail,
    since,
  });

  if (follow) {
    res.status(200);
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders();

    let closed = false;
    const heartbeat = setInterval(() => {
      if (!closed) res.write(": keep-alive\n\n");
    }, 15_000);
    heartbeat.unref();

    const send = (payload: unknown) => {
      if (!closed) res.write(`event: log\ndata: ${JSON.stringify(payload)}\n\n`);
    };
    for (const entry of entries) send(entry);

    const docker = getDocker();
    const cm = new ContainerManager(docker);
    const containerId = await cm.findBySlug(project.slug);
    if (containerId) {
      void cm.streamLogs(containerId, {
        tail: 0,
        follow: true,
        onChunk: (chunk, isStderr) => {
          for (const line of chunk.split(/\r?\n/)) {
            if (!line.trim()) continue;
            send({
              projectId: project.id,
              source: isStderr ? "stderr" : "stdout",
              message: line,
              timestamp: new Date(),
              level: isStderr ? "error" : "info",
            });
          }
        },
      }).catch((error: unknown) => {
        if (!closed) {
          res.write(`event: error\ndata: ${JSON.stringify({ error: String(error) })}\n\n`);
        }
      });
    }

    req.on("close", () => {
      closed = true;
      clearInterval(heartbeat);
      res.end();
    });
    return;
  }

  // If no logs in log manager, fall back to Docker container logs
  if (entries.length === 0) {
    const docker = getDocker();
    const cm = new ContainerManager(docker);
    const containerId = await cm.findBySlug(project.slug);

    if (!containerId) return res.json([]);

    const dockerLogs: Array<{
      projectId: string;
      source: string;
      message: string;
      timestamp: Date;
      level: string;
    }> = [];

    try {
      await cm.streamLogs(containerId, {
        tail,
        follow: false,
        onChunk: (chunk, isStderr) => {
          const lines = chunk.trim().split("\n");
          for (const line of lines) {
            if (!line.trim()) continue;
            dockerLogs.push({
              projectId: project.id,
              source: isStderr ? "stderr" : "stdout",
              message: line,
              timestamp: new Date(),
              level: isStderr ? "error" : "info",
            });
          }
        },
      });
    } catch {
      // Container may not be running
    }

    return res.json(dockerLogs);
  }

  res.json(entries);
  return;
});

export default router;
