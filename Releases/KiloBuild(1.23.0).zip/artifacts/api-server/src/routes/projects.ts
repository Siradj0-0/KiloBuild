import { Router, type IRouter } from "express";
import { and, desc, eq, like, or, sql } from "drizzle-orm";
import { db } from "@workspace/db";
import {
  projectsTable,
  containersTable,
  projectConfigsTable,
  insertProjectSchema,
  updateProjectSchema,
} from "@workspace/db/schema";
import { z } from "zod/v4";
import { access, constants } from "node:fs";
import { mkdir, writeFile } from "node:fs/promises";
import { join, resolve, relative, isAbsolute } from "node:path";
import { analyzeDirectory } from "@workspace/kilobuild-discovery";
import { scaffoldProject } from "@workspace/kilobuild-templates";
import { getConfigManager } from "@workspace/kilobuild-config";
import Dockerode from "dockerode";
import { ContainerManager, ImageManager } from "@workspace/kilobuild-docker";
import { ensureStatusToken } from "../status-tokens.js";

const router: IRouter = Router();

// ── GET /projects ──────────────────────────────
router.get("/projects", async (req, res) => {
  const { status, tag, q } = req.query as Record<string, string>;

  try {
    const conditions = [];
    if (status) {
      conditions.push(eq(projectsTable.status, status as typeof projectsTable.status._.data));
    }
    if (q) {
      const pattern = `%${q}%`;
      conditions.push(or(like(projectsTable.name, pattern), like(projectsTable.description, pattern)));
    }

    const query = db.select().from(projectsTable);
    const rows = await (conditions.length > 0 ? query.where(and(...conditions)) : query)
      .orderBy(desc(projectsTable.updatedAt));

    // Filter by tag client-side (tags stored as JSONB array)
    const filtered = tag
      ? rows.filter((p) => Array.isArray(p.tags) && (p.tags as string[]).includes(tag))
      : rows;

    res.json(filtered);
  } catch (err) {
    res.status(500).json({ error: "Failed to list projects", detail: String(err) });
  }
  return;
});

// ── POST /projects ─────────────────────────────
router.post("/projects", async (req, res) => {
  const name = typeof req.body?.name === "string" ? req.body.name.trim() : "";
  const pathValue = typeof req.body?.path === "string" ? req.body.path : "";
  const projectPath = pathValue ? resolve(pathValue) : "";
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

  if (!name || !projectPath || !slug) {
    return res.status(400).json({ error: "name and path are required" });
  }

  try {
    const global = getConfigManager().getGlobal();
    const projectsRootDir = resolve(global.projectsRootDir);
    const discordBotsDir = resolve(global.discordBotsDir);
    const sep = process.platform === "win32" ? "\\" : "/";

    function isInsideDir(child: string, dir: string): boolean {
      const rel = relative(dir, child);
      return rel !== ".." && !rel.startsWith(`..${sep}`) && !isAbsolute(rel);
    }

    if (!isInsideDir(projectPath, projectsRootDir) && !isInsideDir(projectPath, discordBotsDir)) {
      return res.status(400).json({
        error: "Project path must be inside the configured projects root or Discord-Bots directory",
        detail: { projectsRootDir, discordBotsDir },
      });
    }

    await mkdir(projectPath, { recursive: true });

    // Create initializes a new directory; import can still pass
    // initialize=false to require an existing package.json.
    if (!(await fileExists(join(projectPath, "package.json")))) {
      if (req.body?.initialize === false) {
        return res.status(400).json({
          error: "The project directory has no package.json",
          detail: "Create package.json first or omit initialize=false.",
        });
      }

      await writeFile(
        join(projectPath, "package.json"),
        JSON.stringify({
          name: slug,
          version: "1.0.0",
          private: true,
          scripts: { start: "node index.js" },
        }, null, 2) + "\n",
        { encoding: "utf8", flag: "wx" },
      ).catch((error: unknown) => {
        if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
      });
      await writeFile(
        join(projectPath, "index.js"),
        `const http = require("node:http");\nconst port = Number(process.env.PORT || 3000);\nhttp.createServer((_req, res) => res.end("KiloBuild project is running\\n")).listen(port, () => console.log(\`Listening on \${port}\`));\n`,
        { encoding: "utf8", flag: "wx" },
      ).catch((error: unknown) => {
        if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
      });
    }

    const discovered = await analyzeDirectory(projectPath);
    if (!discovered) {
      return res.status(400).json({ error: "Unable to analyze the Node.js project" });
    }

    const parsed = insertProjectSchema.safeParse({
      name,
      slug,
      path: projectPath,
      description: req.body.description,
      tags: req.body.tags,
      nodeVersion: req.body.nodeVersion ?? discovered.nodeVersion,
      entryPoint: req.body.entryPoint ?? discovered.entryPoint,
      packageManager: req.body.packageManager ?? discovered.packageManager ?? "npm",
      projectType: req.body.projectType ?? (discovered.hasTypeScript ? "typescript" : "node"),
      metadata: {
        discovered: true,
        hasDockerfile: discovered.hasDockerfile,
        hasDockerCompose: discovered.hasDockerCompose,
        envFiles: discovered.envFiles,
      },
    });

    if (!parsed.success) {
      return res.status(400).json({ error: "Validation failed", detail: parsed.error.message });
    }

    const [project] = await db
      .insert(projectsTable)
      .values({
        ...parsed.data,
        tags: parsed.data.tags ?? [],
        metadata: parsed.data.metadata ?? {},
      })
      .returning();

    const config = getConfigManager().getProject(project.id);
    await db.insert(projectConfigsTable).values({ projectId: project.id, ...config });
    await ensureStatusToken(project.id);

    await scaffoldProject({
      projectPath,
      context: {
        projectName: project.name,
        projectSlug: project.slug,
        nodeVersion: project.nodeVersion ?? getConfigManager().getGlobal().defaultNodeVersion,
        packageManager: project.packageManager,
        entryPoint: project.entryPoint ?? "index.js",
        nodeArgs: config.nodeArgs,
        hasTypeScript: discovered.hasTypeScript,
        ports: config.portBindings.map((binding) => binding.containerPort),
        volumes: config.volumeBindings.map(
          (binding) => `${binding.hostPath}:${binding.containerPath}${binding.readOnly ? ":ro" : ""}`,
        ),
        envVars: config.envVars,
        buildCommand: null,
        startCommand: project.entryPoint ?? "node index.js",
        projectType: project.projectType,
        extraDockerfileLines: config.extraDockerfileLines,
        autoInstall: config.autoInstall,
        autoBuild: config.autoBuild,
        autoMigrate: config.autoMigrate,
      },
    });

    res.status(201).json({ ...project, config });
  } catch (err: unknown) {
    const msg = String(err);
    if (msg.includes("unique")) {
      return res.status(409).json({ error: "Project name already exists" });
    }
    res.status(500).json({ error: "Failed to create project", detail: msg });
  }
  return;
});

// ── GET /projects/:id ─────────────────────────
router.get("/projects/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const project = await findProject(id);
    if (!project) return res.status(404).json({ error: "Project not found" });

    // Enrich with container + config
    const [container] = await db
      .select()
      .from(containersTable)
      .where(eq(containersTable.projectId, project.id))
      .limit(1)
      .orderBy(sql`${containersTable.createdAt} DESC`);

    const [config] = await db
      .select()
      .from(projectConfigsTable)
      .where(eq(projectConfigsTable.projectId, project.id))
      .limit(1);

    res.json({ ...project, container: container ?? null, config: config ?? null });
  } catch (err) {
    res.status(500).json({ error: "Failed to get project", detail: String(err) });
  }
  return;
});

// ── PATCH /projects/:id ───────────────────────
router.patch("/projects/:id", async (req, res) => {
  const { id } = req.params;
  const parsed = updateProjectSchema.safeParse(req.body);

  if (!parsed.success) {
    return res.status(400).json({ error: "Validation failed", detail: parsed.error.message });
  }

  try {
    const project = await findProject(id);
    if (!project) return res.status(404).json({ error: "Project not found" });

    const [updated] = await db
      .update(projectsTable)
      .set({ ...parsed.data, updatedAt: new Date() })
      .where(eq(projectsTable.id, project.id))
      .returning();

    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: "Failed to update project", detail: String(err) });
  }
  return;
});

// ── DELETE /projects/:id ──────────────────────
router.delete("/projects/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const project = await findProject(id);
    if (!project) return res.status(404).json({ error: "Project not found" });

    // Docker is optional during project import and local development. When
    // available, remove only resources owned by this KiloBuild project.
    try {
      const docker = new Dockerode({
        socketPath: getConfigManager().getGlobal().dockerSocket,
      });
      const manager = new ContainerManager(docker);
      const containerId = await manager.findBySlug(project.slug);
      if (containerId) await manager.remove(containerId, true);

      const imageManager = new ImageManager(docker);
      const imageName = imageManager.imageName(project.slug);
      if (await imageManager.exists(imageName)) {
        await imageManager.remove(imageName, true);
      }
    } catch (dockerError) {
      req.log.warn({ err: dockerError, project: project.slug }, "Docker cleanup skipped");
    }

    await db.delete(projectsTable).where(eq(projectsTable.id, project.id));
    await getConfigManager().deleteProject(project.id);
    res.status(204).send();
  } catch (err) {
    res.status(500).json({ error: "Failed to delete project", detail: String(err) });
  }
  return;
});

async function fileExists(path: string): Promise<boolean> {
  return new Promise((resolve) => {
    access(path, constants.F_OK, (error) => resolve(!error));
  });
}

// ── Helper: find project by ID or name ───────

export async function findProject(idOrName: string) {
  // Try UUID first
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (uuidRegex.test(idOrName)) {
    const [p] = await db.select().from(projectsTable).where(eq(projectsTable.id, idOrName)).limit(1);
    return p ?? null;
  }
  // Try by name or slug
  const [p] = await db
    .select()
    .from(projectsTable)
    .where(or(eq(projectsTable.name, idOrName), eq(projectsTable.slug, idOrName)) as ReturnType<typeof eq>)
    .limit(1);
  return p ?? null;
}

export default router;
