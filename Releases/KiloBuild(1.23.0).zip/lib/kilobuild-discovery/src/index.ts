import {
  readFile,
  readdir,
  stat,
  access,
} from "node:fs/promises";
import { join, basename, resolve } from "node:path";
import { constants } from "node:fs";
import type {
  DiscoveredProject,
  PackageManager,
} from "@workspace/kilobuild-types";

interface PackageJson {
  name?: string;
  version?: string;
  main?: string;
  scripts?: Record<string, string>;
  dependencies?: Record<string, string>;
  devDependencies?: Record<string, string>;
  engines?: { node?: string };
}

const ENTRY_POINT_CANDIDATES = [
  "index.js",
  "index.ts",
  "main.js",
  "main.ts",
  "server.js",
  "server.ts",
  "app.js",
  "app.ts",
  "start.js",
  "start.ts",
  "dist/index.js",
  "dist/main.js",
  "dist/server.js",
  "src/index.js",
  "src/index.ts",
  "src/main.js",
  "src/main.ts",
  "src/server.js",
  "src/server.ts",
];

async function fileExists(p: string): Promise<boolean> {
  try {
    await access(p, constants.F_OK);
    return true;
  } catch {
    return false;
  }
}

async function readJson<T>(p: string): Promise<T | null> {
  try {
    const raw = await readFile(p, "utf8");
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

/** Detect package manager from lock files. */
async function detectPackageManager(
  dir: string,
): Promise<PackageManager | null> {
  if (await fileExists(join(dir, "pnpm-lock.yaml"))) return "pnpm";
  if (await fileExists(join(dir, "bun.lockb"))) return "bun";
  if (await fileExists(join(dir, "yarn.lock"))) return "yarn";
  if (await fileExists(join(dir, "package-lock.json"))) return "npm";
  return null;
}

/** Resolve start entry point from package.json scripts and file candidates. */
async function detectEntryPoint(
  dir: string,
  pkg: PackageJson | null,
): Promise<string | null> {
  // Prefer npm start script
  if (pkg?.scripts?.["start"]) {
    return `npm start`;
  }
  // Check well-known files
  for (const candidate of ENTRY_POINT_CANDIDATES) {
    if (await fileExists(join(dir, candidate))) {
      return candidate;
    }
  }
  // Fall back to "main" in package.json
  if (pkg?.main) {
    return pkg.main;
  }
  return null;
}

/** Extract Node version from .nvmrc, .node-version, engines field. */
async function detectNodeVersion(
  dir: string,
  pkg: PackageJson | null,
): Promise<string | null> {
  for (const f of [".nvmrc", ".node-version"]) {
    if (await fileExists(join(dir, f))) {
      const content = (await readFile(join(dir, f), "utf8")).trim();
      return content.replace(/^v/, "");
    }
  }
  if (pkg?.engines?.node) {
    // Strip semver range markers
    return pkg.engines.node.replace(/[^0-9.]/g, "").split(".")[0] ?? null;
  }
  return null;
}

/** Discover env files in a directory. */
async function detectEnvFiles(dir: string): Promise<string[]> {
  const candidates = [
    ".env",
    ".env.local",
    ".env.example",
    ".env.template",
    ".env.production",
    ".env.development",
  ];
  const found: string[] = [];
  for (const f of candidates) {
    if (await fileExists(join(dir, f))) found.push(f);
  }
  return found;
}

/**
 * Analyse a single directory and produce a DiscoveredProject descriptor.
 * Returns null if the directory doesn't look like a Node.js project.
 */
export async function analyzeDirectory(
  dirPath: string,
  managedSlugs: Set<string> = new Set(),
): Promise<DiscoveredProject | null> {
  const absPath = resolve(dirPath);
  const hasPackageJson = await fileExists(join(absPath, "package.json"));
  if (!hasPackageJson) return null;

  const pkg = await readJson<PackageJson>(join(absPath, "package.json"));
  if (!pkg) return null;

  const name = pkg.name ?? basename(absPath);
  const packageManager = await detectPackageManager(absPath);
  const hasDockerfile = await fileExists(join(absPath, "Dockerfile"));
  const hasDockerCompose =
    (await fileExists(join(absPath, "docker-compose.yml"))) ||
    (await fileExists(join(absPath, "docker-compose.yaml")));
  const nodeVersion = await detectNodeVersion(absPath, pkg);
  const entryPoint = await detectEntryPoint(absPath, pkg);
  const hasTypeScript =
    (await fileExists(join(absPath, "tsconfig.json"))) ||
    Boolean(pkg.devDependencies?.typescript) ||
    Boolean(pkg.dependencies?.typescript);
  const envFiles = await detectEnvFiles(absPath);

  // Derive a slug from directory name
  const slug = basename(absPath).toLowerCase().replace(/[^a-z0-9-]/g, "-");

  return {
    path: absPath,
    name,
    packageManager,
    hasDockerfile,
    hasDockerCompose,
    nodeVersion,
    entryPoint,
    scripts: pkg.scripts ?? {},
    hasTypeScript,
    envFiles,
    dependencies: pkg.dependencies ?? {},
    devDependencies: pkg.devDependencies ?? {},
    isAlreadyManaged: managedSlugs.has(slug),
  };
}

export interface ScanOptions {
  /** Directories to scan. Defaults to current working directory. */
  roots?: string[];
  /** Max depth to recurse. Defaults to 3. */
  maxDepth?: number;
  /** Set of slugs already managed by KiloBuild (to mark duplicates). */
  managedSlugs?: Set<string>;
  /** Directories to skip (absolute paths or names). */
  ignore?: string[];
}

const DEFAULT_IGNORE = new Set([
  "node_modules",
  ".git",
  ".pnpm-store",
  "dist",
  "build",
  ".cache",
  "coverage",
  ".turbo",
]);

/**
 * Recursively scan directories and return all discovered Node.js projects.
 */
export async function scanForProjects(
  opts: ScanOptions = {},
): Promise<DiscoveredProject[]> {
  const roots = opts.roots ?? [process.cwd()];
  const maxDepth = opts.maxDepth ?? 3;
  const managedSlugs = opts.managedSlugs ?? new Set<string>();
  const ignoreSet = new Set([
    ...DEFAULT_IGNORE,
    ...(opts.ignore ?? []),
  ]);
  const results: DiscoveredProject[] = [];

  async function recurse(dir: string, depth: number): Promise<void> {
    if (depth > maxDepth) return;

    const discovered = await analyzeDirectory(dir, managedSlugs);
    if (discovered) {
      results.push(discovered);
      return; // Don't recurse into a project directory
    }

    let entries: string[] = [];
    try {
      entries = await readdir(dir);
    } catch {
      return;
    }

    await Promise.all(
      entries.map(async (entry) => {
        if (ignoreSet.has(entry)) return;
        const fullPath = join(dir, entry);
        try {
          const s = await stat(fullPath);
          if (s.isDirectory()) await recurse(fullPath, depth + 1);
        } catch {
          // Ignore permission errors
        }
      }),
    );
  }

  await Promise.all(roots.map((r) => recurse(r, 0)));
  return results;
}

export type { DiscoveredProject, PackageManager };
