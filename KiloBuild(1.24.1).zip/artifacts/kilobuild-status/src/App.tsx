import { QueryClient, QueryClientProvider, useQuery } from '@tanstack/react-query';
import { Activity, AlertTriangle, ArrowUpRight, Check, Copy, HeartPulse, Layers3, RefreshCw, Server, ShieldCheck, TerminalSquare, Timer } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { Route, Switch, useLocation, useParams, useSearch } from 'wouter';
import NotFound from '@/pages/not-found';
import '@/index.css';

const queryClient = new QueryClient();
type Tab = 'overview' | 'logs';
type Status = 'online' | 'offline' | 'starting' | 'stopping' | 'unknown';
type PublicProject = {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  projectType: string;
  nodeVersion?: string | null;
};
type PublicContainer = {
  containerId: string;
  status: string;
  startedAt?: string | null;
  finishedAt?: string | null;
  exitCode?: number | null;
  restartCount: number;
  error?: string | null;
  lastStopReason?: 'normal' | 'crash' | 'unknown' | null;
};
type PublicDashboard = {
  project: PublicProject;
  status: Status;
  container: PublicContainer | null;
  lastStopReason?: PublicContainer['lastStopReason'];
  uptimeSeconds: number;
  checkedAt: string;
  health: { status: string; message?: string | null; responseTimeMs?: number | null };
};

async function readStatus(token: string): Promise<PublicDashboard> {
  const response = await fetch(`/api/status/${encodeURIComponent(token)}`, {
    headers: { Accept: 'application/json' },
    cache: 'no-store',
  });
  if (!response.ok) throw new Error('This status link is invalid or has expired.');
  return response.json() as Promise<PublicDashboard>;
}

function getKey() {
  const params = new URLSearchParams(window.location.search);
  return params.get('token') || params.get('projectId') || '';
}

function formatUptime(seconds: number | undefined) {
  if (!seconds || seconds < 1) return '—';
  const d = Math.floor(seconds / 86400); const h = Math.floor((seconds % 86400) / 3600); const m = Math.floor((seconds % 3600) / 60);
  return d ? `${d}d ${h}h ${m}m` : `${h}h ${m}m`;
}

function formatTime(value?: string | null) {
  if (!value) return 'Not recorded';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function statusTone(status: string) {
  if (status === 'online' || status === 'running' || status === 'healthy' || status === 'ok') return { label: 'Online', color: 'text-[hsl(var(--primary))]', bg: 'bg-[hsl(var(--primary)/.1)]', dot: 'bg-[hsl(var(--primary))]' };
  if (status === 'starting' || status === 'stopping' || status === 'building') return { label: status === 'starting' ? 'Starting' : status === 'stopping' ? 'Stopping' : 'Building', color: 'text-[hsl(var(--accent-foreground))]', bg: 'bg-[hsl(var(--accent)/.18)]', dot: 'bg-[hsl(var(--accent))]' };
  if (status === 'offline' || status === 'stopped' || status === 'error' || status === 'unhealthy') return { label: status === 'offline' ? 'Offline' : 'Needs attention', color: 'text-[hsl(var(--destructive))]', bg: 'bg-[hsl(var(--destructive)/.1)]', dot: 'bg-[hsl(var(--destructive))]' };
  return { label: 'Unknown', color: 'text-[hsl(var(--muted-foreground))]', bg: 'bg-[hsl(var(--muted))]', dot: 'bg-[hsl(var(--muted-foreground))]' };
}

function Skeleton() {
  return <div className="min-h-[100dvh] bg-[hsl(var(--background))] p-5 md:p-10"><div className="mx-auto max-w-6xl animate-pulse space-y-8"><div className="h-10 w-56 rounded-lg bg-[hsl(var(--muted))]" /><div className="h-52 rounded-3xl bg-[hsl(var(--muted))]" /><div className="grid gap-4 md:grid-cols-3"><div className="h-36 rounded-2xl bg-[hsl(var(--muted))]" /><div className="h-36 rounded-2xl bg-[hsl(var(--muted))]" /><div className="h-36 rounded-2xl bg-[hsl(var(--muted))]" /></div></div></div>;
}

function ErrorState({ message, onRetry }: { message: string; onRetry: () => void }) {
  return <main className="grid-paper flex min-h-[100dvh] items-center justify-center px-6"><section className="max-w-md text-center"><div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-[hsl(var(--destructive)/.11)] text-[hsl(var(--destructive))]"><AlertTriangle size={25} /></div><p className="mono text-xs uppercase tracking-[.22em] text-[hsl(var(--destructive))]">no signal</p><h1 className="mt-3 text-3xl font-extrabold tracking-[-.04em]">We could not reach this project.</h1><p className="mt-4 text-sm leading-6 text-[hsl(var(--muted-foreground))]">{message}</p><button onClick={onRetry} data-testid="button-retry-status" className="mt-7 inline-flex items-center gap-2 rounded-xl bg-[hsl(var(--foreground))] px-4 py-3 text-sm font-bold text-[hsl(var(--background))]"><RefreshCw size={16} /> Try again</button></section></main>;
}

function EmptyState() {
  return <main className="grid-paper flex min-h-[100dvh] items-center justify-center px-6"><section className="max-w-lg text-center"><div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]"><TerminalSquare size={25} /></div><p className="mono text-xs uppercase tracking-[.22em] text-[hsl(var(--primary))]">waiting for a project</p><h1 className="mt-3 text-3xl font-extrabold tracking-[-.04em]">No status token supplied.</h1><p className="mt-4 text-sm leading-6 text-[hsl(var(--muted-foreground))]">Open a KiloBuild status link with a token, or use <span className="mono">?projectId=</span> while developing.</p></section></main>;
}

function Header({ project, status, tab, setTab, onRefresh, refreshedAt }: { project: PublicProject; status: string; tab: Tab; setTab: (tab: Tab) => void; onRefresh: () => void; refreshedAt: Date }) {
  const tone = statusTone(status);
  const [copied, setCopied] = useState(false);
  const copyUrl = async () => { await navigator.clipboard?.writeText(window.location.href); setCopied(true); window.setTimeout(() => setCopied(false), 1500); };
  return <header className="border-b border-[hsl(var(--border))] bg-[hsl(var(--card)/.82)] backdrop-blur-xl"><div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-5 md:px-8"><div className="flex min-w-0 items-center gap-3"><div className="hidden h-10 w-10 items-center justify-center rounded-xl bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] sm:flex"><Layers3 size={20} /></div><div className="min-w-0"><div className="flex items-center gap-2"><p className="truncate text-[15px] font-extrabold tracking-[-.02em]" data-testid="text-project-name">{project.name}</p><span className={`relative inline-flex h-2 w-2 rounded-full ${tone.dot} ${status === 'starting' ? 'dot-pulse' : ''}`} /></div><p className="mono truncate text-[11px] text-[hsl(var(--muted-foreground))]" data-testid="text-project-slug">{project.slug} / {project.projectType}</p></div></div><div className="flex items-center gap-2"><span className={`hidden rounded-full px-3 py-1.5 text-xs font-bold sm:inline-flex ${tone.bg} ${tone.color}`} data-testid="status-header">{tone.label}</span><button onClick={copyUrl} data-testid="button-copy-status-link" className="flex h-9 items-center gap-2 rounded-lg border border-[hsl(var(--border))] px-3 text-xs font-bold transition-colors hover:bg-[hsl(var(--muted))]">{copied ? <Check size={14} /> : <Copy size={14} />}<span className="hidden sm:inline">{copied ? 'Copied' : 'Share'}</span></button><button onClick={onRefresh} data-testid="button-refresh-status" className="flex h-9 w-9 items-center justify-center rounded-lg border border-[hsl(var(--border))] transition-colors hover:bg-[hsl(var(--muted))]"><RefreshCw size={15} /></button></div></div><div className="mx-auto flex max-w-6xl items-center gap-6 px-5 md:px-8"><button onClick={() => setTab('overview')} data-testid="tab-overview" className={`border-b-2 py-3 text-xs font-extrabold ${tab === 'overview' ? 'border-[hsl(var(--primary))] text-[hsl(var(--foreground))]' : 'border-transparent text-[hsl(var(--muted-foreground))]'}`}>Overview</button><button onClick={() => setTab('logs')} data-testid="tab-logs" className={`border-b-2 py-3 text-xs font-extrabold ${tab === 'logs' ? 'border-[hsl(var(--primary))] text-[hsl(var(--foreground))]' : 'border-transparent text-[hsl(var(--muted-foreground))]'}`}>Logs</button><span className="mono ml-auto hidden text-[10px] text-[hsl(var(--muted-foreground))] sm:block">checked {refreshedAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span></div></header>;
}

function Metric({ icon: Icon, label, value, detail, accent = false }: { icon: typeof Activity; label: string; value: string; detail: string; accent?: boolean }) {
  return <article className={`rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 ${accent ? 'ring-1 ring-[hsl(var(--accent)/.55)]' : ''}`}><div className="flex items-center justify-between"><p className="flex items-center gap-2 text-xs font-bold text-[hsl(var(--muted-foreground))]"><Icon size={15} className={accent ? 'text-[hsl(var(--accent-foreground))]' : 'text-[hsl(var(--primary))]'} />{label}</p><ArrowUpRight size={14} className="text-[hsl(var(--muted-foreground))]" /></div><p className="mt-4 text-2xl font-extrabold tracking-[-.04em]" data-testid={`metric-${label.toLowerCase().replaceAll(' ', '-')}`}>{value}</p><p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">{detail}</p></article>;
}

function Dashboard() {
  const params = useParams<{ token?: string }>();
  const token = params.token || getKey();
  const query = useQuery({
    queryKey: ['public-status', token],
    queryFn: () => readStatus(token),
    enabled: Boolean(token),
    refetchInterval: 30000,
    retry: false,
  });
  const [tab, setTab] = useState<Tab>('overview');
  const [refreshedAt, setRefreshedAt] = useState(new Date());
  const [uptimeTick, setUptimeTick] = useState(0);

  useEffect(() => {
    if (!query.data) return;
    setRefreshedAt(new Date());
  }, [query.data]);

  useEffect(() => {
    if (query.data?.status !== 'online') return;
    const timer = window.setInterval(() => setUptimeTick((value) => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, [query.data?.status]);

  if (!token) return <EmptyState />;
  if (query.isPending) return <Skeleton />;
  if (query.isError || !query.data) {
    return <ErrorState message={query.error instanceof Error ? query.error.message : 'This status link is invalid or has expired.'} onRetry={() => void query.refetch()} />;
  }

  const dashboard = query.data;
  const project = dashboard.project;
  const status = dashboard.status.toLowerCase();
  const tone = statusTone(status);
  const healthStatus = dashboard.health.status.toLowerCase();
  const isHealthy = healthStatus === 'ok' || healthStatus === 'healthy';
  const uptime = dashboard.uptimeSeconds + uptimeTick;
  const invalidate = () => {
    setRefreshedAt(new Date());
    void query.refetch();
  };
  const response = dashboard.health.responseTimeMs;
  const stopReason = dashboard.container?.lastStopReason;
  const stopDetail = stopReason === 'crash'
    ? 'Crashed unexpectedly'
    : stopReason === 'normal'
      ? 'Stopped by an operator'
      : 'No recent interruptions';

  return <div className="min-h-[100dvh] bg-[hsl(var(--background))]">
    <Header project={project} status={status} tab={tab} setTab={setTab} onRefresh={invalidate} refreshedAt={refreshedAt} />
    <main className="mx-auto max-w-6xl px-5 py-7 md:px-8 md:py-10">
      {tab === 'logs' ? <section className="reveal rounded-3xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-8 md:p-12"><div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]"><TerminalSquare size={22} /></div><h2 className="mt-8 text-3xl font-extrabold tracking-[-.04em]">Logs</h2><p className="mono mt-3 text-sm text-[hsl(var(--muted-foreground))]" data-testid="text-logs-coming-soon">Coming Soon.....</p></section> : <>
        <section className="reveal relative overflow-hidden rounded-3xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-6 md:p-9">
          <div className="absolute right-0 top-0 h-44 w-44 translate-x-16 -translate-y-20 rounded-full bg-[hsl(var(--accent)/.18)] blur-3xl" />
          <div className="relative flex flex-col justify-between gap-7 md:flex-row md:items-end"><div>
            <div className={`mb-5 inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-extrabold ${tone.bg} ${tone.color}`} data-testid="status-project"><span className={`relative h-2 w-2 rounded-full ${tone.dot} ${status === 'starting' ? 'dot-pulse' : ''}`} />{tone.label}</div>
            <h1 className="max-w-2xl text-4xl font-extrabold leading-[1.02] tracking-[-.055em] md:text-6xl" data-testid="heading-project-status">{status === 'online' ? 'Everything is running.' : status === 'starting' ? 'Starting up cleanly.' : status === 'offline' ? 'The project is offline.' : 'Status needs a closer look.'}</h1>
            <p className="mt-5 max-w-xl text-sm leading-6 text-[hsl(var(--muted-foreground))]" data-testid="text-project-description">{project.description || 'KiloBuild is keeping watch over this Node.js project.'}</p>
          </div><div className="md:min-w-48 md:text-right"><p className="mono text-[10px] uppercase tracking-[.2em] text-[hsl(var(--muted-foreground))]">last checked</p><p className="mt-2 text-sm font-bold" data-testid="text-checked-at">{formatTime(dashboard.checkedAt)}</p><p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">Auto-refreshes every 30 sec</p></div></div>
        </section>
        <section className="mt-4 grid gap-4 md:grid-cols-3">
          <Metric icon={Timer} label="Uptime" value={formatUptime(uptime)} detail={dashboard.container?.startedAt ? `Since ${formatTime(dashboard.container.startedAt)}` : 'No active run'} />
          <Metric icon={HeartPulse} label="Health check" value={isHealthy ? 'Healthy' : healthStatus === 'unknown' ? 'Unknown' : 'Attention'} detail={response ? `${response}ms response time` : dashboard.health.message || 'No response recorded'} accent={isHealthy} />
          <Metric icon={RefreshCw} label="Restarts" value={String(dashboard.container?.restartCount ?? 0)} detail={stopDetail} />
        </section>
        <section className="mt-4 grid gap-4 lg:grid-cols-[1.35fr_.65fr]">
          <article className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-6"><div className="flex items-center justify-between"><div><p className="flex items-center gap-2 text-xs font-bold text-[hsl(var(--muted-foreground))]"><Server size={15} className="text-[hsl(var(--primary))]" /> Runtime details</p><h2 className="mt-2 text-lg font-extrabold">Container pulse</h2></div><span className="mono rounded-md bg-[hsl(var(--muted))] px-2 py-1 text-[10px] text-[hsl(var(--muted-foreground))]">{dashboard.container?.containerId?.slice(0, 12) || 'not allocated'}</span></div><div className="mt-7 grid gap-5 sm:grid-cols-2"><Detail label="Node version" value={project.nodeVersion || 'Not specified'} /><Detail label="Container state" value={dashboard.container?.status || dashboard.status} /><Detail label="Started" value={formatTime(dashboard.container?.startedAt)} /><Detail label="Last finished" value={formatTime(dashboard.container?.finishedAt)} /><Detail label="Exit code" value={dashboard.container?.exitCode == null ? '—' : String(dashboard.container.exitCode)} /><Detail label="Stop reason" value={stopReason || 'Unknown'} /></div>{dashboard.container?.error && <div className="mt-6 flex gap-3 rounded-xl bg-[hsl(var(--destructive)/.08)] p-4 text-xs text-[hsl(var(--destructive))]"><AlertTriangle size={15} className="mt-0.5 shrink-0" /><span data-testid="text-container-error">{dashboard.container.error}</span></div>}</article>
          <aside className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--primary))] p-6 text-[hsl(var(--primary-foreground))]"><p className="flex items-center gap-2 text-xs font-bold opacity-75"><ShieldCheck size={15} /> KiloBuild monitor</p><h2 className="mt-8 text-2xl font-extrabold leading-tight tracking-[-.04em]">Plain English, on purpose.</h2><p className="mt-3 text-sm leading-6 opacity-75">This page reports the latest observation from the Node.js runtime — not a dashboard full of guesses.</p><div className="mt-8 border-t border-current/20 pt-4"><p className="mono text-[10px] uppercase tracking-[.18em] opacity-65">Project ID</p><p className="mono mt-2 break-all text-xs" data-testid="text-project-id">{project.id}</p></div></aside>
        </section>
      </>}
    </main>
    <footer className="mx-auto flex max-w-6xl items-center justify-between px-5 pb-8 pt-5 text-[11px] text-[hsl(var(--muted-foreground))] md:px-8"><span className="mono">KILOBUILD / STATUS PULSE</span><span className="flex items-center gap-1"><Activity size={12} /> Operational clarity</span></footer>
  </div>;
}

function Detail({ label, value }: { label: string; value: string }) { return <div><p className="text-[11px] font-bold text-[hsl(var(--muted-foreground))]">{label}</p><p className="mono mt-1.5 text-sm" data-testid={`detail-${label.toLowerCase().replaceAll(' ', '-')}`}>{value}</p></div>; }

function Router() { return <Switch><Route path="/" component={Dashboard} /><Route path="/status/:token" component={Dashboard} /><Route component={NotFound} /></Switch>; }
function App() { return <QueryClientProvider client={queryClient}><Router /></QueryClientProvider>; }
export default App;