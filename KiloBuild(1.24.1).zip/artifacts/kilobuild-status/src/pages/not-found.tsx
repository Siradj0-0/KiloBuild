import { Link } from 'wouter';
import { ArrowLeft, RadioTower } from 'lucide-react';

export default function NotFound() {
  return (
    <main className="grid-paper flex min-h-[100dvh] items-center justify-center px-6">
      <section className="reveal max-w-md text-center">
        <div className="mx-auto mb-6 flex h-14 w-14 items-center justify-center rounded-2xl bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]"><RadioTower size={25} /></div>
        <p className="mono mb-3 text-xs uppercase tracking-[.24em] text-[hsl(var(--primary))]">signal not found</p>
        <h1 className="text-4xl font-extrabold tracking-[-.04em]">This route is off the map.</h1>
        <p className="mt-4 text-sm leading-6 text-[hsl(var(--muted-foreground))]">The status page you requested does not exist, or its access token has expired.</p>
        <Link href="/" data-testid="link-return-dashboard" className="mt-8 inline-flex items-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-4 py-3 text-sm font-bold text-[hsl(var(--primary-foreground))] transition-transform hover:-translate-y-0.5"><ArrowLeft size={16} /> Return to dashboard</Link>
      </section>
    </main>
  );
}
