import app from "./app";
import { logger } from "./lib/logger";
import { getConfigManager } from "@workspace/kilobuild-config";
import { initializePlugins } from "./routes/plugins";
import { randomBytes } from "node:crypto";
import { existsSync } from "node:fs";
import Dockerode from "dockerode";
import { db, containersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { DockerEventWatcher, pingDocker, getDockerVersion } from "@workspace/kilobuild-docker";
import { startStatusTokenRotation, rotateAllStatusTokens, statusTokenPolicy } from "./status-tokens.js";
import type { GlobalConfig } from "@workspace/kilobuild-types";
import { sql } from "drizzle-orm";
import { createPublicStatusApp } from "./public-status-app.js";

function resolvePort(configuredPort: number): number {
  const rawPort = process.env["PORT"];
  if (!rawPort) return configuredPort;

  const port = Number(rawPort);
  if (Number.isNaN(port) || port <= 0) {
    throw new Error(`Invalid PORT value: "${rawPort}"`);
  }
  return port;
}

function resolveHost(configuredHost: string): string {
  return process.env["KILOBUILD_API_HOST"]?.trim() || configuredHost;
}

function resolveOptionalPort(configuredPort: number | null): number | null {
  const rawPort = process.env["KILOBUILD_PUBLIC_STATUS_PORT"]?.trim();
  if (!rawPort) return configuredPort;
  const port = Number(rawPort);
  if (Number.isNaN(port) || port <= 0) {
    throw new Error(`Invalid KILOBUILD_PUBLIC_STATUS_PORT value: "${rawPort}"`);
  }
  return port;
}

async function start(): Promise<void> {
  await getConfigManager().load();
  const configManager = getConfigManager();
  const before = configManager.getGlobal();
  const generatedInternalToken = !before.internalToken;
  if (generatedInternalToken) {
    await configManager.setGlobal({
      internalToken: randomBytes(32).toString("hex"),
    });
  }
  const config = configManager.getGlobal();
  const port = resolvePort(config.apiPort);
  if (generatedInternalToken) {
    logger.info("================================================");
    logger.info(" KiloBuild — first-time setup");
    logger.info("------------------------------------------------");
    logger.info(` Internal Token (KiloBuilder bot ONLY): ${config.internalToken}`);
    logger.info(` API listening at:                       http://${config.apiHost}:${port}`);
    logger.info("================================================");
    logger.info(" Save these now — they will not be printed again.");
    logger.info(` They live in: ${process.env["KILOBUILD_CONFIG_PATH"] ?? `${config.dataDir}/config.json`}`);
    logger.info("================================================");
  }
  await runBootDiagnostics(config);
  await initializePlugins();
  await rotateAllStatusTokens();
  startStatusTokenRotation();
  startDockerLifecycleWatcher(config.dockerSocket);
  const host = resolveHost(config.apiHost);
  const publicStatusPort = resolveOptionalPort(config.publicStatusPort);
  const publicStatusHost =
    process.env["KILOBUILD_PUBLIC_STATUS_HOST"]?.trim() || config.publicStatusHost;

  app.listen(port, host, (err) => {
    if (err) {
      logger.error({ err }, "Error listening on port");
      process.exit(1);
    }

    logger.info({ port, host }, "Server listening");
  });

  if (publicStatusPort !== null) {
    const publicStatusUiDir = process.env["KILOBUILD_STATUS_DIR"];
    createPublicStatusApp(publicStatusUiDir).listen(
      publicStatusPort,
      publicStatusHost,
      (err) => {
        if (err) {
          logger.error({ err }, "Error listening on public status port");
          process.exit(1);
        }
        logger.info(
          { port: publicStatusPort, host: publicStatusHost },
          "Public status listener ready; management API remains on its private listener",
        );
      },
    );
  }
}

async function runBootDiagnostics(config: GlobalConfig): Promise<void> {
  logger.info("[boot] Running startup diagnostics");
  try {
    const alive = await pingDocker(config);
    if (!alive) logger.error("[boot] ERROR Docker daemon is not reachable");
    else {
      const version = await getDockerVersion(config);
      logger.info(`[boot] OK Docker ${version.version} (${config.dockerSocket})`);
    }
  } catch (error) {
    logger.error({ error }, "[boot] ERROR Docker diagnostics failed");
  }
  try {
    await db.run(sql`SELECT 1`);
    logger.info("[boot] OK Embedded SQLite database is ready");
  } catch (error) {
    logger.error({ error }, "[boot] ERROR Embedded SQLite database is unavailable");
  }
  for (const [name, path] of [["data", config.dataDir], ["logs", config.logDir], ["backups", config.backupDir]] as const) {
    logger.info(`[boot] ${existsSync(path) ? "OK" : "WARN"} ${name} directory: ${path}`);
  }
  logger.info(`[boot] Rotating status URLs: every ${statusTokenPolicy.rotationMinutes} minutes with ${statusTokenPolicy.graceMinutes}-minute grace; fetch via /internal/status-url/:projectId`);
}

function startDockerLifecycleWatcher(socketPath: string): void {
  const watcher = new DockerEventWatcher(new Dockerode({ socketPath }));
  void watcher.addListener(async (event) => {
    if (event.action !== "die" || !event.projectId || event.exitCode == null || event.exitCode === 0) return;
    const [container] = await db
      .select({ lastStopReason: containersTable.lastStopReason })
      .from(containersTable)
      .where(eq(containersTable.containerId, event.containerId))
      .limit(1);
    if (container?.lastStopReason === "normal") return;
    await db
      .update(containersTable)
      .set({ status: "dead", finishedAt: event.timestamp, exitCode: event.exitCode, lastStopReason: "crash" })
      .where(eq(containersTable.containerId, event.containerId));
    logger.warn({ projectId: event.projectId, exitCode: event.exitCode }, "[lifecycle] container crashed");
  });
  void watcher.start().catch((error) => logger.warn({ error }, "[lifecycle] Docker watcher unavailable"));
}

start().catch((err: unknown) => {
  logger.error({ err }, "Failed to initialize KiloBuild");
  process.exit(1);
});
