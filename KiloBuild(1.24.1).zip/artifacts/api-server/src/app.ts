import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { apiAuth } from "./middlewares/auth";
import statusRouter from "./routes/status";
import healthRouter from "./routes/health";
import { existsSync } from "node:fs";
import { join } from "node:path";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// On a VPS the API and the public status page share one origin. Keep this
// optional so the Replit development frontend can continue to run separately.
const statusUiDir = process.env["KILOBUILD_STATUS_DIR"];
if (statusUiDir && existsSync(join(statusUiDir, "index.html"))) {
  const statusUi = express.static(statusUiDir, { index: "index.html" });
  app.use((req, res, next) => {
    if (req.method !== "GET" && req.method !== "HEAD") {
      next();
      return;
    }
    if (req.path.startsWith("/api/") || req.path.startsWith("/internal/")) {
      next();
      return;
    }
    statusUi(req, res, () => {
      if ((req.path === "/" || req.path.startsWith("/status/")) && req.accepts("html")) {
        res.sendFile(join(statusUiDir, "index.html"));
        return;
      }
      next();
    });
  });
}

app.use(statusRouter);
app.use("/api", statusRouter);
app.use("/api", healthRouter);
app.use("/api", apiAuth, router);

export default app;
