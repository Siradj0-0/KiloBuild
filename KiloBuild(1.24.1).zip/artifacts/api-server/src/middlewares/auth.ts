import type { RequestHandler } from "express";
import { getConfigManager } from "@workspace/kilobuild-config";

/**
 * The daemon is operator-only, but a bearer check prevents accidental exposure
 * if a host/VPN binding is changed later.
 */
export const apiAuth: RequestHandler = async (req, res, next) => {
  const secret = getConfigManager().getGlobal().apiSecret;

  // No secret configured → open access (normal operator setup).
  if (!secret) {
    next();
    return;
  }

  // /internal/* routes handle their own auth (internalToken) — let them through.
  if (req.path.startsWith("/internal/")) {
    next();
    return;
  }

  // Secret is set — enforce bearer token.
  const header = req.header("authorization");
  const token = header?.startsWith("Bearer ") ? header.slice(7) : null;
  if (token === secret) {
    next();
    return;
  }

  res.status(401).json({ error: "Unauthorized" });
};