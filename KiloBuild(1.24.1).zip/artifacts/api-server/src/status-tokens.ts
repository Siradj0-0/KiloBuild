import { randomBytes } from "node:crypto";
import { and, eq, gt, or } from "drizzle-orm";
import { db, projectsTable, statusTokensTable } from "@workspace/db";
import { logger } from "./lib/logger.js";

const TOKEN_TTL_MS = 15 * 60 * 1000;
const GRACE_TTL_MS = 2 * 60 * 1000;
const ROTATION_INTERVAL_MS = 15 * 60 * 1000;
const MAX_ATTEMPTS_PER_WINDOW = 60;
const attemptWindows = new Map<string, { startedAt: number; count: number }>();
let rotationTimer: NodeJS.Timeout | null = null;

function newToken(): string {
  return randomBytes(32).toString("hex");
}

function isRateLimited(ip: string): boolean {
  const now = Date.now();
  const current = attemptWindows.get(ip);
  if (!current || now - current.startedAt >= TOKEN_TTL_MS) {
    attemptWindows.set(ip, { startedAt: now, count: 1 });
    return false;
  }
  current.count += 1;
  return current.count > MAX_ATTEMPTS_PER_WINDOW;
}

export async function ensureStatusToken(projectId: string) {
  const now = new Date();
  const [existing] = await db
    .select()
    .from(statusTokensTable)
    .where(eq(statusTokensTable.projectId, projectId))
    .limit(1);

  if (existing && existing.currentExpiresAt.getTime() > now.getTime()) {
    return existing;
  }

  const currentExpiresAt = new Date(now.getTime() + TOKEN_TTL_MS);
  if (!existing) {
    const [created] = await db
      .insert(statusTokensTable)
      .values({
        projectId,
        currentToken: newToken(),
        currentExpiresAt,
      })
      .returning();
    return created;
  }

  const [rotated] = await db
    .update(statusTokensTable)
    .set({
      previousToken: existing.currentToken,
      previousExpiresAt: new Date(now.getTime() + GRACE_TTL_MS),
      currentToken: newToken(),
      currentExpiresAt,
    })
    .where(eq(statusTokensTable.projectId, projectId))
    .returning();
  return rotated;
}

export async function resolveStatusToken(token: string, ip: string) {
  const now = new Date();
  const [row] = await db
    .select()
    .from(statusTokensTable)
    .where(
      or(
        and(eq(statusTokensTable.currentToken, token), gt(statusTokensTable.currentExpiresAt, now)),
        and(
          eq(statusTokensTable.previousToken, token),
          gt(statusTokensTable.previousExpiresAt, now),
        ),
      ),
    )
    .limit(1);
  // Valid links are polled by the dashboard and must not consume the
  // invalid-attempt budget. Only failed lookups count toward the limit.
  if (!row && isRateLimited(ip)) return null;
  return row ?? null;
}

export async function rotateAllStatusTokens(): Promise<void> {
  const projects = await db.select({ id: projectsTable.id }).from(projectsTable);
  let rotated = 0;
  for (const project of projects) {
    const existing = await db
      .select({ expiresAt: statusTokensTable.currentExpiresAt })
      .from(statusTokensTable)
      .where(eq(statusTokensTable.projectId, project.id))
      .limit(1);
    await ensureStatusToken(project.id);
    if (!existing[0] || existing[0].expiresAt.getTime() <= Date.now()) rotated++;
  }
  if (rotated > 0) {
    logger.info({ projects: rotated }, "[status] Rotated project status URLs");
  }
}

export function startStatusTokenRotation(): void {
  if (rotationTimer) return;
  rotationTimer = setInterval(() => {
    void rotateAllStatusTokens().catch((error) => {
      logger.error({ error }, "[status] ERROR: status token rotation failed");
    });
  }, ROTATION_INTERVAL_MS);
  rotationTimer.unref();
}

export function stopStatusTokenRotation(): void {
  if (rotationTimer) clearInterval(rotationTimer);
  rotationTimer = null;
}

export const statusTokenPolicy = {
  rotationMinutes: TOKEN_TTL_MS / 60_000,
  graceMinutes: GRACE_TTL_MS / 60_000,
};