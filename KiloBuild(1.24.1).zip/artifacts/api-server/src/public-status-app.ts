import cors from "cors";
import express, { type Express } from "express";
import { existsSync } from "node:fs";
import { join } from "node:path";
import { publicStatusRouter } from "./routes/status.js";

/**
 * A deliberately small public listener. It never mounts the management
 * router, so making the status page reachable from the internet does not
 * make project administration reachable from the internet.
 */
export function createPublicStatusApp(statusUiDir?: string): Express {
  const app = express();
  app.disable("x-powered-by");
  app.use(cors());
  app.use(express.json());

  app.use(publicStatusRouter);
  app.use("/api", publicStatusRouter);

  if (statusUiDir && existsSync(join(statusUiDir, "index.html"))) {
    const statusUi = express.static(statusUiDir, { index: "index.html" });
    app.use(statusUi);
    app.get(["/", "/status/:token"], (_req, res) => {
      res.sendFile(join(statusUiDir, "index.html"));
    });
  }

  return app;
}