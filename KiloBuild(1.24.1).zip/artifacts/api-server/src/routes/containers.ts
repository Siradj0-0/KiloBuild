import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db } from "@workspace/db";
import {
  projectsTable,
  containersTable,
  buildLogsTable,
} from "@workspace/db/schema";
import Dockerode from "dockerode";
import { randomUUID } from "node:crypto";
import { eventBus } from "@workspace/kilobuild-events";
import { ContainerManager } from "@workspace/kilobuild-docker";
import { ImageManager } from "@workspace/kilobuild-docker";
import { getConfigManager } from "@workspace/kilobuild-config";
import { findProject } from "./projects.js";
import { logger } from "../lib/logger.js";

const router: IRouter = Router();

function getDocker(): Dockerode {
  const cfg = getConfigManager().getGlobal();
  return new Dockerode({ socketPath: cfg.dockerSocket });
}

// ── POST /projects/:id/start ──────────────────
router.post("/projects/:id/start", async (req, res) => {
  const project = await findProject(req.params["id"]!);
  if (!project) return res.status(404).json({ error: "Project not found" });

  const docker = getDocker();
  const cm = new ContainerManager(docker);

  try {
    // Check for existing container
    let containerId = await cm.findBySlug(project.slug);

    if (!containerId) {
      // Create container from existing image or build first
      const im = new ImageManager(docker);
      const imageName = im.imageName(project.slug);
      const imageExists = await im.exists(imageName);

      if (!imageExists) {
        return res.status(400).json({
          error: "No image found for this project. Run rebuild first.",
        });
      }

      const projectConfig = getConfigManager().getProject(project.id);
      containerId = await cm.create({
        projectId: project.id,
        projectSlug: project.slug,
        imageName,
        config: projectConfig,
        projectPath: project.path,
      });
    }

    const existing = await cm.inspect(containerId);
    if (existing?.status !== "running" && existing?.status !== "restarting") {
      await cm.start(containerId);
    }

    // Update DB
    const info = await cm.inspect(containerId);
    const [container] = await db
      .insert(containersTable)
      .values({
        projectId: project.id,
        containerId,
        imageId: info?.imageId ?? null,
        imageName: info?.imageName ?? null,
        status: info?.status ?? "running",
        startedAt: info?.startedAt ?? new Date(),
      })
      .onConflictDoUpdate({
        target: containersTable.containerId,
        set: {
          status: sql`EXCLUDED.status`,
          startedAt: sql`EXCLUDED.started_at`,
        },
      })
      .returning();

    await db
      .update(projectsTable)
      .set({ status: "running", lastStartedAt: new Date(), updatedAt: new Date() })
      .where(eq(projectsTable.id, project.id));

    res.json(container);
  } catch (err) {
    req.log.error({ err }, "Failed to start project");
    res.status(500).json({ error: "Failed to start project", detail: String(err) });
  }
  return;
});

// ── POST /projects/:id/stop ───────────────────
router.post("/projects/:id/stop", async (req, res) => {
  const project = await findProject(req.params["id"]!);
  if (!project) return res.status(404).json({ error: "Project not found" });

  const timeout = parseInt(String(req.query["timeout"] ?? "10"), 10);
  const stopTimeout = Number.isInteger(timeout) && timeout > 0 ? timeout : 10;
  const docker = getDocker();
  const cm = new ContainerManager(docker);

  try {
    const containerId = await cm.findBySlug(project.slug);
    if (!containerId) {
      return res.status(400).json({ error: "No container found for this project" });
    }

    await db
      .update(containersTable)
      .set({ lastStopReason: "normal" })
      .where(eq(containersTable.containerId, containerId));
    await cm.stop(containerId, stopTimeout);
    const info = await cm.inspect(containerId);

    // Update DB
    await db
      .update(containersTable)
      .set({ status: info?.status ?? "exited", finishedAt: new Date(), lastStopReason: "normal" })
      .where(eq(containersTable.containerId, containerId));

    await db
      .update(projectsTable)
      .set({ status: "stopped", lastStoppedAt: new Date(), updatedAt: new Date() })
      .where(eq(projectsTable.id, project.id));

    const [container] = await db
      .select()
      .from(containersTable)
      .where(eq(containersTable.containerId, containerId))
      .limit(1);

    res.json(container);
  } catch (err) {
    req.log.error({ err }, "Failed to stop project");
    res.status(500).json({ error: "Failed to stop project", detail: String(err) });
  }
  return;
});

// ── POST /projects/:id/restart ────────────────
router.post("/projects/:id/restart", async (req, res) => {
  const project = await findProject(req.params["id"]!);
  if (!project) return res.status(404).json({ error: "Project not found" });

  const docker = getDocker();
  const cm = new ContainerManager(docker);

  try {
    const containerId = await cm.findBySlug(project.slug);
    if (!containerId) {
      return res.status(400).json({ error: "No container found for this project" });
    }

    await cm.restart(containerId);
    const info = await cm.inspect(containerId);

    await db
      .update(containersTable)
      .set({ status: info?.status ?? "running", startedAt: new Date(), lastStopReason: "unknown" })
      .where(eq(containersTable.containerId, containerId));

    await db
      .update(projectsTable)
      .set({ status: "running", lastStartedAt: new Date(), updatedAt: new Date() })
      .where(eq(projectsTable.id, project.id));

    const [container] = await db
      .select()
      .from(containersTable)
      .where(eq(containersTable.containerId, containerId))
      .limit(1);

    res.json(container);
  } catch (err) {
    req.log.error({ err }, "Failed to restart project");
    res.status(500).json({ error: "Failed to restart project", detail: String(err) });
  }
  return;
});

// ── POST /projects/:id/rebuild ────────────────
router.post("/projects/:id/rebuild", async (req, res) => {
  const project = await findProject(req.params["id"]!);
  if (!project) return res.status(404).json({ error: "Project not found" });

  const docker = getDocker();
  const cm = new ContainerManager(docker);
  const im = new ImageManager(docker);
  const projectConfig = getConfigManager().getProject(project.id);
  const buildId = randomUUID();
  const startedAt = new Date();

  await db.insert(buildLogsTable).values({
    id: buildId,
    projectId: project.id,
    status: "pending",
    imageName: im.imageName(project.slug),
    logs: [],
    startedAt,
  });

  await db
    .update(projectsTable)
    .set({ status: "building", updatedAt: new Date() })
    .where(eq(projectsTable.id, project.id));

  // Fire-and-forget: respond 202 immediately, rebuild in background
  res.status(202).json({
    projectId: project.id,
    buildId,
    status: "pending",
    imageId: null,
    imageName: im.imageName(project.slug),
    startedAt: startedAt.toISOString(),
    finishedAt: null,
    durationMs: null,
    error: null,
    logs: [],
  });

  // Background build
  im.build({
    buildId,
    projectId: project.id,
    projectSlug: project.slug,
    contextPath: project.path,
    buildArgs: projectConfig.buildArgs,
    onLog: (line) => logger.debug({ project: project.slug, line }, "build"),
  })
    .then(async (result) => {
      await db
        .update(buildLogsTable)
        .set({
          status: result.status,
          imageId: result.imageId,
          imageName: result.imageName,
          logs: result.logs,
          startedAt: result.startedAt,
          finishedAt: result.finishedAt,
          durationMs: result.durationMs,
          error: result.error,
        })
        .where(eq(buildLogsTable.id, buildId));
      if (result.status === "success") {
        const oldContainerId = await cm.findBySlug(project.slug);
        if (oldContainerId) {
          await cm.remove(oldContainerId, true);
          await db
            .delete(containersTable)
            .where(eq(containersTable.containerId, oldContainerId));
        }

        const containerId = await cm.create({
          projectId: project.id,
          projectSlug: project.slug,
          imageName: im.imageName(project.slug),
          config: projectConfig,
          projectPath: project.path,
        });
        await cm.start(containerId);
        const info = await cm.inspect(containerId);

        await db
          .insert(containersTable)
          .values({
            projectId: project.id,
            containerId,
            imageId: info?.imageId ?? result.imageId,
            imageName: info?.imageName ?? im.imageName(project.slug),
            status: info?.status ?? "running",
            startedAt: info?.startedAt ?? new Date(),
          })
          .onConflictDoUpdate({
            target: containersTable.containerId,
            set: {
              status: sql`excluded.status`,
              imageId: sql`excluded.image_id`,
              imageName: sql`excluded.image_name`,
              startedAt: sql`excluded.started_at`,
            },
          });

        await db
          .update(projectsTable)
          .set({ status: "running", lastStartedAt: new Date(), updatedAt: new Date() })
          .where(eq(projectsTable.id, project.id));
        logger.info({ project: project.slug, containerId }, "Build and restart succeeded");
      } else {
        await db
          .update(projectsTable)
          .set({ status: "error", updatedAt: new Date() })
          .where(eq(projectsTable.id, project.id));
        logger.error({ project: project.slug, error: result.error }, "Build failed");
      }
    })
    .catch(async (err) => {
      await db
        .update(buildLogsTable)
        .set({
          status: "failed",
          finishedAt: new Date(),
          error: String(err),
        })
        .where(eq(buildLogsTable.id, buildId));
      logger.error({ err }, "Rebuild threw an error");
    });
  return;
});

// ── GET /projects/:id/builds/:buildId ──────────
router.get("/projects/:id/builds/:buildId", async (req, res) => {
  const project = await findProject(req.params["id"]!);
  if (!project) return res.status(404).json({ error: "Project not found" });

  const [build] = await db
    .select()
    .from(buildLogsTable)
    .where(eq(buildLogsTable.id, req.params["buildId"]!))
    .limit(1);
  if (!build || build.projectId !== project.id) {
    return res.status(404).json({ error: "Build not found" });
  }
  res.json(build);
  return;
});

// ── POST /projects/:id/exec ────────────────────
router.post("/projects/:id/exec", async (req, res) => {
  const project = await findProject(req.params["id"]!);
  if (!project) return res.status(404).json({ error: "Project not found" });

  const cmd: string[] = Array.isArray(req.body?.cmd)
    ? req.body.cmd.filter((part: unknown): part is string => typeof part === "string")
    : typeof req.body?.cmd === "string"
      ? req.body.cmd.trim().split(/\s+/)
      : [];
  if (cmd.length === 0) return res.status(400).json({ error: "cmd is required" });
  if (cmd.length > 64 || cmd.some((part: string) => part.length > 4096)) {
    return res.status(400).json({ error: "Command is too large" });
  }

  try {
    const docker = getDocker();
    const cm = new ContainerManager(docker);
    const containerId = await cm.findBySlug(project.slug);
    if (!containerId) return res.status(400).json({ error: "No container found for this project" });
    const result = await cm.exec(containerId, cmd);
    eventBus.emit("container:exec", project.id, {
      command: cmd,
      timestamp: new Date().toISOString(),
      exitCode: result.exitCode,
    });
    res.json({ projectId: project.id, command: cmd, ...result });
  } catch (err) {
    res.status(500).json({ error: "Exec failed", detail: String(err) });
  }
  return;
});

export default router;
