import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db } from "@workspace/db";
import { backupsTable } from "@workspace/db/schema";
import { BackupManager } from "@workspace/kilobuild-backup";
import { getConfigManager } from "@workspace/kilobuild-config";
import { findProject } from "./projects.js";

const router: IRouter = Router();

function getBackupManager(): BackupManager {
  const cfg = getConfigManager().getGlobal();
  return new BackupManager(cfg.backupDir);
}

// ── GET /projects/:id/backups ─────────────────
router.get("/projects/:id/backups", async (req, res) => {
  const project = await findProject(req.params["id"]!);
  if (!project) return res.status(404).json({ error: "Project not found" });

  try {
    const backups = await db
      .select()
      .from(backupsTable)
      .where(eq(backupsTable.projectId, project.id))
      .orderBy(backupsTable.createdAt);

    res.json(backups);
  } catch (err) {
    res.status(500).json({ error: "Failed to list backups", detail: String(err) });
  }
  return;
});

// ── POST /projects/:id/backups ────────────────
router.post("/projects/:id/backups", async (req, res) => {
  const project = await findProject(req.params["id"]!);
  if (!project) return res.status(404).json({ error: "Project not found" });

  const { name, notes, includesLogs } = req.body as {
    name?: string;
    notes?: string;
    includesLogs?: boolean;
  };

  try {
    // Insert a "creating" record first
    const [record] = await db
      .insert(backupsTable)
      .values({
        projectId: project.id,
        name: name ?? `backup-${Date.now()}`,
        path: "",
        status: "creating",
        includesLogs: includesLogs ?? false,
        notes: notes ?? null,
      })
      .returning();

    res.status(202).json(record);

    // Perform backup in background
    const bm = getBackupManager();
    bm.create(project.id, project.path, { name, notes, includesLogs })
      .then(async (backup) => {
        await db
          .update(backupsTable)
          .set({
            path: backup.path,
            sizeBytes: backup.sizeBytes,
            status: backup.status,
          })
          .where(eq(backupsTable.id, record.id));
      })
      .catch(async (err) => {
        await db
          .update(backupsTable)
          .set({ status: "failed" })
          .where(eq(backupsTable.id, record.id));
        req.log?.error({ err }, "Backup failed");
      });
  } catch (err) {
    res.status(500).json({ error: "Failed to create backup", detail: String(err) });
  }
  return;
});

// ── POST /projects/:id/backups/:backupId/restore ──
router.post("/projects/:id/backups/:backupId/restore", async (req, res) => {
  const project = await findProject(req.params["id"]!);
  if (!project) return res.status(404).json({ error: "Project not found" });

  try {
    const [backup] = await db
      .select()
      .from(backupsTable)
      .where(eq(backupsTable.id, req.params["backupId"]!))
      .limit(1);

    if (!backup) return res.status(404).json({ error: "Backup not found" });
    if (backup.projectId !== project.id) {
      return res.status(404).json({ error: "Backup not found" });
    }

    res.status(202).json(backup);

    // Restore in background
    const bm = getBackupManager();
    const mapped = {
      id: backup.id,
      projectId: backup.projectId,
      name: backup.name,
      path: backup.path,
      sizeBytes: backup.sizeBytes ?? null,
      includesLogs: backup.includesLogs,
      createdAt: backup.createdAt,
      notes: backup.notes ?? null,
      status: backup.status as "creating" | "ready" | "failed" | "deleted",
    };

    bm.restore(mapped, project.path).catch((err) => {
      req.log?.error({ err }, "Restore failed");
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to restore backup", detail: String(err) });
  }
  return;
});

export default router;
