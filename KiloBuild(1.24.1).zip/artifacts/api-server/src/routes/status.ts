import { Router, type IRouter, type Request } from "express";
import { desc, eq } from "drizzle-orm";
import { db, containersTable, projectsTable } from "@workspace/db";
import { getConfigManager } from "@workspace/kilobuild-config";
import { ensureStatusToken, resolveStatusToken } from "../status-tokens.js";

const router: IRouter = Router();

export const publicStatusRouter: IRouter = Router();

function publicStatus(container: typeof containersTable.$inferSelect | null) {
  if (!container) return "offline";
  switch (container.status) {
    case "running":
      return "online";
    case "created":
    case "restarting":
      return "starting";
    case "paused":
    case "removing":
      return "stopping";
    case "exited":
    case "dead":
    default:
      return "offline";
  }
}

export async function buildStatusDashboard(projectId: string) {
  const [project] = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, projectId))
    .limit(1);
  if (!project) return null;

  const [container] = await db
    .select()
    .from(containersTable)
    .where(eq(containersTable.projectId, project.id))
    .orderBy(desc(containersTable.createdAt))
    .limit(1);
  const state = publicStatus(container ?? null);
  const uptimeSeconds =
    state === "online" && container?.startedAt
      ? Math.max(0, Math.floor((Date.now() - container.startedAt.getTime()) / 1000))
      : 0;

  return {
    project: {
      id: project.id,
      name: project.name,
      slug: project.slug,
      description: project.description,
      projectType: project.projectType,
      nodeVersion: project.nodeVersion,
    },
    status: state,
    container: container
      ? {
          containerId: container.containerId,
          status: container.status,
          startedAt: container.startedAt,
          finishedAt: container.finishedAt,
          exitCode: container.exitCode,
          restartCount: container.restartCount,
          error: container.error,
          lastStopReason: container.lastStopReason,
        }
      : null,
    lastStopReason: container?.lastStopReason ?? null,
    uptimeSeconds,
    checkedAt: new Date(),
    health: {
      status: state === "online" ? "unknown" : state === "starting" ? "starting" : "unknown",
      message: null,
      responseTimeMs: null,
    },
  };
}

function publicBaseUrl(req: Request): string {
  const configured = getConfigManager().getGlobal().publicBaseUrl
    ?? process.env["KILOBUILD_PUBLIC_BASE_URL"];
  if (configured) return configured.replace(/\/+$/, "");

  const forwardedProto = req.header("x-forwarded-proto")?.split(",")[0]?.trim();
  return `${forwardedProto || req.protocol}://${req.get("host")}`;
}

// Public by design: the rotating token is the credential for this route.
async function getPublicStatus(req: Request, res: import("express").Response) {
  const rawToken = req.params["token"];
  const token = Array.isArray(rawToken) ? rawToken[0] ?? "" : rawToken ?? "";
  const resolved = await resolveStatusToken(token, req.ip ?? "");
  if (!resolved) {
    res.status(404).json({ error: "Status page not found" });
    return;
  }

  const dashboard = await buildStatusDashboard(resolved.projectId);
  if (!dashboard) {
    res.status(404).json({ error: "Status page not found" });
    return;
  }
  res.setHeader("Cache-Control", "no-store");
  res.json(dashboard);
}

// The token is the credential for these deliberately narrow, read-only
// dashboard data routes. They are mounted on both the private API app (for
// local development) and the optional public status-only listener.
router.get("/status/:token", getPublicStatus);
publicStatusRouter.get("/status/:token", getPublicStatus);

// Dedicated KiloBuilder-only route. The token is intentionally not accepted
// by the general API auth middleware.
router.get("/internal/status-url/:projectId", async (req, res) => {
  const configured = getConfigManager().getGlobal().internalToken;
  const header = req.header("authorization");
  const supplied = header?.startsWith("Bearer ") ? header.slice(7) : null;
  if (!configured || !supplied || supplied !== configured) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const [project] = await db
    .select({ id: projectsTable.id })
    .from(projectsTable)
    .where(eq(projectsTable.id, req.params["projectId"]!))
    .limit(1);
  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const token = await ensureStatusToken(project.id);
  const base = publicBaseUrl(req);
  res.json({
    projectId: project.id,
    url: `${base}/status/${token.currentToken}`,
    expiresAt: token.currentExpiresAt,
  });
});

export default router;