import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { projectsTable } from "@workspace/db/schema";
import { BackupManager } from "@workspace/kilobuild-backup";
import { LogManager } from "@workspace/kilobuild-logging";
import { getConfigManager } from "@workspace/kilobuild-config";

const router: IRouter = Router();

router.get("/disk", async (_req, res) => {
  try {
    const projects = await db.select().from(projectsTable);
    const cfg = getConfigManager().getGlobal();
    const backups = new BackupManager(cfg.backupDir);
    const logs = new LogManager(cfg.logDir);
    const usage = await Promise.all(projects.map(async (project) => {
      const backupBytes = await backups.totalSize(project.id);
      const logBytes = logs.getLogSizeBytes(project.id);
      return {
        projectId: project.id,
        name: project.name,
        backupBytes,
        logBytes,
        totalBytes: backupBytes + logBytes,
      };
    }));
    res.json(usage);
  } catch (err) {
    res.status(500).json({ error: "Failed to calculate disk usage", detail: String(err) });
  }
});

export default router;