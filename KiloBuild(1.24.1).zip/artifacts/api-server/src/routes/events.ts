import { Router, type IRouter } from "express";
import { and, eq, desc } from "drizzle-orm";
import { db } from "@workspace/db";
import { eventsLogTable } from "@workspace/db/schema";
import { eventBus } from "@workspace/kilobuild-events";
import type { KiloBuildEvent } from "@workspace/kilobuild-types";
import { findProject } from "./projects.js";

const router: IRouter = Router();

// Persist all events to DB
eventBus.on("*", async (event: KiloBuildEvent) => {
  try {
    await db.insert(eventsLogTable).values({
      projectId: event.projectId,
      eventType: event.type,
      payload: event.payload as Record<string, unknown>,
    });
  } catch {
    // Non-fatal – event logging should never crash the daemon
  }
});

// ── GET /events ───────────────────────────────
router.get("/events", async (req, res) => {
  const limit = parseInt(String(req.query["limit"] ?? "100"), 10);
  const projectId = req.query["projectId"] as string | undefined;
  const type = req.query["type"] as string | undefined;

  try {
    const resolvedProject = projectId ? await findProject(projectId) : null;
    const resolvedProjectId = resolvedProject?.id ?? projectId;
    let query = db
      .select()
      .from(eventsLogTable)
      .orderBy(desc(eventsLogTable.createdAt))
      .limit(Math.min(limit, 1000));

    const filters = [];
    if (resolvedProjectId) filters.push(eq(eventsLogTable.projectId, resolvedProjectId));
    if (type) filters.push(eq(eventsLogTable.eventType, type));
    if (filters.length > 0) query = query.where(and(...filters)) as typeof query;

    const events = await query;
    res.json(events.reverse()); // Return in chronological order
  } catch (err) {
    res.status(500).json({ error: "Failed to list events", detail: String(err) });
  }
});

export default router;
