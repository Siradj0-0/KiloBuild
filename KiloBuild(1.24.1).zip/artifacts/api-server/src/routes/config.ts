import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db } from "@workspace/db";
import { projectConfigsTable } from "@workspace/db/schema";
import { getConfigManager, projectConfigSchema } from "@workspace/kilobuild-config";
import { findProject } from "./projects.js";

const router: IRouter = Router();

// ── GET /projects/:id/config ──────────────────
router.get("/projects/:id/config", async (req, res) => {
  const project = await findProject(req.params["id"]!);
  if (!project) return res.status(404).json({ error: "Project not found" });

  const config = getConfigManager().getProject(project.id);
  res.json(config);
  return;
});

// ── PUT /projects/:id/config ──────────────────
router.put("/projects/:id/config", async (req, res) => {
  const project = await findProject(req.params["id"]!);
  if (!project) return res.status(404).json({ error: "Project not found" });

  const parsed = projectConfigSchema.partial().safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Validation failed", detail: parsed.error.message });
  }

  try {
    const updated = await getConfigManager().setProject(project.id, parsed.data);
    await db
      .update(projectConfigsTable)
      .set({ ...parsed.data, updatedAt: new Date() })
      .where(eq(projectConfigsTable.projectId, project.id));
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: "Failed to update config", detail: String(err) });
  }
  return;
});

// ── GET /config ───────────────────────────────
router.get("/config", (_req, res) => {
  const config = getConfigManager().getGlobal();
  // Never expose either bearer credential through the API.
  res.json({
    ...config,
    apiSecret: config.apiSecret ? "***" : null,
    internalToken: config.internalToken ? "***" : null,
  });
});

// ── PUT /config ───────────────────────────────
router.put("/config", async (req, res) => {
  try {
    const updated = await getConfigManager().setGlobal(req.body as Record<string, unknown>);
    res.json({
      ...updated,
      apiSecret: updated.apiSecret ? "***" : null,
      internalToken: updated.internalToken ? "***" : null,
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to update global config", detail: String(err) });
  }
});

export default router;
