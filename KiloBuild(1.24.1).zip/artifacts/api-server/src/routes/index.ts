import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import projectsRouter from "./projects.js";
import containersRouter from "./containers.js";
import statsRouter from "./stats.js";
import logsRouter from "./logs.js";
import backupsRouter from "./backups.js";
import configRouter from "./config.js";
import discoveryRouter from "./discovery.js";
import eventsRouter from "./events.js";
import doctorRouter from "./doctor.js";
import pluginsRouter from "./plugins.js";
import operationsRouter from "./operations.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use(projectsRouter);
router.use(containersRouter);
router.use(statsRouter);
router.use(logsRouter);
router.use(backupsRouter);
router.use(configRouter);
router.use(discoveryRouter);
router.use(eventsRouter);
router.use(doctorRouter);
router.use(pluginsRouter);
router.use(operationsRouter);

export default router;
