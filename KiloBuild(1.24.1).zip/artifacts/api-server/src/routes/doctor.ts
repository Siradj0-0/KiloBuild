import { Router, type IRouter } from "express";
import { pingDocker, getDockerVersion } from "@workspace/kilobuild-docker";
import { getConfigManager } from "@workspace/kilobuild-config";
import { db } from "@workspace/db";
import { projectsTable, projectConfigsTable } from "@workspace/db/schema";
import { eq, inArray, sql } from "drizzle-orm";
import { existsSync } from "node:fs";
import type { DiagnosticCheck, DoctorReport } from "@workspace/kilobuild-types";

const router: IRouter = Router();

// ── GET /doctor ───────────────────────────────
router.get("/doctor", async (_req, res) => {
  const checks: DiagnosticCheck[] = [];
  const cfg = getConfigManager().getGlobal();

  // 1. Docker daemon
  try {
    const alive = await pingDocker(cfg);
    if (alive) {
      const ver = await getDockerVersion(cfg);
      checks.push({
        name: "Docker Daemon",
        status: "ok",
        message: `Docker ${ver.version} (API ${ver.apiVersion}) on ${ver.os}/${ver.arch}`,
      });
    } else {
      checks.push({
        name: "Docker Daemon",
        status: "error",
        message: "Docker daemon is not reachable",
        detail: `Socket: ${cfg.dockerSocket}`,
      });
    }
  } catch (err) {
    checks.push({
      name: "Docker Daemon",
      status: "error",
      message: "Failed to connect to Docker",
      detail: String(err),
    });
  }

  // 2. Database
  try {
    await db.run(sql`SELECT 1`);
    checks.push({ name: "Database", status: "ok", message: "Embedded SQLite database is ready" });
  } catch (err) {
    checks.push({
      name: "Database",
      status: "error",
      message: "Embedded SQLite database is unavailable",
      detail: String(err),
    });
  }

  // 3. Data directories
  for (const [name, dir] of [
    ["Data Dir", cfg.dataDir],
    ["Log Dir", cfg.logDir],
    ["Backup Dir", cfg.backupDir],
  ]) {
    if (existsSync(dir)) {
      checks.push({ name, status: "ok", message: `${dir} exists` });
    } else {
      checks.push({
        name,
        status: "warning",
        message: `${dir} does not exist`,
        detail: "Will be created on first use",
      });
    }
  }

  // 4. Resource isolation
  try {
    const activeProjects = await db
      .select({
        name: projectsTable.name,
        memoryLimit: projectConfigsTable.memoryLimit,
      })
      .from(projectsTable)
      .leftJoin(projectConfigsTable, eq(projectConfigsTable.projectId, projectsTable.id))
      .where(inArray(projectsTable.status, ["running", "building"]));
    const missing = activeProjects.filter((p) => !p.memoryLimit);
    checks.push(
      missing.length === 0
        ? {
            name: "Project memory limits",
            status: "ok",
            message: "All active projects have a memory limit",
          }
        : {
            name: "Project memory limits",
            status: "warning",
            message: `${missing.length} active project(s) have no memory limit`,
            detail: missing.map((p) => p.name).join(", "),
          },
    );
  } catch (err) {
    checks.push({
      name: "Project memory limits",
      status: "warning",
      message: "Unable to verify active project memory limits",
      detail: String(err),
    });
  }

  // 5. Node version
  const nodeVer = process.version;
  const [major] = nodeVer.slice(1).split(".");
  const majorNum = parseInt(major ?? "0", 10);
  if (majorNum >= 20) {
    checks.push({ name: "Node.js", status: "ok", message: `Node ${nodeVer}` });
  } else {
    checks.push({
      name: "Node.js",
      status: "warning",
      message: `Node ${nodeVer} – recommend Node 20+`,
    });
  }

  const overall = checks.some((c) => c.status === "error")
    ? "error"
    : checks.some((c) => c.status === "warning")
      ? "warning"
      : "ok";

  const report: DoctorReport = {
    overall,
    checks,
    generatedAt: new Date(),
  };

  res.json(report);
});

export default router;
