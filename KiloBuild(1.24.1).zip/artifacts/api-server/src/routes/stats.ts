import { Router, type IRouter } from "express";
import { eq, count } from "drizzle-orm";
import { db } from "@workspace/db";
import { projectsTable } from "@workspace/db/schema";
import Dockerode from "dockerode";
import { StatsCollector } from "@workspace/kilobuild-docker";
import { ContainerManager } from "@workspace/kilobuild-docker";
import { ContainerMonitor } from "@workspace/kilobuild-monitor";
import { getConfigManager } from "@workspace/kilobuild-config";
import { findProject } from "./projects.js";

const router: IRouter = Router();

// Shared monitor instance (one per process)
let _monitor: ContainerMonitor | null = null;
function getMonitor(): ContainerMonitor {
  if (!_monitor) _monitor = new ContainerMonitor();
  return _monitor;
}

function getDocker(): Dockerode {
  return new Dockerode({ socketPath: getConfigManager().getGlobal().dockerSocket });
}

// ── GET /projects/:id/stats ───────────────────
router.get("/projects/:id/stats", async (req, res) => {
  const project = await findProject(req.params["id"]!);
  if (!project) return res.status(404).json({ error: "Project not found" });

  // Try live stats from monitor first
  const monitor = getMonitor();
  const cached = monitor.getStats(project.id);
  if (cached) return res.json(cached);

  // Fall back to single collection
  const docker = getDocker();
  const cm = new ContainerManager(docker);
  const containerId = await cm.findBySlug(project.slug);

  if (!containerId) {
    return res.status(404).json({ error: "No running container for this project" });
  }

  const sc = new StatsCollector(docker);
  const stats = await sc.collect(containerId, project.id);

  if (!stats) {
    return res.status(503).json({ error: "Stats not available (container may be stopped)" });
  }

  res.json(stats);
  return;
});

// ── GET /projects/:id/health ──────────────────
router.get("/projects/:id/health", async (req, res) => {
  const project = await findProject(req.params["id"]!);
  if (!project) return res.status(404).json({ error: "Project not found" });

  const monitor = getMonitor();
  const cached = monitor.getHealth(project.id);
  if (cached) return res.json(cached);

  // Inspect Docker health status
  const docker = getDocker();
  const cm = new ContainerManager(docker);
  const containerId = await cm.findBySlug(project.slug);

  if (!containerId) {
    return res.json({
      projectId: project.id,
      status: "unknown",
      message: "No container running",
      checkedAt: new Date().toISOString(),
      responseTimeMs: null,
    });
  }

  const result = await monitor.inspectHealth(containerId, project.id);
  res.json(result);
  return;
});

// ── GET /stats ────────────────────────────────
router.get("/stats", async (_req, res) => {
  try {
    const [rows] = await db
      .select({
        total: count(),
      })
      .from(projectsTable);

    const byStatus = await db
      .select({ status: projectsTable.status, cnt: count() })
      .from(projectsTable)
      .groupBy(projectsTable.status);

    const counts: Record<string, number> = {};
    for (const row of byStatus) counts[row.status] = Number(row.cnt);

    const monitor = getMonitor();
    const summary = monitor.globalSummary();
    const projects = await db.select({
      projectId: projectsTable.id,
      name: projectsTable.name,
      status: projectsTable.status,
    }).from(projectsTable);
    const fleet = projects.map((project) => {
      const stats = monitor.getStats(project.projectId);
      return {
        ...project,
        cpuPercent: stats?.cpuPercent ?? 0,
        memoryUsedBytes: stats?.memoryUsedBytes ?? 0,
        memoryLimitBytes: stats?.memoryLimitBytes ?? 0,
        memoryPercent: stats?.memoryPercent ?? 0,
      };
    });

    res.json({
      totalProjects: Number(rows?.total ?? 0),
      runningProjects: counts["running"] ?? 0,
      stoppedProjects: counts["stopped"] ?? 0,
      errorProjects: counts["error"] ?? 0,
      totalContainers: summary.monitoredCount,
      totalCpuPercent: summary.totalCpuPercent,
      totalMemoryUsedBytes: summary.totalMemoryUsedBytes,
      uptimeSecs: Math.floor(process.uptime()),
      projects: fleet,
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to get stats", detail: String(err) });
  }
  return;
});

export default router;
