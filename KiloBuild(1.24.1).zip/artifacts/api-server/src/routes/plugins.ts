import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db } from "@workspace/db";
import { pluginsRegistryTable } from "@workspace/db/schema";
import { getConfigManager } from "@workspace/kilobuild-config";
import { PluginManager, createDiscordWebhookPlugin } from "@workspace/kilobuild-plugins";

const router: IRouter = Router();

let _pluginManager: PluginManager | null = null;
let _pluginsInitialized = false;
function getPluginManager(): PluginManager {
  if (!_pluginManager) {
    const cfg = getConfigManager().getGlobal();
    _pluginManager = new PluginManager(cfg.pluginsDir);
  }
  return _pluginManager;
}

export async function initializePlugins(): Promise<void> {
  if (_pluginsInitialized) return;
  const manager = getPluginManager();
  const cfg = getConfigManager().getGlobal();
  if (cfg.discordWebhookUrl) {
    await manager.loadDefinition(createDiscordWebhookPlugin(cfg.discordWebhookUrl));
  }
  await manager.loadAll();
  _pluginsInitialized = true;
}

// ── GET /plugins ──────────────────────────────
router.get("/plugins", async (_req, res) => {
  try {
    const rows = await db.select().from(pluginsRegistryTable);
    const runtime = getPluginManager().list();

    // Merge DB record with runtime status
    const merged = rows.map((row) => {
      const live = runtime.find((p) => p.name === row.name);
      return {
        id: row.id,
        name: row.name,
        version: live?.version ?? row.version,
        description: row.description ?? live?.description ?? null,
        enabled: row.enabled,
        status: live?.status ?? (row.enabled ? "active" : "inactive"),
        installedAt: row.installedAt,
      };
    });

    res.json(merged);
  } catch (err) {
    res.status(500).json({ error: "Failed to list plugins", detail: String(err) });
  }
  return;
});

// ── POST /plugins/:name/enable ────────────────
router.post("/plugins/:name/enable", async (req, res) => {
  const { name } = req.params;
  try {
    const [row] = await db
      .select()
      .from(pluginsRegistryTable)
      .where(eq(pluginsRegistryTable.name, name!))
      .limit(1);

    if (!row) return res.status(404).json({ error: "Plugin not found" });

    await db
      .update(pluginsRegistryTable)
      .set({ enabled: true, status: "active" })
      .where(eq(pluginsRegistryTable.name, name!));

    getPluginManager().setEnabled(name!, true);

    res.json({ ...row, enabled: true, status: "active" });
  } catch (err) {
    res.status(500).json({ error: "Failed to enable plugin", detail: String(err) });
  }
  return;
});

// ── POST /plugins/:name/disable ───────────────
router.post("/plugins/:name/disable", async (req, res) => {
  const { name } = req.params;
  try {
    const [row] = await db
      .select()
      .from(pluginsRegistryTable)
      .where(eq(pluginsRegistryTable.name, name!))
      .limit(1);

    if (!row) return res.status(404).json({ error: "Plugin not found" });

    await db
      .update(pluginsRegistryTable)
      .set({ enabled: false, status: "inactive" })
      .where(eq(pluginsRegistryTable.name, name!));

    getPluginManager().setEnabled(name!, false);

    res.json({ ...row, enabled: false, status: "inactive" });
  } catch (err) {
    res.status(500).json({ error: "Failed to disable plugin", detail: String(err) });
  }
  return;
});

export default router;
