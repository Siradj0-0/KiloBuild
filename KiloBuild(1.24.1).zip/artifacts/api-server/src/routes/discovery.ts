import { Router, type IRouter } from "express";
import { scanForProjects } from "@workspace/kilobuild-discovery";
import { db } from "@workspace/db";
import { projectsTable } from "@workspace/db/schema";

const router: IRouter = Router();

// ── POST /discover ────────────────────────────
router.post("/discover", async (req, res) => {
  const { roots, maxDepth } = req.body as { roots?: string[]; maxDepth?: number };

  if (!roots || !Array.isArray(roots) || roots.length === 0) {
    return res.status(400).json({ error: "roots array is required" });
  }

  try {
    // Get all managed slugs so discovery can mark duplicates
    const managed = await db.select({ slug: projectsTable.slug }).from(projectsTable);
    const managedSlugs = new Set(managed.map((m) => m.slug));

    const discovered = await scanForProjects({
      roots,
      maxDepth: maxDepth ?? 3,
      managedSlugs,
    });

    res.json(discovered);
  } catch (err) {
    res.status(500).json({ error: "Discovery failed", detail: String(err) });
  }
  return;
});

export default router;
