# KiloBuild

A production-grade self-hosted platform for deploying, managing, monitoring, and maintaining unlimited Node.js applications (and Discord bots) inside isolated Docker containers. Think PM2 + Coolify + Docker Compose — focused on Node.js, designed to scale from 1 to 1000+ projects.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the KiloBuild management daemon (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes when needed (the embedded database also initializes automatically)
- `pnpm --filter @workspace/kilobuild-cli run build` — build the `kilo` CLI binary to `lib/kilobuild-cli/dist/index.mjs`
- Database storage: embedded SQLite at `.kilobuild/kilobuild.sqlite` (override with `KILOBUILD_DATA_DIR` or `KILOBUILD_DB_PATH`)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5 (KiloBuild management daemon)
- Docker: Dockerode (Docker Engine API)
- DB: embedded SQLite + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- CLI: commander + chalk + ora + cli-table3
- Build: esbuild (CJS bundle for API server)

## Where things live

```
lib/kilobuild-types/         Shared TypeScript interfaces (no runtime deps)
lib/kilobuild-events/        Type-safe singleton event bus
lib/kilobuild-cache/         TTL-aware in-memory + disk-backed cache
lib/kilobuild-config/        Zod-validated global + per-project config system
lib/kilobuild-docker/        Dockerode wrapper: container, image, stats, event watcher
lib/kilobuild-discovery/     File-system project auto-detector
lib/kilobuild-templates/     Dockerfile / docker-compose / startup.sh generator
lib/kilobuild-monitor/       Container stats streaming + HTTP health checks
lib/kilobuild-logging/       Per-project structured log files, rotation, tailing
lib/kilobuild-recovery/      Self-healing restart policies + exponential backoff
lib/kilobuild-backup/        tar.gz backup + restore system
lib/kilobuild-plugins/       Dynamic plugin loader + lifecycle hook bridge
lib/kilobuild-cli/           kilo CLI (commander, chalk, ora, cli-table3)
lib/db/src/schema/           Drizzle ORM table definitions (source of truth for DB)
lib/api-spec/openapi.yaml    OpenAPI spec (source of truth for REST API)
artifacts/api-server/        KiloBuild management daemon (Express 5)
ARCHITECTURE.md              Full architecture document with diagrams
```

## Architecture decisions

- **Event-driven**: all subsystems communicate through a singleton `KiloBuildEventBus`; never import each other directly.
- **Config hierarchy**: global defaults → per-project overrides (in-process) → `kilobuild.json` in project root.
- **API-only CLI**: the `kilo` CLI only calls the REST API; it never touches Docker or the database directly.
- **Labels for discovery**: all KiloBuild containers are labelled `kilobuild.managed=true` so the Docker event stream can be filtered cheaply.
- **Async background jobs**: rebuild and backup respond immediately with 202 and execute in the background.
- **Backoff with jitter**: restart delay = `base × multiplier^attempt ± 20%` to prevent thundering herd.

## Product

KiloBuild allows a developer or small team to:
1. **Import any Node.js project** into KiloBuild with a single command
2. **Automatically generate** a production Dockerfile, docker-compose.yml, and startup layer
3. **Start/stop/restart/rebuild** projects as Docker containers
4. **Monitor** CPU, memory, network, and health status in real time
5. **View logs** per project, with rotation and retention
6. **Self-heal** crashed containers with configurable backoff
7. **Back up and restore** entire projects including volumes
8. **Extend** the platform with plugins that hook into any lifecycle event

## User preferences

- Build everything as production-quality TypeScript; no mocked data, no placeholders.
- No hardcoded project names or arbitrary limits anywhere.
- The daemon API binds to 127.0.0.1 by default (not 0.0.0.0).

## Gotchas

- After adding a new lib package, add it to `tsconfig.json` references AND the consuming package's `tsconfig.json` references.
- The `kilobuild-types` package has no runtime dependencies — keep it that way.
- Run `pnpm --filter @workspace/api-spec run codegen` after every OpenAPI spec change.
- Docker must be running on the host for any container operation to work.
- The `kilo` CLI reads `KILOBUILD_API_URL` env var to find the daemon (default: `http://127.0.0.1:3001/api`).

## Pointers

- See `ARCHITECTURE.md` for full system design, data models, lifecycle diagrams, and roadmap.
- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
