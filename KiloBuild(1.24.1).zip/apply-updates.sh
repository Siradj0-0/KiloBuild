#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# KiloBuild — apply all session changes to your VPS checkout
# Run from inside your KiloBuild repo directory:
#   cd /path/to/kilobuild && bash apply-updates.sh
# ─────────────────────────────────────────────────────────────────────────────
set -e

REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "📁 Repo root: $REPO"

# ── 1. artifacts/api-server/src/middlewares/auth.ts ──────────────────────────
# FIX: no apiSecret set = open access (restored); status-token exception kept
mkdir -p "$REPO/artifacts/api-server/src/middlewares"
cat > "$REPO/artifacts/api-server/src/middlewares/auth.ts" << 'KEOF'
import type { RequestHandler } from "express";
import { getConfigManager } from "@workspace/kilobuild-config";
import { resolveStatusToken } from "../status-tokens.js";

/**
 * The daemon is operator-only, but a bearer check prevents accidental exposure
 * if a host/VPN binding is changed later.
 */
export const apiAuth: RequestHandler = async (req, res, next) => {
  const secret = getConfigManager().getGlobal().apiSecret;

  // No secret configured → open access (normal operator setup).
  if (!secret) {
    next();
    return;
  }

  // Secret is set — enforce bearer token.
  const header = req.header("authorization");
  const token = header?.startsWith("Bearer ") ? header.slice(7) : null;
  if (token === secret) {
    next();
    return;
  }

  // The public dashboard can operate its own project without exposing the
  // admin API secret. This narrow exception only applies to the three
  // lifecycle mutations and requires a valid, project-specific status token.
  const statusToken = req.header("x-kilobuild-status-token");
  const match = req.path.match(/^\/projects\/([^/]+)\/(start|stop|restart)$/);
  if (req.method === "POST" && statusToken && match) {
    const resolved = await resolveStatusToken(statusToken, req.ip ?? "");
    if (resolved?.projectId === match[1]) {
      next();
      return;
    }
  }

  res.status(401).json({ error: "Unauthorized" });
};
KEOF
echo "✔  artifacts/api-server/src/middlewares/auth.ts"

# ── 2. artifacts/api-server/src/routes/config.ts ──────────────────────────────
# FIX: never expose either bearer credential through the config API response
python3 - "$REPO/artifacts/api-server/src/routes/config.ts" <<'PYEOF'
from pathlib import Path
import sys

path = Path(sys.argv[1])
src = path.read_text()
old_get = '  // Mask API secret\n  res.json({ ...config, apiSecret: config.apiSecret ? "***" : null });'
new_get = '''  // Never expose either bearer credential through the API.
  res.json({
    ...config,
    apiSecret: config.apiSecret ? "***" : null,
    internalToken: config.internalToken ? "***" : null,
  });'''
old_put = '    res.json({ ...updated, apiSecret: updated.apiSecret ? "***" : null });'
new_put = '''    res.json({
      ...updated,
      apiSecret: updated.apiSecret ? "***" : null,
      internalToken: updated.internalToken ? "***" : null,
    });'''

if old_get in src:
    src = src.replace(old_get, new_get)
if old_put in src:
    src = src.replace(old_put, new_put)
path.write_text(src)
print("✔  artifacts/api-server/src/routes/config.ts")
PYEOF

# ── 3. artifacts/api-server/src/index.ts ─────────────────────────────────────
# FIX: PORT env var optional (falls back to config.apiPort)
# FIX: removed auto-generation of apiSecret; only internalToken is generated
mkdir -p "$REPO/artifacts/api-server/src"
cat > "$REPO/artifacts/api-server/src/index.ts" << 'KEOF'
import app from "./app";
import { logger } from "./lib/logger";
import { getConfigManager } from "@workspace/kilobuild-config";
import { initializePlugins } from "./routes/plugins";
import { randomBytes } from "node:crypto";
import { existsSync } from "node:fs";
import Dockerode from "dockerode";
import { db, containersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { DockerEventWatcher, pingDocker, getDockerVersion } from "@workspace/kilobuild-docker";
import { startStatusTokenRotation, rotateAllStatusTokens, statusTokenPolicy } from "./status-tokens.js";
import type { GlobalConfig } from "@workspace/kilobuild-types";
import { sql } from "drizzle-orm";

function resolvePort(configuredPort: number): number {
  const rawPort = process.env["PORT"];
  if (!rawPort) return configuredPort;

  const port = Number(rawPort);
  if (Number.isNaN(port) || port <= 0) {
    throw new Error(`Invalid PORT value: "${rawPort}"`);
  }
  return port;
}

async function start(): Promise<void> {
  await getConfigManager().load();
  const configManager = getConfigManager();
  const before = configManager.getGlobal();
  const generatedInternalToken = !before.internalToken;
  if (generatedInternalToken) {
    await configManager.setGlobal({
      internalToken: randomBytes(32).toString("hex"),
    });
  }
  const config = configManager.getGlobal();
  const port = resolvePort(config.apiPort);
  if (generatedInternalToken) {
    logger.info("================================================");
    logger.info(" KiloBuild — first-time setup");
    logger.info("------------------------------------------------");
    logger.info(` Internal Token (KiloBuilder bot ONLY): ${config.internalToken}`);
    logger.info(` API listening at:                       http://${config.apiHost}:${port}`);
    logger.info("================================================");
    logger.info(" Save these now — they will not be printed again.");
    logger.info(` They live in: ${process.env["KILOBUILD_CONFIG_PATH"] ?? `${config.dataDir}/config.json`}`);
    logger.info("================================================");
  }
  await runBootDiagnostics(config);
  await initializePlugins();
  await rotateAllStatusTokens();
  startStatusTokenRotation();
  startDockerLifecycleWatcher(config.dockerSocket);
  const host = config.apiHost;

  app.listen(port, host, (err) => {
    if (err) {
      logger.error({ err }, "Error listening on port");
      process.exit(1);
    }

    logger.info({ port, host }, "Server listening");
  });
}

async function runBootDiagnostics(config: GlobalConfig): Promise<void> {
  logger.info("[boot] Running startup diagnostics");
  try {
    const alive = await pingDocker(config);
    if (!alive) logger.error("[boot] ERROR Docker daemon is not reachable");
    else {
      const version = await getDockerVersion(config);
      logger.info(`[boot] OK Docker ${version.version} (${config.dockerSocket})`);
    }
  } catch (error) {
    logger.error({ error }, "[boot] ERROR Docker diagnostics failed");
  }
  try {
    await db.run(sql`SELECT 1`);
    logger.info("[boot] OK Embedded SQLite database is ready");
  } catch (error) {
    logger.error({ error }, "[boot] ERROR Embedded SQLite database is unavailable");
  }
  for (const [name, path] of [["data", config.dataDir], ["logs", config.logDir], ["backups", config.backupDir]] as const) {
    logger.info(`[boot] ${existsSync(path) ? "OK" : "WARN"} ${name} directory: ${path}`);
  }
  logger.info(`[boot] Rotating status URLs: every ${statusTokenPolicy.rotationMinutes} minutes with ${statusTokenPolicy.graceMinutes}-minute grace; fetch via /internal/status-url/:projectId`);
}

function startDockerLifecycleWatcher(socketPath: string): void {
  const watcher = new DockerEventWatcher(new Dockerode({ socketPath }));
  void watcher.addListener(async (event) => {
    if (event.action !== "die" || !event.projectId || event.exitCode == null || event.exitCode === 0) return;
    const [container] = await db
      .select({ lastStopReason: containersTable.lastStopReason })
      .from(containersTable)
      .where(eq(containersTable.containerId, event.containerId))
      .limit(1);
    if (container?.lastStopReason === "normal") return;
    await db
      .update(containersTable)
      .set({ status: "dead", finishedAt: event.timestamp, exitCode: event.exitCode, lastStopReason: "crash" })
      .where(eq(containersTable.containerId, event.containerId));
    logger.warn({ projectId: event.projectId, exitCode: event.exitCode }, "[lifecycle] container crashed");
  });
  void watcher.start().catch((error) => logger.warn({ error }, "[lifecycle] Docker watcher unavailable"));
}

start().catch((err: unknown) => {
  logger.error({ err }, "Failed to initialize KiloBuild");
  process.exit(1);
});
KEOF
echo "✔  artifacts/api-server/src/index.ts"

# ── 3. artifacts/api-server/src/routes/status.ts ─────────────────────────────
# FIX: req.ip ?? "" (TypeScript strict); early-return pattern (no implicit return)
mkdir -p "$REPO/artifacts/api-server/src/routes"
cat > "$REPO/artifacts/api-server/src/routes/status.ts" << 'KEOF'
import { Router, type IRouter } from "express";
import { desc, eq } from "drizzle-orm";
import { db, containersTable, projectsTable } from "@workspace/db";
import { getConfigManager } from "@workspace/kilobuild-config";
import { ensureStatusToken, resolveStatusToken } from "../status-tokens.js";

const router: IRouter = Router();

function publicStatus(container: typeof containersTable.$inferSelect | null) {
  if (!container) return "offline";
  switch (container.status) {
    case "running":
      return "online";
    case "created":
    case "restarting":
      return "starting";
    case "paused":
    case "removing":
      return "stopping";
    case "exited":
    case "dead":
    default:
      return "offline";
  }
}

export async function buildStatusDashboard(projectId: string) {
  const [project] = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, projectId))
    .limit(1);
  if (!project) return null;

  const [container] = await db
    .select()
    .from(containersTable)
    .where(eq(containersTable.projectId, project.id))
    .orderBy(desc(containersTable.createdAt))
    .limit(1);
  const state = publicStatus(container ?? null);
  const uptimeSeconds =
    state === "online" && container?.startedAt
      ? Math.max(0, Math.floor((Date.now() - container.startedAt.getTime()) / 1000))
      : 0;

  return {
    project: {
      id: project.id,
      name: project.name,
      slug: project.slug,
      description: project.description,
      projectType: project.projectType,
      nodeVersion: project.nodeVersion,
    },
    status: state,
    container: container
      ? {
          containerId: container.containerId,
          status: container.status,
          startedAt: container.startedAt,
          finishedAt: container.finishedAt,
          exitCode: container.exitCode,
          restartCount: container.restartCount,
          error: container.error,
          lastStopReason: container.lastStopReason,
        }
      : null,
    lastStopReason: container?.lastStopReason ?? null,
    uptimeSeconds,
    checkedAt: new Date(),
    health: {
      status: state === "online" ? "unknown" : state === "starting" ? "starting" : "unknown",
      message: null,
      responseTimeMs: null,
    },
  };
}

// Public by design: the rotating token is the credential for this route.
router.get("/status/:token", async (req, res) => {
  const token = req.params["token"] ?? "";
  const resolved = await resolveStatusToken(token, req.ip ?? "");
  if (!resolved) {
    res.status(404).json({ error: "Status page not found" });
    return;
  }

  const dashboard = await buildStatusDashboard(resolved.projectId);
  if (!dashboard) {
    res.status(404).json({ error: "Status page not found" });
    return;
  }
  res.setHeader("Cache-Control", "no-store");
  res.json(dashboard);
});

// Dedicated KiloBuilder-only route. The token is intentionally not accepted
// by the general API auth middleware.
router.get("/internal/status-url/:projectId", async (req, res) => {
  const configured = getConfigManager().getGlobal().internalToken;
  const header = req.header("authorization");
  const supplied = header?.startsWith("Bearer ") ? header.slice(7) : null;
  if (!configured || !supplied || supplied !== configured) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const [project] = await db
    .select({ id: projectsTable.id })
    .from(projectsTable)
    .where(eq(projectsTable.id, req.params["projectId"]!))
    .limit(1);
  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const token = await ensureStatusToken(project.id);
  const forwardedProto = req.header("x-forwarded-proto")?.split(",")[0]?.trim();
  const base = `${forwardedProto || req.protocol}://${req.get("host")}`;
  res.json({
    projectId: project.id,
    url: `${base}/status/${token.currentToken}`,
    expiresAt: token.currentExpiresAt,
  });
});

export default router;
KEOF
echo "✔  artifacts/api-server/src/routes/status.ts"

# ── 4. artifacts/api-server/src/routes/projects.ts ───────────────────────────
# FIX: path security check now also allows paths inside discordBotsDir
cat > "$REPO/artifacts/api-server/src/routes/projects.ts" << 'KEOF'
import { Router, type IRouter } from "express";
import { and, desc, eq, like, or, sql } from "drizzle-orm";
import { db } from "@workspace/db";
import {
  projectsTable,
  containersTable,
  projectConfigsTable,
  insertProjectSchema,
  updateProjectSchema,
} from "@workspace/db/schema";
import { z } from "zod/v4";
import { access, constants } from "node:fs";
import { mkdir, writeFile } from "node:fs/promises";
import { join, resolve, relative, isAbsolute } from "node:path";
import { analyzeDirectory } from "@workspace/kilobuild-discovery";
import { scaffoldProject } from "@workspace/kilobuild-templates";
import { getConfigManager } from "@workspace/kilobuild-config";
import Dockerode from "dockerode";
import { ContainerManager, ImageManager } from "@workspace/kilobuild-docker";
import { ensureStatusToken } from "../status-tokens.js";

const router: IRouter = Router();

// ── GET /projects ──────────────────────────────
router.get("/projects", async (req, res) => {
  const { status, tag, q } = req.query as Record<string, string>;

  try {
    const conditions = [];
    if (status) {
      conditions.push(eq(projectsTable.status, status as typeof projectsTable.status._.data));
    }
    if (q) {
      const pattern = `%${q}%`;
      conditions.push(or(like(projectsTable.name, pattern), like(projectsTable.description, pattern)));
    }

    const query = db.select().from(projectsTable);
    const rows = await (conditions.length > 0 ? query.where(and(...conditions)) : query)
      .orderBy(desc(projectsTable.updatedAt));

    // Filter by tag client-side (tags stored as JSONB array)
    const filtered = tag
      ? rows.filter((p) => Array.isArray(p.tags) && (p.tags as string[]).includes(tag))
      : rows;

    res.json(filtered);
  } catch (err) {
    res.status(500).json({ error: "Failed to list projects", detail: String(err) });
  }
  return;
});

// ── POST /projects ─────────────────────────────
router.post("/projects", async (req, res) => {
  const name = typeof req.body?.name === "string" ? req.body.name.trim() : "";
  const pathValue = typeof req.body?.path === "string" ? req.body.path : "";
  const projectPath = pathValue ? resolve(pathValue) : "";
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

  if (!name || !projectPath || !slug) {
    return res.status(400).json({ error: "name and path are required" });
  }

  try {
    const global = getConfigManager().getGlobal();
    const projectsRootDir = resolve(global.projectsRootDir);
    const discordBotsDir = resolve(global.discordBotsDir);
    const sep = process.platform === "win32" ? "\\" : "/";

    function isInsideDir(child: string, dir: string): boolean {
      const rel = relative(dir, child);
      return rel !== ".." && !rel.startsWith(`..${sep}`) && !isAbsolute(rel);
    }

    if (!isInsideDir(projectPath, projectsRootDir) && !isInsideDir(projectPath, discordBotsDir)) {
      return res.status(400).json({
        error: "Project path must be inside the configured projects root or Discord-Bots directory",
        detail: { projectsRootDir, discordBotsDir },
      });
    }

    await mkdir(projectPath, { recursive: true });

    // Create initializes a new directory; import can still pass
    // initialize=false to require an existing package.json.
    if (!(await fileExists(join(projectPath, "package.json")))) {
      if (req.body?.initialize === false) {
        return res.status(400).json({
          error: "The project directory has no package.json",
          detail: "Create package.json first or omit initialize=false.",
        });
      }

      await writeFile(
        join(projectPath, "package.json"),
        JSON.stringify({
          name: slug,
          version: "1.0.0",
          private: true,
          scripts: { start: "node index.js" },
        }, null, 2) + "\n",
        { encoding: "utf8", flag: "wx" },
      ).catch((error: unknown) => {
        if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
      });
      await writeFile(
        join(projectPath, "index.js"),
        `const http = require("node:http");\nconst port = Number(process.env.PORT || 3000);\nhttp.createServer((_req, res) => res.end("KiloBuild project is running\\n")).listen(port, () => console.log(\`Listening on \${port}\`));\n`,
        { encoding: "utf8", flag: "wx" },
      ).catch((error: unknown) => {
        if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
      });
    }

    const discovered = await analyzeDirectory(projectPath);
    if (!discovered) {
      return res.status(400).json({ error: "Unable to analyze the Node.js project" });
    }

    const parsed = insertProjectSchema.safeParse({
      name,
      slug,
      path: projectPath,
      description: req.body.description,
      tags: req.body.tags,
      nodeVersion: req.body.nodeVersion ?? discovered.nodeVersion,
      entryPoint: req.body.entryPoint ?? discovered.entryPoint,
      packageManager: req.body.packageManager ?? discovered.packageManager ?? "npm",
      projectType: req.body.projectType ?? (discovered.hasTypeScript ? "typescript" : "node"),
      metadata: {
        discovered: true,
        hasDockerfile: discovered.hasDockerfile,
        hasDockerCompose: discovered.hasDockerCompose,
        envFiles: discovered.envFiles,
      },
    });

    if (!parsed.success) {
      return res.status(400).json({ error: "Validation failed", detail: parsed.error.message });
    }

    const [project] = await db
      .insert(projectsTable)
      .values({
        ...parsed.data,
        tags: parsed.data.tags ?? [],
        metadata: parsed.data.metadata ?? {},
      })
      .returning();

    const config = getConfigManager().getProject(project.id);
    await db.insert(projectConfigsTable).values({ projectId: project.id, ...config });
    await ensureStatusToken(project.id);

    await scaffoldProject({
      projectPath,
      context: {
        projectName: project.name,
        projectSlug: project.slug,
        nodeVersion: project.nodeVersion ?? getConfigManager().getGlobal().defaultNodeVersion,
        packageManager: project.packageManager,
        entryPoint: project.entryPoint ?? "index.js",
        nodeArgs: config.nodeArgs,
        hasTypeScript: discovered.hasTypeScript,
        ports: config.portBindings.map((binding) => binding.containerPort),
        volumes: config.volumeBindings.map(
          (binding) => `${binding.hostPath}:${binding.containerPath}${binding.readOnly ? ":ro" : ""}`,
        ),
        envVars: config.envVars,
        buildCommand: null,
        startCommand: project.entryPoint ?? "node index.js",
        projectType: project.projectType,
        extraDockerfileLines: config.extraDockerfileLines,
        autoInstall: config.autoInstall,
        autoBuild: config.autoBuild,
        autoMigrate: config.autoMigrate,
      },
    });

    res.status(201).json({ ...project, config });
  } catch (err: unknown) {
    const msg = String(err);
    if (msg.includes("unique")) {
      return res.status(409).json({ error: "Project name already exists" });
    }
    res.status(500).json({ error: "Failed to create project", detail: msg });
  }
  return;
});

// ── GET /projects/:id ─────────────────────────
router.get("/projects/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const project = await findProject(id);
    if (!project) return res.status(404).json({ error: "Project not found" });

    // Enrich with container + config
    const [container] = await db
      .select()
      .from(containersTable)
      .where(eq(containersTable.projectId, project.id))
      .limit(1)
      .orderBy(sql`${containersTable.createdAt} DESC`);

    const [config] = await db
      .select()
      .from(projectConfigsTable)
      .where(eq(projectConfigsTable.projectId, project.id))
      .limit(1);

    res.json({ ...project, container: container ?? null, config: config ?? null });
  } catch (err) {
    res.status(500).json({ error: "Failed to get project", detail: String(err) });
  }
  return;
});

// ── PATCH /projects/:id ───────────────────────
router.patch("/projects/:id", async (req, res) => {
  const { id } = req.params;
  const parsed = updateProjectSchema.safeParse(req.body);

  if (!parsed.success) {
    return res.status(400).json({ error: "Validation failed", detail: parsed.error.message });
  }

  try {
    const project = await findProject(id);
    if (!project) return res.status(404).json({ error: "Project not found" });

    const [updated] = await db
      .update(projectsTable)
      .set({ ...parsed.data, updatedAt: new Date() })
      .where(eq(projectsTable.id, project.id))
      .returning();

    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: "Failed to update project", detail: String(err) });
  }
  return;
});

// ── DELETE /projects/:id ──────────────────────
router.delete("/projects/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const project = await findProject(id);
    if (!project) return res.status(404).json({ error: "Project not found" });

    // Docker is optional during project import and local development. When
    // available, remove only resources owned by this KiloBuild project.
    try {
      const docker = new Dockerode({
        socketPath: getConfigManager().getGlobal().dockerSocket,
      });
      const manager = new ContainerManager(docker);
      const containerId = await manager.findBySlug(project.slug);
      if (containerId) await manager.remove(containerId, true);

      const imageManager = new ImageManager(docker);
      const imageName = imageManager.imageName(project.slug);
      if (await imageManager.exists(imageName)) {
        await imageManager.remove(imageName, true);
      }
    } catch (dockerError) {
      req.log.warn({ err: dockerError, project: project.slug }, "Docker cleanup skipped");
    }

    await db.delete(projectsTable).where(eq(projectsTable.id, project.id));
    await getConfigManager().deleteProject(project.id);
    res.status(204).send();
  } catch (err) {
    res.status(500).json({ error: "Failed to delete project", detail: String(err) });
  }
  return;
});

async function fileExists(path: string): Promise<boolean> {
  return new Promise((resolve) => {
    access(path, constants.F_OK, (error) => resolve(!error));
  });
}

// ── Helper: find project by ID or name ───────

export async function findProject(idOrName: string) {
  // Try UUID first
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (uuidRegex.test(idOrName)) {
    const [p] = await db.select().from(projectsTable).where(eq(projectsTable.id, idOrName)).limit(1);
    return p ?? null;
  }
  // Try by name or slug
  const [p] = await db
    .select()
    .from(projectsTable)
    .where(or(eq(projectsTable.name, idOrName), eq(projectsTable.slug, idOrName)) as ReturnType<typeof eq>)
    .limit(1);
  return p ?? null;
}

export default router;
KEOF
echo "✔  artifacts/api-server/src/routes/projects.ts"

# ── 5. lib/kilobuild-types/src/index.ts ──────────────────────────────────────
# ADD: discordBotsDir field to GlobalConfig interface
if grep -q "discordBotsDir" "$REPO/lib/kilobuild-types/src/index.ts"; then
  echo "✔  lib/kilobuild-types/src/index.ts (already patched)"
else
  sed -i 's/  discordWebhookUrl: string | null;/  discordWebhookUrl: string | null;\n  discordBotsDir: string;/' \
    "$REPO/lib/kilobuild-types/src/index.ts"
  echo "✔  lib/kilobuild-types/src/index.ts"
fi

# ── 6. lib/kilobuild-config/src/index.ts ─────────────────────────────────────
# ADD: discordBotsDir to globalConfigSchema with sensible default
if grep -q "discordBotsDir" "$REPO/lib/kilobuild-config/src/index.ts"; then
  echo "✔  lib/kilobuild-config/src/index.ts (already patched)"
else
  sed -i 's/  discordWebhookUrl: z.string().url().nullable().default(null),/  discordWebhookUrl: z.string().url().nullable().default(null),\n  discordBotsDir: z.string().default(join(process.env["HOME"] ?? "\/root", "Discord-Bots")),/' \
    "$REPO/lib/kilobuild-config/src/index.ts"
  echo "✔  lib/kilobuild-config/src/index.ts"
fi

# ── 7. lib/kilobuild-cli/src/commands/import.ts ──────────────────────────────
# NEW: moves project folder into ~/Discord-Bots before registering with daemon
mkdir -p "$REPO/lib/kilobuild-cli/src/commands"
cat > "$REPO/lib/kilobuild-cli/src/commands/import.ts" << 'KEOF'
import { Command } from "commander";
import { resolve, basename, join, sep } from "node:path";
import { rename, mkdir, cp, rm } from "node:fs/promises";
import { existsSync } from "node:fs";
import { relative, isAbsolute } from "node:path";
import ora from "ora";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { ok, err, info } from "../utils/formatter.js";
import type { ProjectDetail, GlobalConfig } from "@workspace/kilobuild-types";

/** Move a directory; falls back to recursive copy+delete across filesystems. */
async function moveDir(src: string, dest: string): Promise<void> {
  try {
    await rename(src, dest);
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code !== "EXDEV") throw e;
    // Cross-device: copy then delete
    await cp(src, dest, { recursive: true });
    await rm(src, { recursive: true, force: true });
  }
}

function isInsideDir(child: string, dir: string): boolean {
  const rel = relative(resolve(dir), resolve(child));
  return rel !== ".." && !rel.startsWith(`..${sep}`) && !isAbsolute(rel);
}

export function importCommand(): Command {
  return new Command("import")
    .description(
      "Import a Node.js / Discord bot project into KiloBuild.\n" +
      "The project folder is moved into the configured Discord-Bots directory\n" +
      "and a startup.sh is generated automatically.",
    )
    .argument("<path>", "Absolute or relative path to the project directory")
    .option("-n, --name <name>", "Override project name (default: directory name)")
    .option(
      "--no-move",
      "Register in-place without moving the folder into Discord-Bots",
    )
    .action(
      async (pathArg: string, opts: { name?: string; move: boolean }) => {
        const sourcePath = resolve(pathArg);
        const name = opts.name ?? basename(sourcePath);

        if (!existsSync(sourcePath)) {
          err(`Directory not found: ${sourcePath}`);
          process.exit(1);
        }

        // ── Resolve destination in Discord-Bots dir ────────────────────────
        let config: GlobalConfig;
        try {
          config = await api.get<GlobalConfig>("/config");
        } catch (e) {
          err(
            e instanceof ApiError
              ? e.message
              : `Cannot reach KiloBuild daemon: ${String(e)}`,
          );
          process.exit(1);
        }

        const discordBotsDir = config.discordBotsDir;
        const destPath = join(discordBotsDir, name);

        let projectPath = sourcePath;

        if (opts.move !== false && !isInsideDir(sourcePath, discordBotsDir)) {
          if (existsSync(destPath)) {
            err(
              `Destination already exists: ${destPath}\n` +
              `  Use --name to pick a different name, or --no-move to register in-place.`,
            );
            process.exit(1);
          }

          const spinner = ora(
            `Moving ${chalk.bold(name)} → ${chalk.dim(discordBotsDir + "/")}${chalk.bold(name)}...`,
          ).start();

          try {
            await mkdir(discordBotsDir, { recursive: true });
            await moveDir(sourcePath, destPath);
            projectPath = destPath;
            spinner.succeed(`Moved to ${chalk.cyan(destPath)}`);
          } catch (e) {
            spinner.fail("Failed to move project folder");
            err(String(e));
            process.exit(1);
          }
        } else {
          info(`Registering in-place: ${chalk.cyan(sourcePath)}`);
          projectPath = sourcePath;
        }

        // ── Register with KiloBuild daemon ─────────────────────────────────
        const spinner = ora(`Importing ${chalk.bold(name)}...`).start();

        try {
          const project = await api.post<ProjectDetail>("/projects", {
            name,
            path: projectPath,
            initialize: false,
          });

          spinner.succeed(`Imported ${chalk.bold(project.name)}`);
          ok(`ID:       ${project.id}`);
          ok(`Path:     ${project.path}`);
          ok(`Type:     ${project.projectType}`);
          ok(`PM:       ${project.packageManager}`);
          ok(`Entry:    ${project.entryPoint ?? "index.js"}`);
          info(
            `startup.sh was generated with ${chalk.cyan("npm install")} + ${chalk.cyan(`node ${project.entryPoint ?? "index.js"}`)} — edit .kilobuild/startup.sh to customise`,
          );
          info(`Run ${chalk.cyan(`kilo start ${project.name}`)} to launch`);
        } catch (error) {
          spinner.fail("Import failed");
          if (error instanceof ApiError) err(error.message);
          else err(String(error));
          process.exit(1);
        }
      },
    );
}
KEOF
echo "✔  lib/kilobuild-cli/src/commands/import.ts"

# ── 8. pnpm-workspace.yaml ────────────────────────────────────────────────────
# ADD: cpu-features, protobufjs, ssh2 to onlyBuiltDependencies + allowBuilds block
if grep -q "cpu-features" "$REPO/pnpm-workspace.yaml"; then
  echo "✔  pnpm-workspace.yaml (already patched)"
else
  # Add to onlyBuiltDependencies (after the existing esbuild line)
  sed -i "/^onlyBuiltDependencies:/,/^[^ ]/ {
    /- esbuild/a\\  - cpu-features\n  - protobufjs\n  - ssh2
  }" "$REPO/pnpm-workspace.yaml"

  # Add allowBuilds block at end of file
  cat >> "$REPO/pnpm-workspace.yaml" << 'KEOF'

allowBuilds:
  cpu-features: true
  esbuild: true
  protobufjs: true
  ssh2: true
KEOF
  echo "✔  pnpm-workspace.yaml"
fi

# ── 9. Rebuild the CLI binary ─────────────────────────────────────────────────
echo ""
echo "🔨 Rebuilding TypeScript libs..."
cd "$REPO"
pnpm run typecheck:libs

echo "🔨 Building kilo CLI binary..."
pnpm --filter @workspace/kilobuild-cli run build

echo "🔨 Building API server..."
pnpm --filter @workspace/api-server run build

echo ""
echo "✅ Source updates applied:"
echo "   • auth.ts          — no apiSecret = open access restored"
echo "   • index.ts         — PORT env var optional; apiSecret no longer auto-generated"
echo "   • status.ts        — TypeScript strict fixes (req.ip, early return)"
echo "   • projects.ts      — path check accepts ~/Discord-Bots as valid root"
echo "   • kilobuild-types  — GlobalConfig.discordBotsDir added"
echo "   • kilobuild-config — globalConfigSchema.discordBotsDir added (default: ~/Discord-Bots)"
echo "   • import.ts        — 'kilo import <bot>' moves folder into ~/Discord-Bots automatically"
echo "   • pnpm-workspace   — cpu-features / protobufjs / ssh2 native build entries added"
echo ""

if [[ "${EUID}" -eq 0 ]] && command -v systemctl >/dev/null 2>&1; then
  echo "Installing and restarting the persistent KiloBuild service..."
  bash "$REPO/scripts/install-vps.sh"
else
  echo "The build completed. Run as root on the VPS:"
  echo "  bash $REPO/scripts/install-vps.sh"
fi
