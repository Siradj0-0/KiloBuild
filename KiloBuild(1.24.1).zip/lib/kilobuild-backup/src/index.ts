import { mkdir, stat, readdir, access, unlink } from "node:fs/promises";
import { existsSync, statSync } from "node:fs";
import { join, basename } from "node:path";
import { randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import type { Backup, BackupInput, BackupStatus } from "@workspace/kilobuild-types";
import { eventBus } from "@workspace/kilobuild-events";

const execFileAsync = promisify(execFile);

// ── BackupManager ─────────────────────────────

export class BackupManager {
  constructor(private readonly backupDir: string) {}

  private projectBackupDir(projectId: string): string {
    return join(this.backupDir, projectId);
  }

  private safeBackupName(input: string): string {
    const normalized = input.replace(/[\\/]/g, "-").replace(/[^a-zA-Z0-9_-]/g, "");
    if (!normalized || normalized === "." || normalized === "..") {
      throw new Error("Backup name must contain letters, numbers, hyphens, or underscores");
    }
    return normalized;
  }

  /** Create a complete backup of a project. */
  async create(
    projectId: string,
    projectPath: string,
    input: BackupInput = {},
  ): Promise<Backup> {
    const id = randomUUID();
    const requestedName =
      input.name ??
      `backup-${new Date().toISOString().slice(0, 19).replace(/[T:]/g, "-")}`;
    const name = this.safeBackupName(requestedName);
    const dir = this.projectBackupDir(projectId);
    await mkdir(dir, { recursive: true });

    const archivePath = join(dir, `${name}.tar.gz`);

    const backup: Backup = {
      id,
      projectId,
      name,
      path: archivePath,
      sizeBytes: null,
      includesLogs: input.includesLogs ?? false,
      createdAt: new Date(),
      notes: input.notes ?? null,
      status: "creating",
    };

    try {
      const args = [
        "-czf",
        archivePath,
        "--exclude=./node_modules",
        "--exclude=./.git",
        "--exclude=./dist",
        "--exclude=./.cache",
      ];
      if (!input.includesLogs) args.push("--exclude=*.log");
      args.push(".");
      await execFileAsync("tar", args, { cwd: projectPath });

      const s = statSync(archivePath);
      backup.sizeBytes = s.size;
      backup.status = "ready";

      eventBus.emit("backup:created", projectId, { backupId: id, name, path: archivePath });
    } catch (err) {
      backup.status = "failed";
      eventBus.emit("backup:failed", projectId, { backupId: id, error: String(err) });
    }

    return backup;
  }

  /** Restore a project from a backup archive. */
  async restore(
    backup: Backup,
    targetPath: string,
  ): Promise<void> {
    if (backup.status !== "ready") {
      throw new Error(`Backup ${backup.id} is not in 'ready' state`);
    }

    try {
      await access(backup.path, constants.F_OK);
    } catch {
      throw new Error(`Backup archive not found: ${backup.path}`);
    }

    await mkdir(targetPath, { recursive: true });

    await execFileAsync("tar", ["-xzf", backup.path, "-C", targetPath]);

    eventBus.emit("backup:restored", backup.projectId, {
      backupId: backup.id,
      targetPath,
    });
  }

  /** List all backups for a project (reads from disk). */
  async list(projectId: string): Promise<Array<{ name: string; path: string; sizeBytes: number; createdAt: Date }>> {
    const dir = this.projectBackupDir(projectId);
    if (!existsSync(dir)) return [];

    const files = await readdir(dir);
    const results: Array<{ name: string; path: string; sizeBytes: number; createdAt: Date }> = [];

    for (const file of files) {
      if (!file.endsWith(".tar.gz")) continue;
      const fullPath = join(dir, file);
      try {
        const s = await stat(fullPath);
        results.push({
          name: basename(file, ".tar.gz"),
          path: fullPath,
          sizeBytes: s.size,
          createdAt: s.birthtime,
        });
      } catch {
        // ignore
      }
    }

    return results.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  /** Delete a backup archive from disk. */
  async delete(backup: Backup): Promise<void> {
    try {
      await unlink(backup.path);
    } catch {
      // If file doesn't exist, that's fine
    }
  }

  /** Prune backups older than a given number of days. */
  async prune(projectId: string, maxAgeDays: number): Promise<number> {
    const files = await this.list(projectId);
    const cutoff = Date.now() - maxAgeDays * 86_400_000;
    let deleted = 0;
    for (const f of files) {
      if (f.createdAt.getTime() < cutoff) {
        await unlink(f.path).catch(() => { /* ignore */ });
        deleted++;
      }
    }
    return deleted;
  }

  /** Calculate total backup size for a project in bytes. */
  async totalSize(projectId: string): Promise<number> {
    const files = await this.list(projectId);
    return files.reduce((sum, f) => sum + f.sizeBytes, 0);
  }
}

export type { Backup, BackupInput, BackupStatus };
