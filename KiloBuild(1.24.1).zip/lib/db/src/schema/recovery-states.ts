import { randomUUID } from "node:crypto";
import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { projectsTable } from "./projects.js";

export const recoveryStatesTable = sqliteTable("recovery_states", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  projectId: text("project_id")
    .notNull()
    .unique()
    .references(() => projectsTable.id, { onDelete: "cascade" }),
  restartCount: integer("restart_count").notNull().default(0),
  lastRestartAt: integer("last_restart_at", { mode: "timestamp" }),
  nextAllowedRestartAt: integer("next_allowed_restart_at", { mode: "timestamp" }),
  exhausted: integer("exhausted", { mode: "boolean" }).notNull().default(false),
  windowStartAt: integer("window_start_at", { mode: "timestamp" }),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const insertRecoveryStateSchema = createInsertSchema(recoveryStatesTable).omit({
  id: true,
  updatedAt: true,
});

export type RecoveryStateRow = typeof recoveryStatesTable.$inferSelect;
export type InsertRecoveryState = z.infer<typeof insertRecoveryStateSchema>;