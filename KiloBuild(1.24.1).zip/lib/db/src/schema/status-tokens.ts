import { randomUUID } from "node:crypto";
import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { projectsTable } from "./projects.js";

export const statusTokensTable = sqliteTable("status_tokens", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  projectId: text("project_id")
    .notNull()
    .unique()
    .references(() => projectsTable.id, { onDelete: "cascade" }),
  currentToken: text("current_token").notNull().unique(),
  currentExpiresAt: integer("current_expires_at", { mode: "timestamp" }).notNull(),
  previousToken: text("previous_token"),
  previousExpiresAt: integer("previous_expires_at", { mode: "timestamp" }),
});

export type StatusToken = typeof statusTokensTable.$inferSelect;