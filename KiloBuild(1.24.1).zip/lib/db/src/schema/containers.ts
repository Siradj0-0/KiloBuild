import { randomUUID } from "node:crypto";
import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { projectsTable } from "./projects.js";

export const containerStatusValues = [
  "created",
  "running",
  "paused",
  "restarting",
  "removing",
  "exited",
  "dead",
  "unknown",
] as const;

export const lastStopReasonValues = ["normal", "crash", "unknown"] as const;

export const containersTable = sqliteTable("containers", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  projectId: text("project_id")
    .notNull()
    .references(() => projectsTable.id, { onDelete: "cascade" }),
  containerId: text("container_id").notNull().unique(),
  imageId: text("image_id"),
  imageName: text("image_name"),
  status: text("status", { enum: containerStatusValues }).notNull().default("unknown"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
  startedAt: integer("started_at", { mode: "timestamp" }),
  finishedAt: integer("finished_at", { mode: "timestamp" }),
  exitCode: integer("exit_code"),
  restartCount: integer("restart_count").notNull().default(0),
  error: text("error"),
  lastStopReason: text("last_stop_reason", { enum: lastStopReasonValues })
    .notNull()
    .default("unknown"),
});

export const insertContainerSchema = createInsertSchema(containersTable).omit({
  id: true,
  createdAt: true,
});

export type Container = typeof containersTable.$inferSelect;
export type InsertContainer = z.infer<typeof insertContainerSchema>;
