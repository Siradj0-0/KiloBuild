import { randomUUID } from "node:crypto";
import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const projectStatusValues = [
  "created",
  "building",
  "running",
  "stopped",
  "error",
  "unknown",
] as const;

export const packageManagerValues = [
  "npm",
  "pnpm",
  "yarn",
  "bun",
] as const;

export const projectTypeValues = [
  "node",
  "typescript",
  "discord-bot",
  "express-api",
  "generic",
] as const;

export const projectsTable = sqliteTable("projects", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  name: text("name").notNull().unique(),
  slug: text("slug").notNull().unique(),
  path: text("path").notNull(),
  status: text("status", { enum: projectStatusValues }).notNull().default("created"),
  nodeVersion: text("node_version"),
  entryPoint: text("entry_point"),
  packageManager: text("package_manager", { enum: packageManagerValues }).notNull().default("npm"),
  projectType: text("project_type", { enum: projectTypeValues }).notNull().default("node"),
  description: text("description"),
  tags: text("tags", { mode: "json" }).$type<string[]>().notNull().default([]),
  metadata: text("metadata", { mode: "json" }).$type<Record<string, unknown>>().notNull().default({}),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
  lastStartedAt: integer("last_started_at", { mode: "timestamp" }),
  lastStoppedAt: integer("last_stopped_at", { mode: "timestamp" }),
});

export const insertProjectSchema = createInsertSchema(projectsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastStartedAt: true,
  lastStoppedAt: true,
});

export const updateProjectSchema = insertProjectSchema.partial();

export type Project = typeof projectsTable.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type UpdateProject = z.infer<typeof updateProjectSchema>;
