import { randomUUID } from "node:crypto";
import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { projectsTable } from "./projects.js";

export const buildLogsTable = sqliteTable("build_logs", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  projectId: text("project_id")
    .notNull()
    .references(() => projectsTable.id, { onDelete: "cascade" }),
  status: text("status", { enum: ["pending", "running", "success", "failed"] as const })
    .notNull()
    .default("pending"),
  imageId: text("image_id"),
  imageName: text("image_name"),
  logs: text("logs", { mode: "json" }).$type<string[]>().notNull().default([]),
  startedAt: integer("started_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
  finishedAt: integer("finished_at", { mode: "timestamp" }),
  durationMs: integer("duration_ms"),
  error: text("error"),
});

export const insertBuildLogSchema = createInsertSchema(buildLogsTable).omit({
  id: true,
});

export type BuildLog = typeof buildLogsTable.$inferSelect;
export type InsertBuildLog = z.infer<typeof insertBuildLogSchema>;