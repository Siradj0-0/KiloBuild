import { randomUUID } from "node:crypto";
import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { projectsTable } from "./projects.js";

export const backupStatusValues = [
  "creating",
  "ready",
  "failed",
  "deleted",
] as const;

export const backupsTable = sqliteTable("backups", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  projectId: text("project_id")
    .notNull()
    .references(() => projectsTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  path: text("path").notNull(),
  sizeBytes: integer("size_bytes"),
  includesLogs: integer("includes_logs", { mode: "boolean" }).notNull().default(false),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
  notes: text("notes"),
  status: text("status", { enum: backupStatusValues }).notNull().default("creating"),
});

export const insertBackupSchema = createInsertSchema(backupsTable).omit({
  id: true,
  createdAt: true,
});

export const updateBackupSchema = insertBackupSchema.partial().omit({ projectId: true });

export type Backup = typeof backupsTable.$inferSelect;
export type InsertBackup = z.infer<typeof insertBackupSchema>;
export type UpdateBackup = z.infer<typeof updateBackupSchema>;
