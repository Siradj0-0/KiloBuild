import { randomUUID } from "node:crypto";
import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const pluginStatusValues = [
  "active",
  "inactive",
  "error",
] as const;

export const pluginsRegistryTable = sqliteTable("plugins_registry", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  name: text("name").notNull().unique(),
  version: text("version").notNull(),
  description: text("description"),
  path: text("path"),
  enabled: integer("enabled", { mode: "boolean" }).notNull().default(true),
  status: text("status", { enum: pluginStatusValues }).notNull().default("inactive"),
  config: text("config", { mode: "json" }).$type<Record<string, unknown>>().notNull().default({}),
  installedAt: integer("installed_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const insertPluginSchema = createInsertSchema(pluginsRegistryTable).omit({
  id: true,
  installedAt: true,
});

export const updatePluginSchema = insertPluginSchema.partial().omit({ name: true });

export type PluginRow = typeof pluginsRegistryTable.$inferSelect;
export type InsertPlugin = z.infer<typeof insertPluginSchema>;
export type UpdatePlugin = z.infer<typeof updatePluginSchema>;
