import { randomUUID } from "node:crypto";
import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { projectsTable } from "./projects.js";

export const statsSnapshotsTable = sqliteTable("stats_snapshots", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  projectId: text("project_id")
    .notNull()
    .references(() => projectsTable.id, { onDelete: "cascade" }),
  containerId: text("container_id").notNull(),
  cpuPercent: real("cpu_percent").notNull().default(0),
  memoryUsedBytes: integer("memory_used_bytes").notNull().default(0),
  memoryLimitBytes: integer("memory_limit_bytes").notNull().default(0),
  memoryPercent: real("memory_percent").notNull().default(0),
  networkRxBytes: integer("network_rx_bytes").notNull().default(0),
  networkTxBytes: integer("network_tx_bytes").notNull().default(0),
  blockReadBytes: integer("block_read_bytes").notNull().default(0),
  blockWriteBytes: integer("block_write_bytes").notNull().default(0),
  pids: integer("pids").notNull().default(0),
  recordedAt: integer("recorded_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const insertStatsSnapshotSchema = createInsertSchema(statsSnapshotsTable).omit({
  id: true,
  recordedAt: true,
});

export type StatsSnapshot = typeof statsSnapshotsTable.$inferSelect;
export type InsertStatsSnapshot = z.infer<typeof insertStatsSnapshotSchema>;
