import { randomUUID } from "node:crypto";
import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { projectsTable } from "./projects.js";

export const eventsLogTable = sqliteTable("events_log", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  projectId: text("project_id").references(() => projectsTable.id, {
    onDelete: "set null",
  }),
  eventType: text("event_type").notNull(),
  payload: text("payload", { mode: "json" }).$type<Record<string, unknown>>().notNull().default({}),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const insertEventLogSchema = createInsertSchema(eventsLogTable).omit({
  id: true,
  createdAt: true,
});

export type EventLog = typeof eventsLogTable.$inferSelect;
export type InsertEventLog = z.infer<typeof insertEventLogSchema>;
