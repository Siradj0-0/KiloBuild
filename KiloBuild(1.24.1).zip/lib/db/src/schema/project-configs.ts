import { randomUUID } from "node:crypto";
import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { projectsTable } from "./projects.js";

export const restartPolicyValues = [
  "no",
  "always",
  "on-failure",
  "unless-stopped",
] as const;

export const projectConfigsTable = sqliteTable("project_configs", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  projectId: text("project_id")
    .notNull()
    .unique()
    .references(() => projectsTable.id, { onDelete: "cascade" }),
  cpuLimit: text("cpu_limit").notNull().default("0.1"),
  memoryLimit: text("memory_limit").notNull().default("128m"),
  memorySwapLimit: text("memory_swap_limit"),
  restartPolicy: text("restart_policy", { enum: restartPolicyValues }).notNull().default("unless-stopped"),
  maxRestarts: integer("max_restarts").notNull().default(10),
  restartWindowSeconds: integer("restart_window_seconds").notNull().default(300),
  backoffMultiplier: real("backoff_multiplier").notNull().default(2.0),
  cooldownSeconds: integer("cooldown_seconds").notNull().default(5),
  healthCheckEnabled: integer("health_check_enabled", { mode: "boolean" }).notNull().default(false),
  healthCheckPath: text("health_check_path"),
  healthCheckIntervalSeconds: integer("health_check_interval_seconds").notNull().default(30),
  healthCheckTimeoutSeconds: integer("health_check_timeout_seconds").notNull().default(10),
  healthCheckRetries: integer("health_check_retries").notNull().default(3),
  envVars: text("env_vars", { mode: "json" }).$type<Record<string, string>>().notNull().default({}),
  portBindings: text("port_bindings", { mode: "json" }).$type<Array<{ containerPort: number; hostPort: number | null; protocol: string }>>().notNull().default([]),
  volumeBindings: text("volume_bindings", { mode: "json" }).$type<Array<{ containerPath: string; hostPath: string; readOnly: boolean }>>().notNull().default([]),
  networkMode: text("network_mode").notNull().default("bridge"),
  labels: text("labels", { mode: "json" }).$type<Record<string, string>>().notNull().default({}),
  autoInstall: integer("auto_install", { mode: "boolean" }).notNull().default(true),
  autoBuild: integer("auto_build", { mode: "boolean" }).notNull().default(false),
  autoMigrate: integer("auto_migrate", { mode: "boolean" }).notNull().default(false),
  logRotationEnabled: integer("log_rotation_enabled", { mode: "boolean" }).notNull().default(true),
  logMaxSizeMb: integer("log_max_size_mb").notNull().default(100),
  logRetentionDays: integer("log_retention_days").notNull().default(30),
  buildArgs: text("build_args", { mode: "json" }).$type<Record<string, string>>().notNull().default({}),
  nodeArgs: text("node_args", { mode: "json" }).$type<string[]>().notNull().default([]),
  extraDockerfileLines: text("extra_dockerfile_lines", { mode: "json" }).$type<string[]>().notNull().default([]),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const insertProjectConfigSchema = createInsertSchema(projectConfigsTable).omit({
  id: true,
  updatedAt: true,
});

export const updateProjectConfigSchema = insertProjectConfigSchema.partial().omit({ projectId: true });

export type ProjectConfigRow = typeof projectConfigsTable.$inferSelect;
export type InsertProjectConfig = z.infer<typeof insertProjectConfigSchema>;
export type UpdateProjectConfig = z.infer<typeof updateProjectConfigSchema>;
