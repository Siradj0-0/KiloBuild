import { mkdirSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { drizzle } from "drizzle-orm/sqlite-proxy";
import * as schema from "./schema";

const dataDir = resolve(
  process.env["KILOBUILD_DATA_DIR"] ?? join(process.cwd(), ".kilobuild"),
);
export const databasePath = resolve(
  process.env["KILOBUILD_DB_PATH"] ?? join(dataDir, "kilobuild.sqlite"),
);

mkdirSync(dirname(databasePath), { recursive: true });

const sqlite = new DatabaseSync(databasePath, {
  enableForeignKeyConstraints: true,
  timeout: 5_000,
});

sqlite.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA synchronous = NORMAL;
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL UNIQUE,
    slug TEXT NOT NULL UNIQUE,
    path TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'created',
    node_version TEXT,
    entry_point TEXT,
    package_manager TEXT NOT NULL DEFAULT 'npm',
    project_type TEXT NOT NULL DEFAULT 'node',
    description TEXT,
    tags TEXT NOT NULL DEFAULT '[]',
    metadata TEXT NOT NULL DEFAULT '{}',
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    last_started_at INTEGER,
    last_stopped_at INTEGER
  );

  CREATE TABLE IF NOT EXISTS containers (
    id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    container_id TEXT NOT NULL UNIQUE,
    image_id TEXT,
    image_name TEXT,
    status TEXT NOT NULL DEFAULT 'unknown',
    created_at INTEGER NOT NULL,
    started_at INTEGER,
    finished_at INTEGER,
    exit_code INTEGER,
    restart_count INTEGER NOT NULL DEFAULT 0,
    error TEXT,
    last_stop_reason TEXT NOT NULL DEFAULT 'unknown'
  );

  CREATE TABLE IF NOT EXISTS project_configs (
    id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL UNIQUE REFERENCES projects(id) ON DELETE CASCADE,
    cpu_limit TEXT,
    memory_limit TEXT,
    memory_swap_limit TEXT,
    restart_policy TEXT NOT NULL DEFAULT 'unless-stopped',
    max_restarts INTEGER NOT NULL DEFAULT 10,
    restart_window_seconds INTEGER NOT NULL DEFAULT 300,
    backoff_multiplier REAL NOT NULL DEFAULT 2.0,
    cooldown_seconds INTEGER NOT NULL DEFAULT 5,
    health_check_enabled INTEGER NOT NULL DEFAULT 0,
    health_check_path TEXT,
    health_check_interval_seconds INTEGER NOT NULL DEFAULT 30,
    health_check_timeout_seconds INTEGER NOT NULL DEFAULT 10,
    health_check_retries INTEGER NOT NULL DEFAULT 3,
    env_vars TEXT NOT NULL DEFAULT '{}',
    port_bindings TEXT NOT NULL DEFAULT '[]',
    volume_bindings TEXT NOT NULL DEFAULT '[]',
    network_mode TEXT NOT NULL DEFAULT 'bridge',
    labels TEXT NOT NULL DEFAULT '{}',
    auto_install INTEGER NOT NULL DEFAULT 1,
    auto_build INTEGER NOT NULL DEFAULT 0,
    auto_migrate INTEGER NOT NULL DEFAULT 0,
    log_rotation_enabled INTEGER NOT NULL DEFAULT 1,
    log_max_size_mb INTEGER NOT NULL DEFAULT 100,
    log_retention_days INTEGER NOT NULL DEFAULT 30,
    build_args TEXT NOT NULL DEFAULT '{}',
    node_args TEXT NOT NULL DEFAULT '[]',
    extra_dockerfile_lines TEXT NOT NULL DEFAULT '[]',
    updated_at INTEGER NOT NULL
  );

  UPDATE project_configs SET cpu_limit = '0.1' WHERE cpu_limit IS NULL;
  UPDATE project_configs SET memory_limit = '128m' WHERE memory_limit IS NULL;

  CREATE TABLE IF NOT EXISTS backups (
    id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    path TEXT NOT NULL,
    size_bytes INTEGER,
    includes_logs INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    notes TEXT,
    status TEXT NOT NULL DEFAULT 'creating'
  );

  CREATE TABLE IF NOT EXISTS events_log (
    id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT REFERENCES projects(id) ON DELETE SET NULL,
    event_type TEXT NOT NULL,
    payload TEXT NOT NULL DEFAULT '{}',
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS stats_snapshots (
    id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    container_id TEXT NOT NULL,
    cpu_percent REAL NOT NULL DEFAULT 0,
    memory_used_bytes INTEGER NOT NULL DEFAULT 0,
    memory_limit_bytes INTEGER NOT NULL DEFAULT 0,
    memory_percent REAL NOT NULL DEFAULT 0,
    network_rx_bytes INTEGER NOT NULL DEFAULT 0,
    network_tx_bytes INTEGER NOT NULL DEFAULT 0,
    block_read_bytes INTEGER NOT NULL DEFAULT 0,
    block_write_bytes INTEGER NOT NULL DEFAULT 0,
    pids INTEGER NOT NULL DEFAULT 0,
    recorded_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS plugins_registry (
    id TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL UNIQUE,
    version TEXT NOT NULL,
    description TEXT,
    path TEXT,
    enabled INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'inactive',
    config TEXT NOT NULL DEFAULT '{}',
    installed_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS recovery_states (
    id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL UNIQUE REFERENCES projects(id) ON DELETE CASCADE,
    restart_count INTEGER NOT NULL DEFAULT 0,
    last_restart_at INTEGER,
    next_allowed_restart_at INTEGER,
    exhausted INTEGER NOT NULL DEFAULT 0,
    window_start_at INTEGER,
    updated_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS build_logs (
    id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    status TEXT NOT NULL DEFAULT 'pending',
    image_id TEXT,
    image_name TEXT,
    logs TEXT NOT NULL DEFAULT '[]',
    started_at INTEGER NOT NULL,
    finished_at INTEGER,
    duration_ms INTEGER,
    error TEXT
  );

  CREATE TABLE IF NOT EXISTS status_tokens (
    id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL UNIQUE REFERENCES projects(id) ON DELETE CASCADE,
    current_token TEXT NOT NULL UNIQUE,
    current_expires_at INTEGER NOT NULL,
    previous_token TEXT,
    previous_expires_at INTEGER
  );
`);

// Existing installations were created before the status dashboard fields
// existed. SQLite has no IF NOT EXISTS form for ADD COLUMN, so inspect the
// table first and apply the narrow migration only when needed.
const containerColumns = sqlite
  .prepare("PRAGMA table_info(containers)")
  .all() as Array<{ name?: string }>;
if (!containerColumns.some((column) => column.name === "last_stop_reason")) {
  sqlite.exec(
    "ALTER TABLE containers ADD COLUMN last_stop_reason TEXT NOT NULL DEFAULT 'unknown'",
  );
}

const execute = async (
  query: string,
  params: unknown[],
  method: "run" | "all" | "values" | "get",
): Promise<{ rows: any[] }> => {
  const statement = sqlite.prepare(query);
  if (method === "run") {
    statement.run(...(params as Parameters<typeof statement.run>));
    return { rows: [] };
  }

  if (method === "get") {
    const row = statement.get(...(params as Parameters<typeof statement.get>));
    // The sqlite-proxy driver expects positional rows so it can apply
    // Drizzle's column decoders (including JSON and timestamp columns).
    return { rows: row ? Object.values(row) : [] };
  }

  const rows = statement.all(...(params as Parameters<typeof statement.all>));
  return { rows: rows.map((row) => Object.values(row)) };
};

export const db = drizzle(execute, { schema });

export * from "./schema";
