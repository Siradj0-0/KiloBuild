import { defineConfig } from "drizzle-kit";
import path from "path";

const dbPath = process.env["KILOBUILD_DB_PATH"] ?? path.join(
  process.env["KILOBUILD_DATA_DIR"] ?? path.join(process.cwd(), ".kilobuild"),
  "kilobuild.sqlite",
);

export default defineConfig({
  schema: path.join(__dirname, "./src/schema/index.ts"),
  dialect: "sqlite",
  dbCredentials: {
    url: dbPath,
  },
});
