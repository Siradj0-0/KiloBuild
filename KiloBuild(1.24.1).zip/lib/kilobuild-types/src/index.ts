// ─────────────────────────────────────────────
// KiloBuild – Shared TypeScript Type Definitions
// ─────────────────────────────────────────────

// ── Project ──────────────────────────────────

export type ProjectStatus =
  | "created"
  | "building"
  | "running"
  | "stopped"
  | "error"
  | "unknown";

export type PackageManager = "npm" | "pnpm" | "yarn" | "bun";
export type ProjectType =
  | "node"
  | "typescript"
  | "discord-bot"
  | "express-api"
  | "generic";

export interface Project {
  id: string;
  name: string;
  slug: string;
  /** Absolute path to project root on the host. */
  path: string;
  status: ProjectStatus;
  nodeVersion: string | null;
  entryPoint: string | null;
  packageManager: PackageManager;
  projectType: ProjectType;
  description: string | null;
  tags: string[];
  metadata: Record<string, unknown>;
  createdAt: Date;
  updatedAt: Date;
  lastStartedAt: Date | null;
  lastStoppedAt: Date | null;
}

/** REST response shapes shared by the daemon and CLI. */
export type ProjectSummary = Project;

export interface ProjectDetail extends Project {
  container: Container | null;
  config: ProjectConfig | null;
  health?: HealthCheckResult | null;
}

export type ContainerInfo = Container;
export type BackupSummary = Backup;
export type PluginSummary = Plugin;

export interface ProjectInput {
  name: string;
  path: string;
  description?: string;
  tags?: string[];
  nodeVersion?: string;
  packageManager?: PackageManager;
  projectType?: ProjectType;
}

// ── Container ─────────────────────────────────

export type ContainerStatus =
  | "created"
  | "running"
  | "paused"
  | "restarting"
  | "removing"
  | "exited"
  | "dead"
  | "unknown";

export interface Container {
  id: string;
  projectId: string;
  /** Docker-assigned container ID (64-char hex). */
  containerId: string;
  imageId: string | null;
  imageName: string | null;
  status: ContainerStatus;
  createdAt: Date;
  startedAt: Date | null;
  finishedAt: Date | null;
  exitCode: number | null;
  restartCount: number;
  error: string | null;
  lastStopReason: "normal" | "crash" | "unknown";
}

// ── Config ────────────────────────────────────

export type RestartPolicy = "no" | "always" | "on-failure" | "unless-stopped";

export interface PortBinding {
  containerPort: number;
  /** null = auto-assign host port */
  hostPort: number | null;
  protocol: "tcp" | "udp";
}

export interface VolumeBinding {
  containerPath: string;
  hostPath: string;
  readOnly: boolean;
}

export interface ProjectConfig {
  /** e.g. "0.5" = 50% of one CPU */
  cpuLimit: string;
  /** e.g. "512m", "2g" */
  memoryLimit: string;
  memorySwapLimit: string | null;
  restartPolicy: RestartPolicy;
  maxRestarts: number;
  restartWindowSeconds: number;
  backoffMultiplier: number;
  cooldownSeconds: number;
  healthCheckEnabled: boolean;
  healthCheckPath: string | null;
  healthCheckIntervalSeconds: number;
  healthCheckTimeoutSeconds: number;
  healthCheckRetries: number;
  envVars: Record<string, string>;
  portBindings: PortBinding[];
  volumeBindings: VolumeBinding[];
  networkMode: string;
  labels: Record<string, string>;
  autoInstall: boolean;
  autoBuild: boolean;
  autoMigrate: boolean;
  logRotationEnabled: boolean;
  logMaxSizeMb: number;
  logRetentionDays: number;
  buildArgs: Record<string, string>;
  nodeArgs: string[];
  extraDockerfileLines: string[];
}

export interface GlobalConfig {
  dataDir: string;
  projectsDir: string;
  projectsRootDir: string;
  logDir: string;
  backupDir: string;
  dockerSocket: string;
  defaultNodeVersion: string;
  defaultPackageManager: PackageManager;
  defaults: Partial<ProjectConfig>;
  monitoringIntervalMs: number;
  healthCheckIntervalMs: number;
  statsRetentionDays: number;
  eventsRetentionDays: number;
  pluginsDir: string;
  apiPort: number;
  apiHost: string;
  publicStatusPort: number | null;
  publicStatusHost: string;
  publicBaseUrl: string | null;
  apiSecret: string | null;
  internalToken: string | null;
  discordWebhookUrl: string | null;
  discordBotsDir: string;
}

// ── Stats ─────────────────────────────────────

export interface ContainerStats {
  projectId: string;
  containerId: string;
  cpuPercent: number;
  memoryUsedBytes: number;
  memoryLimitBytes: number;
  memoryPercent: number;
  networkRxBytes: number;
  networkTxBytes: number;
  blockReadBytes: number;
  blockWriteBytes: number;
  pids: number;
  recordedAt: Date;
}

export interface GlobalStats {
  totalProjects: number;
  runningProjects: number;
  stoppedProjects: number;
  errorProjects: number;
  totalContainers: number;
  totalCpuPercent: number;
  totalMemoryUsedBytes: number;
  uptimeSecs: number;
  projects?: FleetProjectStats[];
}

export interface FleetProjectStats {
  projectId: string;
  name: string;
  status: ProjectStatus;
  cpuPercent: number;
  memoryUsedBytes: number;
  memoryLimitBytes: number;
  memoryPercent: number;
}

export interface DiskUsage {
  projectId: string;
  name: string;
  backupBytes: number;
  logBytes: number;
  totalBytes: number;
}

// ── Health ────────────────────────────────────

export type HealthStatus = "healthy" | "unhealthy" | "unknown" | "starting";

export interface HealthCheckResult {
  projectId: string;
  status: HealthStatus;
  message: string | null;
  checkedAt: Date;
  responseTimeMs: number | null;
}

// ── Backup ────────────────────────────────────

export type BackupStatus = "creating" | "ready" | "failed" | "deleted";

export interface Backup {
  id: string;
  projectId: string;
  name: string;
  path: string;
  sizeBytes: number | null;
  includesLogs: boolean;
  createdAt: Date;
  notes: string | null;
  status: BackupStatus;
}

export interface BackupInput {
  name?: string;
  notes?: string;
  includesLogs?: boolean;
}

// ── Discovery ─────────────────────────────────

export interface DiscoveredProject {
  path: string;
  name: string;
  packageManager: PackageManager | null;
  hasDockerfile: boolean;
  hasDockerCompose: boolean;
  nodeVersion: string | null;
  entryPoint: string | null;
  scripts: Record<string, string>;
  hasTypeScript: boolean;
  envFiles: string[];
  dependencies: Record<string, string>;
  devDependencies: Record<string, string>;
  isAlreadyManaged: boolean;
}

// ── Events ────────────────────────────────────

export type KiloBuildEventType =
  | "project:created"
  | "project:deleted"
  | "project:updated"
  | "container:started"
  | "container:stopped"
  | "container:restarted"
  | "container:crashed"
  | "container:healthy"
  | "container:unhealthy"
  | "build:started"
  | "build:completed"
  | "build:failed"
  | "backup:created"
  | "backup:restored"
  | "backup:failed"
  | "recovery:triggered"
  | "recovery:exhausted"
  | "container:exec"
  | "config:changed"
  | "plugin:loaded"
  | "plugin:unloaded"
  | "system:started"
  | "system:stopped"
  | "discovery:found";

export interface KiloBuildEvent<T = unknown> {
  id: string;
  type: KiloBuildEventType;
  projectId: string | null;
  payload: T;
  timestamp: Date;
}

// ── Logs ──────────────────────────────────────

export type LogSource =
  | "stdout"
  | "stderr"
  | "system"
  | "build"
  | "startup"
  | "shutdown"
  | "health";

export type LogLevel = "info" | "warn" | "error" | "debug";

export interface LogEntry {
  projectId: string;
  source: LogSource;
  message: string;
  timestamp: Date;
  level: LogLevel;
}

export interface LogQuery {
  projectId: string;
  source?: LogSource;
  level?: LogLevel;
  since?: Date;
  until?: Date;
  limit?: number;
  tail?: number;
}

// ── Plugins ───────────────────────────────────

export type PluginStatus = "active" | "inactive" | "error";

export interface Plugin {
  id: string;
  name: string;
  version: string;
  description: string | null;
  path: string | null;
  enabled: boolean;
  status: PluginStatus;
  config: Record<string, unknown>;
  installedAt: Date;
}

export interface PluginHooks {
  onProjectCreated?: (project: Project) => Promise<void> | void;
  onProjectDeleted?: (projectId: string) => Promise<void> | void;
  onContainerStarted?: (container: Container) => Promise<void> | void;
  onContainerStopped?: (container: Container) => Promise<void> | void;
  onContainerCrashed?: (container: Container) => Promise<void> | void;
  onHealthChanged?: (result: HealthCheckResult) => Promise<void> | void;
  onBackupCreated?: (backup: Backup) => Promise<void> | void;
  onRecoveryExhausted?: (payload: unknown) => Promise<void> | void;
  onBackupFailed?: (payload: unknown) => Promise<void> | void;
}

export interface PluginDefinition {
  name: string;
  version: string;
  description?: string;
  hooks: PluginHooks;
  initialize?: (
    config: Record<string, unknown>,
    api: PluginAPI,
  ) => Promise<void> | void;
  destroy?: () => Promise<void> | void;
}

export interface PluginAPI {
  on: (...args: any[]) => any;
  emit: (type: string, projectId: string | null, payload: unknown) => void;
  getConfig: () => Record<string, unknown>;
}

// ── Templates ─────────────────────────────────

export interface ProjectTemplateFiles {
  dockerfile: string;
  dockerCompose: string;
  startupScript: string;
  envTemplate: string;
  dockerignore: string;
  kiloBuildConfig: string;
}

export interface TemplateContext {
  projectName: string;
  projectSlug: string;
  nodeVersion: string;
  packageManager: PackageManager;
  entryPoint: string;
  nodeArgs?: string[];
  hasTypeScript: boolean;
  ports: number[];
  volumes: string[];
  envVars: Record<string, string>;
  buildCommand: string | null;
  startCommand: string;
  projectType: ProjectType;
  extraDockerfileLines?: string[];
  autoInstall?: boolean;
  autoBuild?: boolean;
  autoMigrate?: boolean;
}

// ── Recovery ──────────────────────────────────

export interface RestartRecord {
  projectId: string;
  timestamp: Date;
  reason: string;
  exitCode: number | null;
  attempt: number;
}

export interface RecoveryState {
  projectId: string;
  restartCount: number;
  lastRestartAt: Date | null;
  nextAllowedRestartAt: Date | null;
  exhausted: boolean;
  windowStartAt: Date | null;
}

// ── Build ─────────────────────────────────────

export type BuildStatus = "pending" | "running" | "success" | "failed";

export interface BuildResult {
  buildId: string;
  projectId: string;
  status: BuildStatus;
  imageId: string | null;
  imageName: string | null;
  startedAt: Date;
  finishedAt: Date | null;
  durationMs: number | null;
  error: string | null;
  logs: string[];
}

// ── Doctor / System check ─────────────────────

export type DiagnosticStatus = "ok" | "warning" | "error";

export interface DiagnosticCheck {
  name: string;
  status: DiagnosticStatus;
  message: string;
  detail?: string;
}

export interface DoctorReport {
  overall: DiagnosticStatus;
  checks: DiagnosticCheck[];
  generatedAt: Date;
}
