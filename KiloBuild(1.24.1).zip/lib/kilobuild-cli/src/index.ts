#!/usr/bin/env node
import { Command } from "commander";
import chalk from "chalk";
import { listCommand } from "./commands/list.js";
import { createCommand } from "./commands/create.js";
import { importCommand } from "./commands/import.js";
import { startCommand } from "./commands/start.js";
import { stopCommand } from "./commands/stop.js";
import { restartCommand } from "./commands/restart.js";
import { rebuildCommand } from "./commands/rebuild.js";
import { deleteCommand } from "./commands/delete.js";
import { logsCommand } from "./commands/logs.js";
import { inspectCommand } from "./commands/inspect.js";
import { statsCommand } from "./commands/stats.js";
import { healthCommand } from "./commands/health.js";
import { backupCommand } from "./commands/backup.js";
import { restoreCommand } from "./commands/restore.js";
import { configCommand } from "./commands/config.js";
import { discoverCommand } from "./commands/discover.js";
import { doctorCommand } from "./commands/doctor.js";
import { pluginsCommand } from "./commands/plugins.js";
import { eventsCommand } from "./commands/events.js";
import { fleetCommand } from "./commands/fleet.js";
import { diskCommand } from "./commands/disk.js";
import { shellCommand } from "./commands/shell.js";
import { updateCommand } from "./commands/update.js";
import { versionCommand } from "./commands/version.js";
import { KILOBUILD_VERSION } from "./version.js";

const program = new Command();

program
  .name("kilo")
  .description(
    chalk.bold("KiloBuild") +
      " – production-grade Node.js app manager\n" +
      chalk.dim("  Manage unlimited Node.js applications in isolated Docker containers.\n") +
      chalk.dim("  Docs: https://github.com/yourusername/kilobuild"),
  )
  .version(KILOBUILD_VERSION, "-v, --version", "Print KiloBuild version")
  .option("--api <url>", "Override daemon API URL", process.env["KILOBUILD_API_URL"])
  .hook("preAction", (thisCommand) => {
    const opts = thisCommand.opts() as { api?: string };
    if (opts.api) {
      process.env["KILOBUILD_API_URL"] = opts.api;
    }
  });

// ── Project management ────────────────────────
program.addCommand(listCommand());
program.addCommand(createCommand());
program.addCommand(importCommand());
program.addCommand(deleteCommand());

// ── Lifecycle ─────────────────────────────────
program.addCommand(startCommand());
program.addCommand(stopCommand());
program.addCommand(restartCommand());
program.addCommand(rebuildCommand());

// ── Observability ─────────────────────────────
program.addCommand(logsCommand());
program.addCommand(eventsCommand());
program.addCommand(fleetCommand());
program.addCommand(diskCommand());
program.addCommand(shellCommand());
program.addCommand(inspectCommand());
program.addCommand(statsCommand());
program.addCommand(healthCommand());

// ── Backup / restore ──────────────────────────
program.addCommand(backupCommand());
program.addCommand(restoreCommand());

// ── Config ────────────────────────────────────
program.addCommand(configCommand());

// ── Discovery ─────────────────────────────────
program.addCommand(discoverCommand());

// ── System ────────────────────────────────────
program.addCommand(doctorCommand());
program.addCommand(pluginsCommand());
program.addCommand(versionCommand());
program.addCommand(updateCommand());

program.configureOutput({
  outputError: (str, write) => write(chalk.red(str)),
});

program.parseAsync(process.argv).catch((error: unknown) => {
  if (error instanceof Error) {
    console.error(chalk.red("Error: ") + error.message);
  } else {
    console.error(chalk.red("Unknown error"));
  }
  process.exit(1);
});
