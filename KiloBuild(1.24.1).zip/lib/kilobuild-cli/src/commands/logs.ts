import { Command } from "commander";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { colorLevel, err } from "../utils/formatter.js";
import type { LogEntry } from "@workspace/kilobuild-types";

export function logsCommand(): Command {
  return new Command("logs")
    .description("View logs for a project")
    .argument("<name>", "Project name or ID")
    .option("-n, --tail <n>", "Number of lines to show", "200")
    .option("-s, --source <source>", "Filter by source: stdout|stderr|system|build|startup|shutdown")
    .option("--since <date>", "Show logs since datetime (ISO 8601)")
    .option("-f, --follow", "Follow logs in real time")
    .option("--json", "Output as JSON")
    .action(
      async (
        name: string,
        opts: { tail: string; source?: string; since?: string; follow?: boolean; json?: boolean },
      ) => {
        try {
          const params = new URLSearchParams({ tail: opts.tail });
          if (opts.source) params.set("source", opts.source);
          if (opts.since) params.set("since", opts.since);
          if (opts.follow) params.set("follow", "true");

          if (opts.follow) {
            const request = api.stream(`/projects/${name}/logs?${params}`, ({ data }) => {
              try {
                const entry = JSON.parse(data) as LogEntry;
                const ts = new Date(entry.timestamp).toISOString().slice(11, 23);
                console.log(`${chalk.dim(ts)} ${colorLevel(entry.level)} ${chalk.dim(entry.source.padEnd(8))} ${entry.message}`);
              } catch {
                console.log(data);
              }
            });
            request.on("error", (error) => {
              if (error instanceof ApiError) err(error.message);
              else err(String(error));
              process.exit(1);
            });
            return;
          }

          const logs = await api.get<LogEntry[]>(`/projects/${name}/logs?${params.toString()}`);

          if (opts.json) {
            console.log(JSON.stringify(logs, null, 2));
            return;
          }

          if (logs.length === 0) {
            console.log(chalk.dim("No logs found."));
            return;
          }

          for (const entry of logs) {
            const ts = new Date(entry.timestamp).toISOString().slice(11, 23);
            const level = colorLevel(entry.level);
            const src = chalk.dim(entry.source.padEnd(8));
            console.log(`${chalk.dim(ts)} ${level} ${src} ${entry.message}`);
          }
        } catch (error) {
          if (error instanceof ApiError) err(error.message);
          else err(String(error));
          process.exit(1);
        }
      },
    );
}
