import { Command } from "commander";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { makeTable, colorStatus, formatRelative, err } from "../utils/formatter.js";
import type { ProjectSummary } from "@workspace/kilobuild-types";

export function listCommand(): Command {
  return new Command("list")
    .alias("ls")
    .description("List all managed projects")
    .option("-s, --status <status>", "Filter by status")
    .option("--tag <tag>", "Filter by tag")
    .option("-q, --query <q>", "Search by name")
    .option("--json", "Output as JSON")
    .action(async (opts: { status?: string; tag?: string; query?: string; json?: boolean }) => {
      try {
        const params = new URLSearchParams();
        if (opts.status) params.set("status", opts.status);
        if (opts.tag) params.set("tag", opts.tag);
        if (opts.query) params.set("q", opts.query);
        const qs = params.toString() ? `?${params.toString()}` : "";

        const projects = await api.get<ProjectSummary[]>(`/projects${qs}`);

        if (opts.json) {
          console.log(JSON.stringify(projects, null, 2));
          return;
        }

        if (projects.length === 0) {
          console.log(chalk.dim("No projects found. Run `kilo create <name>` to get started."));
          return;
        }

        const table = makeTable(["Name", "Status", "Type", "Node", "Package Manager", "Updated"]);
        for (const p of projects) {
          table.push([
            chalk.bold(p.name),
            colorStatus(p.status),
            p.projectType,
            p.nodeVersion ?? chalk.dim("auto"),
            p.packageManager,
            formatRelative(new Date(p.updatedAt)),
          ]);
        }
        console.log(table.toString());
        console.log(chalk.dim(`  ${projects.length} project${projects.length === 1 ? "" : "s"}`));
      } catch (error) {
        if (error instanceof ApiError) {
          err(error.message);
        } else {
          err(String(error));
        }
        process.exit(1);
      }
    });
}
