import { Command } from "commander";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { err } from "../utils/formatter.js";

interface ExecResult {
  command: string[];
  exitCode: number;
  output: string;
}

export function shellCommand(): Command {
  return new Command("shell")
    .description("Execute a command inside a running project container")
    .argument("<project>", "Project name or ID")
    .argument("[command...]", "Command and arguments", ["sh"])
    .action(async (project: string, command: string[]) => {
      try {
        const result = await api.post<ExecResult>(`/projects/${project}/exec`, { cmd: command });
        process.stdout.write(result.output);
        if (result.exitCode !== 0) {
          console.error(chalk.red(`\nCommand exited with code ${result.exitCode}`));
          process.exitCode = result.exitCode;
        }
      } catch (error) {
        err(error instanceof ApiError ? error.message : String(error));
        process.exit(1);
      }
    });
}