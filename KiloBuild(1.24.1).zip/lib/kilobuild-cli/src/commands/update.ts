import { Command } from "commander";
import { cp, mkdtemp, mkdir, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import { basename, join, resolve } from "node:path";
import { tmpdir } from "node:os";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { createInterface } from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import ora from "ora";
import { KILOBUILD_VERSION } from "../version.js";
import { err, info, ok, warn } from "../utils/formatter.js";

const execFileAsync = promisify(execFile);
const IDENTIFIER = /^[A-Za-z0-9._-]+$/;
const VERSIONED_RELEASE = /^KiloBuild\((\d+\.\d+\.\d+)\)\.zip$/i;
const DEFAULT_OWNER = "Siradj0-0";
const DEFAULT_REPOSITORY = "KiloBuild";
const DEFAULT_BRANCH = "main";

interface UpdateConfig {
  owner: string;
  repository: string;
  branch: string;
  installPath: string;
}

interface Release {
  version: string;
  downloadUrl: string;
  fileName: string;
}

function defaultDataDir(): string {
  if (process.env["KILOBUILD_DATA_DIR"]) return resolve(process.env["KILOBUILD_DATA_DIR"]);
  const standardInstall = "/opt/kilobuild/.kilobuild";
  return existsSync(standardInstall) ? standardInstall : resolve(join(process.cwd(), ".kilobuild"));
}

function dataDir(): string {
  return defaultDataDir();
}

function updateConfigPath(): string {
  return join(dataDir(), "update.json");
}

async function readUpdateConfig(): Promise<UpdateConfig | null> {
  try {
    const raw = JSON.parse(await readFile(updateConfigPath(), "utf8")) as Partial<UpdateConfig>;
    if (
      typeof raw.owner === "string" &&
      typeof raw.repository === "string" &&
      typeof raw.branch === "string" &&
      typeof raw.installPath === "string"
    ) {
      return raw as UpdateConfig;
    }
  } catch {
    // A missing or malformed setup file is handled by the guided setup.
  }
  return null;
}

async function askForConfig(existing?: Partial<UpdateConfig>): Promise<UpdateConfig> {
  const rl = createInterface({ input, output });
  try {
    const answer = async (label: string, fallback: string) => {
      const value = (await rl.question(`${label} [${fallback}]: `)).trim();
      return value || fallback;
    };
    const owner = await answer("GitHub owner or organization", existing?.owner ?? DEFAULT_OWNER);
    const repository = await answer("Public repository name", existing?.repository ?? DEFAULT_REPOSITORY);
    const branch = await answer("Release branch", existing?.branch ?? DEFAULT_BRANCH);
    const installPath = resolve(
      await answer(
        "Local KiloBuild installation path",
        existing?.installPath ?? (existsSync("/opt/kilobuild") ? "/opt/kilobuild" : process.cwd()),
      ),
    );

    if (!IDENTIFIER.test(owner) || !IDENTIFIER.test(repository) || !IDENTIFIER.test(branch)) {
      throw new Error(
        "Owner, repository, and branch may contain only letters, numbers, dots, underscores, and hyphens.",
      );
    }
    if (!existsSync(join(installPath, "package.json")) || !existsSync(join(installPath, "VERSION"))) {
      throw new Error(`No KiloBuild installation was found at ${installPath}.`);
    }

    const config = { owner, repository, branch, installPath };
    await mkdir(dataDir(), { recursive: true });
    await writeFile(updateConfigPath(), `${JSON.stringify(config, null, 2)}\n`, { mode: 0o600 });
    ok(`Saved public release source: https://github.com/${owner}/${repository}`);
    return config;
  } finally {
    rl.close();
  }
}

function compareVersions(left: string, right: string): number {
  const a = left.split(".").map(Number);
  const b = right.split(".").map(Number);
  for (let index = 0; index < 3; index += 1) {
    if (a[index] !== b[index]) return (a[index] ?? 0) - (b[index] ?? 0);
  }
  return 0;
}

function isVersion(value: string): boolean {
  return /^\d+\.\d+\.\d+$/.test(value);
}

async function githubJson<T>(url: string): Promise<T> {
  const response = await fetch(url, {
    headers: {
      Accept: "application/vnd.github+json",
      "User-Agent": "KiloBuild-updater",
    },
  });
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 300);
    throw new Error(`GitHub returned ${response.status} for ${url}${detail ? `: ${detail}` : ""}`);
  }
  return (await response.json()) as T;
}

async function findLatestRelease(config: UpdateConfig): Promise<Release | null> {
  const endpoint =
    `https://api.github.com/repos/${encodeURIComponent(config.owner)}` +
    `/${encodeURIComponent(config.repository)}/contents?ref=${encodeURIComponent(config.branch)}`;
  let entries: Array<{ name?: string; download_url?: string | null }>;
  try {
    entries = await githubJson<Array<{ name?: string; download_url?: string | null }>>(endpoint);
  } catch (error) {
    // GitHub returns 404 for the contents of an empty repository. Treat that
    // as "no releases yet" so the first manual upload has a clear workflow.
    if (error instanceof Error && error.message.startsWith("GitHub returned 404")) return null;
    throw error;
  }
  const releases = entries.flatMap((entry) => {
    const match = entry.name?.match(VERSIONED_RELEASE);
    if (!match || !entry.download_url || !isVersion(match[1]!)) return [];
    return [{ version: match[1]!, downloadUrl: entry.download_url, fileName: entry.name! }];
  });
  releases.sort((left, right) => compareVersions(right.version, left.version));
  return releases[0] ?? null;
}

async function downloadRelease(release: Release, target: string): Promise<void> {
  const response = await fetch(release.downloadUrl, {
    headers: { Accept: "application/octet-stream", "User-Agent": "KiloBuild-updater" },
  });
  if (!response.ok) throw new Error(`Could not download ${release.fileName} (${response.status}).`);
  await writeFile(target, Buffer.from(await response.arrayBuffer()), { mode: 0o600 });
}

async function validateArchive(archive: string, stagingDir: string, release: Release): Promise<void> {
  await execFileAsync("unzip", ["-t", archive], { maxBuffer: 2 * 1024 * 1024 });
  const { stdout } = await execFileAsync("unzip", ["-Z1", archive], { maxBuffer: 8 * 1024 * 1024 });
  for (const entry of stdout.split(/\r?\n/).filter(Boolean)) {
    if (entry.startsWith("/") || entry.split("/").includes("..")) {
      throw new Error(`Release archive contains an unsafe path: ${entry}`);
    }
  }

  await execFileAsync("unzip", ["-q", archive, "-d", stagingDir], { maxBuffer: 2 * 1024 * 1024 });
  const version = (await readFile(join(stagingDir, "VERSION"), "utf8")).trim();
  if (version !== release.version) {
    throw new Error(
      `Release filename and VERSION disagree: ${release.fileName} declares ${release.version}, archive declares ${version}.`,
    );
  }
}

async function backupData(): Promise<string> {
  const source = dataDir();
  if (!existsSync(source)) return "";
  const backup = `${source}-update-backup-${new Date().toISOString().replace(/[:.]/g, "-")}`;
  await cp(source, backup, { recursive: true, errorOnExist: true });
  return backup;
}

async function syncRelease(source: string, destination: string): Promise<void> {
  await mkdir(destination, { recursive: true });
  const entries = await readdir(source, { withFileTypes: true });
  for (const entry of entries) {
    // Runtime state is never part of a release and is never replaced by one.
    if (entry.name === ".kilobuild" || entry.name === ".git") continue;
    const sourcePath = join(source, entry.name);
    const destinationPath = join(destination, entry.name);
    if (entry.isDirectory()) {
      await mkdir(destinationPath, { recursive: true });
      await syncRelease(sourcePath, destinationPath);
      continue;
    }
    await rm(destinationPath, { force: true });
    await cp(sourcePath, destinationPath, { force: true });
  }
}

async function installRelease(config: UpdateConfig, release: Release): Promise<void> {
  const workingDir = await mkdtemp(join(tmpdir(), "kilobuild-update-"));
  const archive = join(workingDir, release.fileName);
  const stagingDir = join(workingDir, "release");
  await mkdir(stagingDir);

  try {
    await downloadRelease(release, archive);
    await validateArchive(archive, stagingDir, release);
    const backup = await backupData();
    if (backup) info(`Protected project data with a backup at ${backup}`);

    await syncRelease(stagingDir, config.installPath);
    const installer = join(config.installPath, "scripts", "install-vps.sh");
    if (!existsSync(installer)) throw new Error("The downloaded release is missing scripts/install-vps.sh.");

    const spinner = ora(`Installing KiloBuild ${release.version}...`).start();
    try {
      await execFileAsync("bash", [installer], {
        cwd: config.installPath,
        env: { ...process.env, KILOBUILD_DATA_DIR: dataDir() },
        maxBuffer: 8 * 1024 * 1024,
      });
      spinner.succeed(`KiloBuild updated to ${release.version}`);
    } catch (error) {
      spinner.fail("The update installer failed");
      throw error;
    }
  } finally {
    await rm(workingDir, { recursive: true, force: true });
  }
}

async function resolveConfig(setup: boolean): Promise<UpdateConfig> {
  const existing = await readUpdateConfig();
  if (setup || !existing) return askForConfig(existing ?? undefined);
  return existing;
}

export function updateCommand(): Command {
  return new Command("update")
    .description("Safely update KiloBuild from the highest versioned GitHub release ZIP")
    .option("--setup", "Ask for or replace the public GitHub repository details")
    .option("--check", "Check for updates without installing one")
    .action(async (opts: { setup?: boolean; check?: boolean }) => {
      try {
        const config = await resolveConfig(Boolean(opts.setup));
        const installedVersion = (await readFile(join(config.installPath, "VERSION"), "utf8")).trim();
        if (!isVersion(installedVersion)) {
          throw new Error(`The installed VERSION file is invalid: "${installedVersion}"`);
        }

        const latest = await findLatestRelease(config);
        if (!latest) {
          warn(`No KiloBuild(x.y.z).zip releases were found in https://github.com/${config.owner}/${config.repository}.`);
          return;
        }

        info(`Installed KiloBuild ${installedVersion}; highest available ZIP is ${latest.version}.`);
        const comparison = compareVersions(latest.version, installedVersion);
        if (comparison <= 0) {
          ok(`KiloBuild ${installedVersion} is up to date.`);
          return;
        }
        if (opts.check) {
          warn(`A newer KiloBuild release is available: ${latest.fileName}`);
          return;
        }

        await installRelease(config, latest);
      } catch (error) {
        err(error instanceof Error ? error.message : String(error));
        process.exitCode = 1;
      }
    });
}