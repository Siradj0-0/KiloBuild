import { Command } from "commander";
import chalk from "chalk";
import ora from "ora";
import { api, ApiError } from "../utils/api-client.js";
import { makeTable, colorStatus, formatRelative, err, ok } from "../utils/formatter.js";
import type { PluginSummary } from "@workspace/kilobuild-types";

export function pluginsCommand(): Command {
  const cmd = new Command("plugins").description("Manage KiloBuild plugins");

  cmd
    .command("list")
    .alias("ls")
    .description("List installed plugins")
    .action(async () => {
      try {
        const plugins = await api.get<PluginSummary[]>("/plugins");
        if (plugins.length === 0) {
          console.log(chalk.dim("No plugins installed."));
          return;
        }
        const table = makeTable(["Name", "Version", "Status", "Installed"]);
        for (const p of plugins) {
          table.push([
            chalk.bold(p.name),
            p.version,
            colorStatus(p.enabled ? "running" : "stopped"),
            formatRelative(new Date(p.installedAt)),
          ]);
        }
        console.log(table.toString());
      } catch (error) {
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });

  cmd
    .command("enable <name>")
    .description("Enable a plugin")
    .action(async (name: string) => {
      const spinner = ora(`Enabling ${chalk.bold(name)}...`).start();
      try {
        await api.post<PluginSummary>(`/plugins/${name}/enable`);
        spinner.succeed(`Plugin ${chalk.bold(name)} enabled`);
      } catch (error) {
        spinner.fail("Failed to enable plugin");
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });

  cmd
    .command("disable <name>")
    .description("Disable a plugin")
    .action(async (name: string) => {
      const spinner = ora(`Disabling ${chalk.bold(name)}...`).start();
      try {
        await api.post<PluginSummary>(`/plugins/${name}/disable`);
        spinner.succeed(`Plugin ${chalk.bold(name)} disabled`);
      } catch (error) {
        spinner.fail("Failed to disable plugin");
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });

  return cmd;
}
