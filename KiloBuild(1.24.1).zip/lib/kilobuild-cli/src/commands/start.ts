import { Command } from "commander";
import ora from "ora";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { ok, err, colorStatus } from "../utils/formatter.js";
import type { ContainerInfo } from "@workspace/kilobuild-types";

export function startCommand(): Command {
  return new Command("start")
    .description("Start a project container")
    .argument("<name>", "Project name or ID")
    .action(async (name: string) => {
      const spinner = ora(`Starting ${chalk.bold(name)}...`).start();
      try {
        const container = await api.post<ContainerInfo>(`/projects/${name}/start`);
        spinner.succeed(`${chalk.bold(name)} started — ${colorStatus(container.status)}`);
      } catch (error) {
        spinner.fail(`Failed to start ${name}`);
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });
}
