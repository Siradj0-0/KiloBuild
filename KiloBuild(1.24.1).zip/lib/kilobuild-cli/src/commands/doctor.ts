import { Command } from "commander";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { err } from "../utils/formatter.js";
import type { DoctorReport } from "@workspace/kilobuild-types";

export function doctorCommand(): Command {
  return new Command("doctor")
    .description("Run system diagnostics and check KiloBuild health")
    .option("--json", "Output as JSON")
    .action(async (opts: { json?: boolean }) => {
      try {
        const report = await api.get<DoctorReport>("/doctor");

        if (opts.json) {
          console.log(JSON.stringify(report, null, 2));
          return;
        }

        const icon = {
          ok: chalk.green("✓"),
          warning: chalk.yellow("⚠"),
          error: chalk.red("✗"),
        };

        console.log(chalk.bold.cyan("\n  KiloBuild Doctor\n"));

        for (const check of report.checks) {
          const i = icon[check.status];
          console.log(`  ${i} ${check.name}: ${check.message}`);
          if (check.detail) {
            console.log(chalk.dim(`      ${check.detail}`));
          }
        }

        const overallIcon = icon[report.overall];
        console.log(
          `\n  Overall: ${overallIcon} ${chalk.bold(report.overall.toUpperCase())}\n`,
        );

        if (report.overall !== "ok") process.exit(1);
      } catch (error) {
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });
}
