import { Command } from "commander";
import ora from "ora";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { err, colorStatus } from "../utils/formatter.js";
import type { ContainerInfo } from "@workspace/kilobuild-types";

export function restartCommand(): Command {
  return new Command("restart")
    .description("Restart a project container")
    .argument("<name>", "Project name or ID")
    .action(async (name: string) => {
      const spinner = ora(`Restarting ${chalk.bold(name)}...`).start();
      try {
        const container = await api.post<ContainerInfo>(`/projects/${name}/restart`);
        spinner.succeed(`${chalk.bold(name)} restarted — ${colorStatus(container.status)}`);
      } catch (error) {
        spinner.fail(`Failed to restart ${name}`);
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });
}
