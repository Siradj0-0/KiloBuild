import { Command } from "commander";
import ora from "ora";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { makeTable, formatBytes, formatRelative, err, ok } from "../utils/formatter.js";
import type { BackupSummary } from "@workspace/kilobuild-types";

export function backupCommand(): Command {
  const cmd = new Command("backup").description("Backup and restore management");

  cmd
    .command("create <name>")
    .description("Create a backup of a project")
    .option("-n, --backup-name <name>", "Backup name")
    .option("--notes <notes>", "Notes about this backup")
    .option("--include-logs", "Include log files in backup")
    .action(
      async (
        name: string,
        opts: { backupName?: string; notes?: string; includeLogs?: boolean },
      ) => {
        const spinner = ora(`Creating backup of ${chalk.bold(name)}...`).start();
        try {
          const backup = await api.post<BackupSummary>(`/projects/${name}/backups`, {
            name: opts.backupName,
            notes: opts.notes,
            includesLogs: opts.includeLogs,
          });
          spinner.succeed(`Backup created: ${chalk.bold(backup.name)}`);
          if (backup.sizeBytes) ok(`Size: ${formatBytes(backup.sizeBytes)}`);
          ok(`ID:   ${backup.id}`);
        } catch (error) {
          spinner.fail("Backup failed");
          if (error instanceof ApiError) err(error.message);
          else err(String(error));
          process.exit(1);
        }
      },
    );

  cmd
    .command("list <name>")
    .description("List backups for a project")
    .action(async (name: string) => {
      try {
        const backups = await api.get<BackupSummary[]>(`/projects/${name}/backups`);
        if (backups.length === 0) {
          console.log(chalk.dim("No backups found."));
          return;
        }
        const table = makeTable(["ID", "Name", "Size", "Status", "Created", "Notes"]);
        for (const b of backups) {
          table.push([
            b.id.slice(0, 8),
            b.name,
            b.sizeBytes ? formatBytes(b.sizeBytes) : chalk.dim("—"),
            b.status,
            formatRelative(new Date(b.createdAt)),
            b.notes ?? chalk.dim("—"),
          ]);
        }
        console.log(table.toString());
      } catch (error) {
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });

  return cmd;
}
