import { Command } from "commander";
import { join, resolve } from "node:path";
import ora from "ora";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { ok, err, info } from "../utils/formatter.js";
import type { GlobalConfig, ProjectDetail } from "@workspace/kilobuild-types";

export function createCommand(): Command {
  return new Command("create")
    .description("Create a new KiloBuild project")
    .argument("<name>", "Project name (unique identifier)")
    .argument("[path]", "Path to project directory (defaults to ./<name>)")
    .option("-d, --description <desc>", "Project description")
    .option("--node <version>", "Node.js version (e.g. 22)")
    .option("--pm <manager>", "Package manager: npm|pnpm|yarn|bun")
    .option("--type <type>", "Project type: node|typescript|discord-bot|express-api|generic")
    .option("--tag <tags...>", "Tags for this project")
    .action(
      async (
        name: string,
        pathArg: string | undefined,
        opts: {
          description?: string;
          node?: string;
          pm?: string;
          type?: string;
          tag?: string[];
        },
      ) => {
        const spinner = ora(`Creating project ${chalk.bold(name)}...`).start();

        try {
           const projectPath = resolve(
             pathArg ?? join((await api.get<GlobalConfig>("/config")).projectsRootDir, name),
           );
          const project = await api.post<ProjectDetail>("/projects", {
            name,
            path: projectPath,
            description: opts.description,
            nodeVersion: opts.node,
            packageManager: opts.pm,
            projectType: opts.type,
            tags: opts.tag ?? [],
          });

          spinner.succeed(`Project ${chalk.bold(project.name)} created`);
          ok(`ID:   ${project.id}`);
          ok(`Path: ${project.path}`);
          info(`Run ${chalk.cyan(`kilo start ${project.name}`)} to start the container`);
        } catch (error) {
          spinner.fail("Failed to create project");
          if (error instanceof ApiError) {
            err(error.message);
          } else {
            err(String(error));
          }
          process.exit(1);
        }
      },
    );
}
