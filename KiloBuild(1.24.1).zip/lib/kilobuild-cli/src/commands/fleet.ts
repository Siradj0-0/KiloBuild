import { Command } from "commander";
import { api, ApiError } from "../utils/api-client.js";
import { colorStatus, err, formatBytes, makeTable } from "../utils/formatter.js";
import type { GlobalStats } from "@workspace/kilobuild-types";

export function fleetCommand(): Command {
  return new Command("fleet")
    .description("Show status and resource usage for every project")
    .option("--json", "Output as JSON")
    .action(async (opts: { json?: boolean }) => {
      try {
        const stats = await api.get<GlobalStats>("/stats");
        if (opts.json) {
          console.log(JSON.stringify(stats.projects ?? [], null, 2));
          return;
        }
        const table = makeTable(["Project", "Status", "CPU", "Memory", "Limit"]);
        for (const project of stats.projects ?? []) {
          table.push([
            project.name,
            colorStatus(project.status),
            `${project.cpuPercent.toFixed(1)}%`,
            formatBytes(project.memoryUsedBytes),
            formatBytes(project.memoryLimitBytes),
          ]);
        }
        console.log(table.toString());
      } catch (error) {
        err(error instanceof ApiError ? error.message : String(error));
        process.exit(1);
      }
    });
}