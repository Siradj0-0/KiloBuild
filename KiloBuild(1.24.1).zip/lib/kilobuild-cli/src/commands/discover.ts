import { Command } from "commander";
import { resolve } from "node:path";
import ora from "ora";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { makeTable, err } from "../utils/formatter.js";
import type { DiscoveredProject } from "@workspace/kilobuild-types";

export function discoverCommand(): Command {
  return new Command("discover")
    .description("Scan directories and discover Node.js projects")
    .argument("[dirs...]", "Directories to scan (default: current directory)")
    .option("-d, --depth <n>", "Max scan depth", "3")
    .option("--json", "Output as JSON")
    .action(
      async (dirs: string[], opts: { depth: string; json?: boolean }) => {
        const roots = (dirs.length > 0 ? dirs : ["."]).map((d) => resolve(d));
        const spinner = ora(`Scanning ${roots.join(", ")}...`).start();

        try {
          const projects = await api.post<DiscoveredProject[]>("/discover", {
            roots,
            maxDepth: parseInt(opts.depth, 10),
          });
          spinner.succeed(`Found ${projects.length} project${projects.length === 1 ? "" : "s"}`);

          if (opts.json) {
            console.log(JSON.stringify(projects, null, 2));
            return;
          }

          if (projects.length === 0) {
            console.log(chalk.dim("No Node.js projects found."));
            return;
          }

          const table = makeTable(["Path", "Name", "PM", "Node", "TypeScript", "Managed"]);
          for (const p of projects) {
            table.push([
              chalk.dim(p.path.replace(process.cwd(), ".")),
              chalk.bold(p.name),
              p.packageManager ?? chalk.dim("—"),
              p.nodeVersion ?? chalk.dim("auto"),
              p.hasTypeScript ? chalk.green("yes") : chalk.dim("no"),
              p.isAlreadyManaged ? chalk.green("yes") : chalk.dim("no"),
            ]);
          }
          console.log(table.toString());
        } catch (error) {
          spinner.fail("Discovery failed");
          if (error instanceof ApiError) err(error.message);
          else err(String(error));
          process.exit(1);
        }
      },
    );
}
