import { Command } from "commander";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { colorStatus, formatBytes, formatRelative, err } from "../utils/formatter.js";
import type { ProjectDetail } from "@workspace/kilobuild-types";

export function inspectCommand(): Command {
  return new Command("inspect")
    .description("Show detailed information about a project")
    .argument("<name>", "Project name or ID")
    .option("--json", "Output as JSON")
    .action(async (name: string, opts: { json?: boolean }) => {
      try {
        const project = await api.get<ProjectDetail>(`/projects/${name}`);

        if (opts.json) {
          console.log(JSON.stringify(project, null, 2));
          return;
        }

        const section = (title: string) =>
          console.log("\n" + chalk.bold.underline(title));
        const row = (label: string, value: string) =>
          console.log(`  ${chalk.dim(label.padEnd(20))} ${value}`);

        console.log(chalk.bold.cyan(`\n  ${project.name}`));
        row("ID", project.id);
        row("Status", colorStatus(project.status));
        row("Path", project.path);
        row("Type", project.projectType);
        row("Node Version", project.nodeVersion ?? chalk.dim("auto"));
        row("Package Manager", project.packageManager);
        row("Entry Point", project.entryPoint ?? chalk.dim("auto"));
        if (project.description) row("Description", project.description);
        if (project.tags?.length) row("Tags", project.tags.join(", "));
        row("Created", formatRelative(new Date(project.createdAt)));
        row("Updated", formatRelative(new Date(project.updatedAt)));

        if (project.container) {
          section("Container");
          const c = project.container;
          row("Container ID", c.containerId.slice(0, 12));
          row("Status", colorStatus(c.status));
          if (c.imageName) row("Image", c.imageName);
          if (c.startedAt) row("Started", formatRelative(new Date(c.startedAt)));
          row("Restarts", String(c.restartCount));
          if (c.exitCode !== null) row("Exit Code", String(c.exitCode));
          if (c.error) row("Error", chalk.red(c.error));
        }

        if (project.health) {
          section("Health");
          const h = project.health;
          row("Status", colorStatus(h.status));
          if (h.message) row("Message", h.message);
          if (h.responseTimeMs !== null) row("Response Time", `${h.responseTimeMs}ms`);
          row("Checked", formatRelative(new Date(h.checkedAt)));
        }

        if (project.config) {
          section("Configuration");
          const c = project.config;
          row("Restart Policy", c.restartPolicy);
          row("Max Restarts", String(c.maxRestarts));
          if (c.memoryLimit) row("Memory Limit", c.memoryLimit);
          if (c.cpuLimit) row("CPU Limit", c.cpuLimit);
          row("Health Check", c.healthCheckEnabled ? "enabled" : "disabled");
          if (c.portBindings.length > 0) {
            row(
              "Ports",
              c.portBindings
                .map((pb) => `${pb.hostPort ?? "auto"}:${pb.containerPort}`)
                .join(", "),
            );
          }
        }

        console.log();
      } catch (error) {
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });
}
