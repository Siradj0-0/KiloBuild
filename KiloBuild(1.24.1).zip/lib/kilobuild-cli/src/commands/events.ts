import { Command } from "commander";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { err, formatRelative } from "../utils/formatter.js";

interface EventRow {
  id: string;
  eventType: string;
  payload: unknown;
  createdAt: string;
}

export function eventsCommand(): Command {
  return new Command("events")
    .description("Show lifecycle events for a project")
    .argument("<project>", "Project name or ID")
    .option("-n, --limit <n>", "Number of events", "100")
    .option("--type <type>", "Filter by event type")
    .option("--json", "Output as JSON")
    .action(async (project: string, opts: { limit: string; type?: string; json?: boolean }) => {
      try {
        const params = new URLSearchParams({ projectId: project, limit: opts.limit });
        if (opts.type) params.set("type", opts.type);
        const rows = await api.get<EventRow[]>(`/events?${params}`);
        if (opts.json) {
          console.log(JSON.stringify(rows, null, 2));
          return;
        }
        if (rows.length === 0) {
          console.log(chalk.dim("No events found."));
          return;
        }
        for (const row of rows) {
          console.log(`${chalk.dim(formatRelative(new Date(row.createdAt)).padEnd(10))} ${chalk.cyan(row.eventType)} ${chalk.dim(JSON.stringify(row.payload))}`);
        }
      } catch (error) {
        err(error instanceof ApiError ? error.message : String(error));
        process.exit(1);
      }
    });
}