import { Command } from "commander";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { makeTable, formatBytes, err } from "../utils/formatter.js";
import type { ContainerStats, GlobalStats } from "@workspace/kilobuild-types";

export function statsCommand(): Command {
  return new Command("stats")
    .description("Show container resource usage stats")
    .argument("[name]", "Project name or ID (omit for global stats)")
    .option("--json", "Output as JSON")
    .action(async (name: string | undefined, opts: { json?: boolean }) => {
      try {
        if (!name) {
          const stats = await api.get<GlobalStats>("/stats");

          if (opts.json) {
            console.log(JSON.stringify(stats, null, 2));
            return;
          }

          console.log(chalk.bold.cyan("\n  Global Stats\n"));
          console.log(`  Projects: ${stats.totalProjects} total, ${chalk.green(stats.runningProjects + " running")}, ${chalk.yellow(stats.stoppedProjects + " stopped")}, ${chalk.red(stats.errorProjects + " error")}`);
          console.log(`  Containers: ${stats.totalContainers}`);
          console.log(`  CPU: ${stats.totalCpuPercent.toFixed(1)}%`);
          console.log(`  Memory: ${formatBytes(stats.totalMemoryUsedBytes)}`);
          console.log();
        } else {
          const stats = await api.get<ContainerStats>(`/projects/${name}/stats`);

          if (opts.json) {
            console.log(JSON.stringify(stats, null, 2));
            return;
          }

          const table = makeTable(["Metric", "Value"]);
          table.push(
            ["CPU %", `${stats.cpuPercent.toFixed(2)}%`],
            ["Memory", `${formatBytes(stats.memoryUsedBytes)} / ${formatBytes(stats.memoryLimitBytes)} (${stats.memoryPercent.toFixed(1)}%)`],
            ["Net I/O", `↓ ${formatBytes(stats.networkRxBytes)}  ↑ ${formatBytes(stats.networkTxBytes)}`],
            ["Block I/O", `↓ ${formatBytes(stats.blockReadBytes)}  ↑ ${formatBytes(stats.blockWriteBytes)}`],
            ["PIDs", String(stats.pids)],
          );
          console.log(table.toString());
        }
      } catch (error) {
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });
}
