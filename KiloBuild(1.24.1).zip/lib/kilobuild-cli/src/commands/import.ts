import { Command } from "commander";
import { resolve, basename, join, sep } from "node:path";
import { rename, mkdir, cp, rm } from "node:fs/promises";
import { existsSync } from "node:fs";
import { relative, isAbsolute } from "node:path";
import ora from "ora";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { ok, err, info } from "../utils/formatter.js";
import type { ProjectDetail, GlobalConfig } from "@workspace/kilobuild-types";

/** Move a directory; falls back to recursive copy+delete across filesystems. */
async function moveDir(src: string, dest: string): Promise<void> {
  try {
    await rename(src, dest);
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code !== "EXDEV") throw e;
    // Cross-device: copy then delete
    await cp(src, dest, { recursive: true });
    await rm(src, { recursive: true, force: true });
  }
}

function isInsideDir(child: string, dir: string): boolean {
  const rel = relative(resolve(dir), resolve(child));
  return rel !== ".." && !rel.startsWith(`..${sep}`) && !isAbsolute(rel);
}

export function importCommand(): Command {
  return new Command("import")
    .description(
      "Import a Node.js / Discord bot project into KiloBuild.\n" +
      "The project folder is moved into the configured Discord-Bots directory\n" +
      "and a startup.sh is generated automatically.",
    )
    .argument("<path>", "Absolute or relative path to the project directory")
    .option("-n, --name <name>", "Override project name (default: directory name)")
    .option(
      "--no-move",
      "Register in-place without moving the folder into Discord-Bots",
    )
    .action(
      async (pathArg: string, opts: { name?: string; move: boolean }) => {
        const sourcePath = resolve(pathArg);
        const name = opts.name ?? basename(sourcePath);

        if (!existsSync(sourcePath)) {
          err(`Directory not found: ${sourcePath}`);
          process.exit(1);
        }

        // ── Resolve destination in Discord-Bots dir ────────────────────────
        let config: GlobalConfig;
        try {
          config = await api.get<GlobalConfig>("/config");
        } catch (e) {
          err(
            e instanceof ApiError
              ? e.message
              : `Cannot reach KiloBuild daemon: ${String(e)}`,
          );
          process.exit(1);
        }

        const discordBotsDir = config.discordBotsDir;
        const destPath = join(discordBotsDir, name);

        let projectPath = sourcePath;

        if (opts.move !== false && !isInsideDir(sourcePath, discordBotsDir)) {
          if (existsSync(destPath)) {
            err(
              `Destination already exists: ${destPath}\n` +
              `  Use --name to pick a different name, or --no-move to register in-place.`,
            );
            process.exit(1);
          }

          const spinner = ora(
            `Moving ${chalk.bold(name)} → ${chalk.dim(discordBotsDir + "/")}${chalk.bold(name)}...`,
          ).start();

          try {
            await mkdir(discordBotsDir, { recursive: true });
            await moveDir(sourcePath, destPath);
            projectPath = destPath;
            spinner.succeed(`Moved to ${chalk.cyan(destPath)}`);
          } catch (e) {
            spinner.fail("Failed to move project folder");
            err(String(e));
            process.exit(1);
          }
        } else {
          info(`Registering in-place: ${chalk.cyan(sourcePath)}`);
          projectPath = sourcePath;
        }

        // ── Register with KiloBuild daemon ─────────────────────────────────
        const spinner = ora(`Importing ${chalk.bold(name)}...`).start();

        try {
          const project = await api.post<ProjectDetail>("/projects", {
            name,
            path: projectPath,
            initialize: false,
          });

          spinner.succeed(`Imported ${chalk.bold(project.name)}`);
          ok(`ID:       ${project.id}`);
          ok(`Path:     ${project.path}`);
          ok(`Type:     ${project.projectType}`);
          ok(`PM:       ${project.packageManager}`);
          ok(`Entry:    ${project.entryPoint ?? "index.js"}`);
          info(
            `startup.sh was generated with ${chalk.cyan("npm install")} + ${chalk.cyan(`node ${project.entryPoint ?? "index.js"}`)} — edit .kilobuild/startup.sh to customise`,
          );
          info(`Run ${chalk.cyan(`kilo start ${project.name}`)} to launch`);
        } catch (error) {
          spinner.fail("Import failed");
          if (error instanceof ApiError) err(error.message);
          else err(String(error));
          process.exit(1);
        }
      },
    );
}
