import { Command } from "commander";
import ora from "ora";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { ok, err, formatDuration, info } from "../utils/formatter.js";
import type { BuildResult } from "@workspace/kilobuild-types";

export function rebuildCommand(): Command {
  return new Command("rebuild")
    .description("Rebuild Docker image and restart container")
    .argument("<name>", "Project name or ID")
    .option("--logs", "Stream build logs")
    .action(async (name: string, opts: { logs?: boolean }) => {
      const spinner = ora(`Rebuilding ${chalk.bold(name)}...`).start();
      try {
        const result = await api.post<BuildResult>(`/projects/${name}/rebuild`);

        if (result.status === "success") {
          spinner.succeed(
            `${chalk.bold(name)} rebuilt successfully in ${formatDuration(result.durationMs ?? 0)}`,
          );
          if (result.imageId) ok(`Image: ${result.imageId.slice(0, 12)}`);
        } else if (result.status === "pending" || result.status === "running") {
          spinner.succeed(`Build for ${chalk.bold(name)} queued`);
          info("The daemon is building in the background. Check `kilo inspect` or `kilo list` for status.");
        } else {
          spinner.fail(`Build failed for ${chalk.bold(name)}`);
          if (result.error) err(result.error);
        }

        if (opts.logs && result.logs.length > 0) {
          info("Build logs:");
          for (const line of result.logs) {
            console.log(chalk.dim("  " + line));
          }
        }
      } catch (error) {
        spinner.fail(`Failed to rebuild ${name}`);
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });
}
