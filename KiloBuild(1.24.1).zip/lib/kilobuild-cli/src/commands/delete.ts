import { Command } from "commander";
import { createInterface } from "node:readline";
import ora from "ora";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { ok, err } from "../utils/formatter.js";

export function deleteCommand(): Command {
  return new Command("delete")
    .alias("rm")
    .description("Delete a project and its container")
    .argument("<name>", "Project name or ID")
    .option("-f, --force", "Skip confirmation and force-remove container")
    .option("--yes", "Skip confirmation prompt")
    .action(async (name: string, opts: { force?: boolean; yes?: boolean }) => {
      if (!opts.yes && !opts.force) {
        const rl = createInterface({ input: process.stdin, output: process.stdout });
        const answer = await new Promise<string>((resolve) => {
          rl.question(
            chalk.yellow(`Delete project "${name}"? This cannot be undone. [y/N] `),
            resolve,
          );
        });
        rl.close();
        if (answer.toLowerCase() !== "y" && answer.toLowerCase() !== "yes") {
          console.log(chalk.dim("Cancelled."));
          return;
        }
      }

      const spinner = ora(`Deleting ${chalk.bold(name)}...`).start();
      try {
        await api.delete<void>(`/projects/${name}${opts.force ? "?force=true" : ""}`);
        spinner.succeed(`Project ${chalk.bold(name)} deleted`);
      } catch (error) {
        spinner.fail(`Failed to delete ${name}`);
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });
}
