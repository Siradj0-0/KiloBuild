import { Command } from "commander";
import { createInterface } from "node:readline";
import ora from "ora";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { err, ok } from "../utils/formatter.js";
import type { BackupSummary } from "@workspace/kilobuild-types";

export function restoreCommand(): Command {
  return new Command("restore")
    .description("Restore a project from a backup")
    .argument("<name>", "Project name or ID")
    .argument("<backupId>", "Backup ID (use `kilo backup list <name>` to find it)")
    .option("--yes", "Skip confirmation")
    .action(async (name: string, backupId: string, opts: { yes?: boolean }) => {
      if (!opts.yes) {
        const rl = createInterface({ input: process.stdin, output: process.stdout });
        const answer = await new Promise<string>((r) => {
          rl.question(
            chalk.yellow(`Restore project "${name}" from backup "${backupId}"? [y/N] `),
            r,
          );
        });
        rl.close();
        if (answer.toLowerCase() !== "y") {
          console.log(chalk.dim("Cancelled."));
          return;
        }
      }

      const spinner = ora(`Restoring ${chalk.bold(name)}...`).start();
      try {
        const result = await api.post<BackupSummary>(
          `/projects/${name}/backups/${backupId}/restore`,
        );
        spinner.succeed(`Restore of ${chalk.bold(name)} complete`);
        ok(`From backup: ${result.name}`);
      } catch (error) {
        spinner.fail("Restore failed");
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });
}
