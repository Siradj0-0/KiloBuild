import { Command } from "commander";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { colorStatus, formatRelative, err, ok, warn } from "../utils/formatter.js";
import type { HealthCheckResult } from "@workspace/kilobuild-types";

export function healthCommand(): Command {
  return new Command("health")
    .description("Check health status of a project")
    .argument("<name>", "Project name or ID")
    .action(async (name: string) => {
      try {
        const result = await api.get<HealthCheckResult>(`/projects/${name}/health`);

        const fn = result.status === "healthy" ? ok : result.status === "starting" ? warn : (m: string) => console.log(chalk.red("✗") + " " + m);
        fn(`${chalk.bold(name)}: ${colorStatus(result.status)}`);
        if (result.message) console.log(chalk.dim("  " + result.message));
        if (result.responseTimeMs !== null) console.log(chalk.dim(`  Response time: ${result.responseTimeMs}ms`));
        console.log(chalk.dim(`  Checked: ${formatRelative(new Date(result.checkedAt))}`));
      } catch (error) {
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });
}
