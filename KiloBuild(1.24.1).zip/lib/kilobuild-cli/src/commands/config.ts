import { Command } from "commander";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { err, ok } from "../utils/formatter.js";
import type { ProjectConfig, GlobalConfig } from "@workspace/kilobuild-types";

export function configCommand(): Command {
  const cmd = new Command("config").description("Manage KiloBuild configuration");

  cmd
    .command("get [name]")
    .description("Get configuration (omit name for global config)")
    .option("--json", "Output as JSON")
    .action(async (name: string | undefined, opts: { json?: boolean }) => {
      try {
        if (!name) {
          const cfg = await api.get<GlobalConfig>("/config");
          if (opts.json) { console.log(JSON.stringify(cfg, null, 2)); return; }
          for (const [k, v] of Object.entries(cfg)) {
            console.log(`  ${chalk.dim(k.padEnd(28))} ${JSON.stringify(v)}`);
          }
        } else {
          const cfg = await api.get<ProjectConfig>(`/projects/${name}/config`);
          if (opts.json) { console.log(JSON.stringify(cfg, null, 2)); return; }
          for (const [k, v] of Object.entries(cfg)) {
            console.log(`  ${chalk.dim(k.padEnd(28))} ${JSON.stringify(v)}`);
          }
        }
      } catch (error) {
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });

  cmd
    .command("set <name> <key> <value>")
    .description("Set a project config value (use dot notation for nested keys)")
    .action(async (name: string, key: string, value: string) => {
      try {
        // Parse the value (JSON-like)
        let parsed: unknown = value;
        try { parsed = JSON.parse(value); } catch { /* keep as string */ }

        const patch: Record<string, unknown> = {};
        patch[key] = parsed;

        await api.put<ProjectConfig>(`/projects/${name}/config`, patch);
        ok(`Updated ${chalk.cyan(key)} on ${chalk.bold(name)}`);
      } catch (error) {
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });

  cmd
    .command("set-global <key> <value>")
    .description("Set a global config value")
    .action(async (key: string, value: string) => {
      try {
        let parsed: unknown = value;
        try { parsed = JSON.parse(value); } catch { /* keep as string */ }

        const patch: Record<string, unknown> = {};
        patch[key] = parsed;

        await api.put<GlobalConfig>("/config", patch);
        ok(`Updated global ${chalk.cyan(key)}`);
      } catch (error) {
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });

  return cmd;
}
