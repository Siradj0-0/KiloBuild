import { Command } from "commander";
import { api, ApiError } from "../utils/api-client.js";
import { err, formatBytes, makeTable } from "../utils/formatter.js";
import type { DiskUsage } from "@workspace/kilobuild-types";

export function diskCommand(): Command {
  return new Command("disk")
    .description("Show backup and log disk usage for every project")
    .option("--json", "Output as JSON")
    .action(async (opts: { json?: boolean }) => {
      try {
        const usage = await api.get<DiskUsage[]>("/disk");
        if (opts.json) {
          console.log(JSON.stringify(usage, null, 2));
          return;
        }
        const table = makeTable(["Project", "Backups", "Logs", "Total"]);
        for (const row of usage) {
          table.push([row.name, formatBytes(row.backupBytes), formatBytes(row.logBytes), formatBytes(row.totalBytes)]);
        }
        console.log(table.toString());
      } catch (error) {
        err(error instanceof ApiError ? error.message : String(error));
        process.exit(1);
      }
    });
}