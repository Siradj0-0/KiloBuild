import { Command } from "commander";
import ora from "ora";
import chalk from "chalk";
import { api, ApiError } from "../utils/api-client.js";
import { err, colorStatus } from "../utils/formatter.js";
import type { ContainerInfo } from "@workspace/kilobuild-types";

export function stopCommand(): Command {
  return new Command("stop")
    .description("Stop a project container")
    .argument("<name>", "Project name or ID")
    .option("-t, --timeout <secs>", "Stop timeout in seconds", "10")
    .action(async (name: string, opts: { timeout: string }) => {
      const spinner = ora(`Stopping ${chalk.bold(name)}...`).start();
      try {
        const container = await api.post<ContainerInfo>(
          `/projects/${name}/stop?timeout=${opts.timeout}`,
        );
        spinner.succeed(`${chalk.bold(name)} stopped — ${colorStatus(container.status)}`);
      } catch (error) {
        spinner.fail(`Failed to stop ${name}`);
        if (error instanceof ApiError) err(error.message);
        else err(String(error));
        process.exit(1);
      }
    });
}
