import { Command } from "commander";
import chalk from "chalk";
import { KILOBUILD_VERSION } from "../version.js";

export function versionCommand(): Command {
  return new Command("version")
    .description("Show the installed KiloBuild version")
    .action(() => {
      process.stdout.write(`${chalk.bold("KiloBuild")} ${KILOBUILD_VERSION}\n`);
    });
}