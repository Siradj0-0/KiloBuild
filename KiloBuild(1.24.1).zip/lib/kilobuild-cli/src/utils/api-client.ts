import https from "node:https";
import http from "node:http";

function baseUrl(): string {
  return process.env["KILOBUILD_API_URL"] ?? "http://127.0.0.1:3001/api";
}

function authHeaders(): Record<string, string> {
  const secret = process.env["KILOBUILD_API_SECRET"];
  return secret ? { Authorization: `Bearer ${secret}` } : {};
}

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    message: string,
    public readonly body: unknown,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

function streamRequest(
  path: string,
  onEvent: (event: { event?: string; data: string }) => void,
): import("node:http").ClientRequest {
  const configuredBaseUrl = baseUrl();
  const url = new URL(`${configuredBaseUrl}${path}`);
  const lib = url.protocol === "https:" ? https : http;
  const req = lib.request(url, {
    method: "GET",
    headers: { Accept: "text/event-stream", ...authHeaders() },
  }, (res) => {
    if ((res.statusCode ?? 500) >= 400) {
      res.resume();
      req.emit("error", new ApiError(res.statusCode ?? 500, `HTTP ${res.statusCode}`, null));
      return;
    }
    let buffer = "";
    res.setEncoding("utf8");
    res.on("data", (chunk: string) => {
      buffer += chunk;
      const frames = buffer.split("\n\n");
      buffer = frames.pop() ?? "";
      for (const frame of frames) {
        const data = frame
          .split("\n")
          .filter((line) => line.startsWith("data:"))
          .map((line) => line.slice(5).trimStart())
          .join("\n");
        const eventLine = frame.split("\n").find((line) => line.startsWith("event:"));
        if (data) onEvent({ event: eventLine?.slice(6).trim() || undefined, data });
      }
    });
  });
  req.end();
  return req;
}

async function request<T>(
  method: string,
  path: string,
  body?: unknown,
): Promise<T> {
  const configuredBaseUrl = baseUrl();
  const url = new URL(`${configuredBaseUrl}${path}`);
  const isHttps = url.protocol === "https:";
  const lib = isHttps ? https : http;

  const bodyStr = body !== undefined ? JSON.stringify(body) : undefined;

  return new Promise((resolve, reject) => {
    const req = lib.request(
      url,
      {
        method,
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          ...authHeaders(),
          ...(bodyStr ? { "Content-Length": Buffer.byteLength(bodyStr) } : {}),
        },
      },
      (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (chunk: Buffer) => chunks.push(chunk));
        res.on("end", () => {
          const raw = Buffer.concat(chunks).toString();
          let parsed: unknown;
          try {
            parsed = JSON.parse(raw);
          } catch {
            parsed = raw;
          }

          if (res.statusCode !== undefined && res.statusCode >= 400) {
            const err = parsed as { error?: string };
            reject(
              new ApiError(
                res.statusCode,
                err?.error ?? `HTTP ${res.statusCode}`,
                parsed,
              ),
            );
          } else {
            resolve(parsed as T);
          }
        });
      },
    );

    req.on("error", (err) => {
      if ((err as NodeJS.ErrnoException).code === "ECONNREFUSED") {
        reject(
          new Error(
             `Cannot connect to KiloBuild daemon at ${configuredBaseUrl}\n` +
              `Make sure the daemon is running: kilo daemon start`,
          ),
        );
      } else {
        reject(err);
      }
    });

    if (bodyStr) req.write(bodyStr);
    req.end();
  });
}

export const api = {
  get: <T>(path: string) => request<T>("GET", path),
  post: <T>(path: string, body?: unknown) => request<T>("POST", path, body),
  patch: <T>(path: string, body: unknown) => request<T>("PATCH", path, body),
  put: <T>(path: string, body: unknown) => request<T>("PUT", path, body),
  delete: <T>(path: string) => request<T>("DELETE", path),
  stream: streamRequest,
};
