import chalk from "chalk";
import Table from "cli-table3";

// ── Bytes formatter ───────────────────────────

export function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${units[i]}`;
}

// ── Duration formatter ────────────────────────

export function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60_000) return `${(ms / 1000).toFixed(1)}s`;
  const m = Math.floor(ms / 60_000);
  const s = Math.floor((ms % 60_000) / 1000);
  return `${m}m ${s}s`;
}

// ── Uptime formatter ──────────────────────────

export function formatUptime(secs: number): string {
  const d = Math.floor(secs / 86400);
  const h = Math.floor((secs % 86400) / 3600);
  const m = Math.floor((secs % 3600) / 60);
  if (d > 0) return `${d}d ${h}h`;
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}

// ── Status colorizer ──────────────────────────

export function colorStatus(status: string): string {
  switch (status) {
    case "running": return chalk.green(status);
    case "stopped":
    case "exited": return chalk.yellow(status);
    case "error":
    case "dead":
    case "unhealthy": return chalk.red(status);
    case "building": return chalk.blue(status);
    case "restarting": return chalk.cyan(status);
    case "healthy": return chalk.green(status);
    case "unknown":
    case "starting": return chalk.gray(status);
    default: return chalk.white(status);
  }
}

// ── Table helpers ──────────────────────────────

export function makeTable(headers: string[]): InstanceType<typeof Table> {
  return new Table({
    head: headers.map((h) => chalk.bold.cyan(h)),
    style: { "padding-left": 1, "padding-right": 1 },
    chars: {
      top: "─", "top-mid": "┬", "top-left": "╭", "top-right": "╮",
      bottom: "─", "bottom-mid": "┴", "bottom-left": "╰", "bottom-right": "╯",
      left: "│", "left-mid": "├", mid: "─", "mid-mid": "┼",
      right: "│", "right-mid": "┤", middle: "│",
    },
  });
}

// ── Log level colorizer ───────────────────────

export function colorLevel(level: string): string {
  switch (level) {
    case "error": return chalk.red(level.toUpperCase().padEnd(5));
    case "warn":  return chalk.yellow(level.toUpperCase().padEnd(5));
    case "debug": return chalk.gray(level.toUpperCase().padEnd(5));
    default:      return chalk.white(level.toUpperCase().padEnd(5));
  }
}

// ── Relative date formatter ────────────────────

export function formatRelative(date: Date): string {
  const diff = Date.now() - date.getTime();
  const s = Math.floor(diff / 1000);
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return date.toLocaleDateString();
}

// ── Print helpers ─────────────────────────────

export const ok = (msg: string) => console.log(chalk.green("✓") + " " + msg);
export const warn = (msg: string) => console.log(chalk.yellow("⚠") + " " + msg);
export const err = (msg: string) => console.error(chalk.red("✗") + " " + msg);
export const info = (msg: string) => console.log(chalk.blue("ℹ") + " " + msg);
export const dim = (msg: string) => console.log(chalk.dim(msg));
