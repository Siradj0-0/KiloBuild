import https from "node:https";
import http from "node:http";
import type {
  ContainerStats,
  HealthCheckResult,
  HealthStatus,
  GlobalConfig,
} from "@workspace/kilobuild-types";
import { StatsCollector } from "@workspace/kilobuild-docker";
import { eventBus } from "@workspace/kilobuild-events";
import { getConfigManager } from "@workspace/kilobuild-config";
import Dockerode from "dockerode";

// ── Health checker ─────────────────────────────

export interface HealthCheckOptions {
  projectId: string;
  containerId: string;
  host: string;
  port: number;
  path: string;
  timeoutMs?: number;
}

export async function httpHealthCheck(
  opts: HealthCheckOptions,
): Promise<HealthCheckResult> {
  const { projectId, path, host, port, timeoutMs = 5_000 } = opts;
  const start = Date.now();

  return new Promise((resolve) => {
    const req = (port === 443 ? https : http).request(
      { host, port, path, method: "GET", timeout: timeoutMs },
      (res) => {
        const ok = res.statusCode !== undefined && res.statusCode < 400;
        resolve({
          projectId,
          status: ok ? "healthy" : "unhealthy",
          message: ok
            ? `HTTP ${res.statusCode}`
            : `HTTP ${res.statusCode} (unhealthy)`,
          checkedAt: new Date(),
          responseTimeMs: Date.now() - start,
        });
        res.resume(); // consume response
      },
    );

    req.on("timeout", () => {
      req.destroy();
      resolve({
        projectId,
        status: "unhealthy",
        message: `Timeout after ${timeoutMs}ms`,
        checkedAt: new Date(),
        responseTimeMs: Date.now() - start,
      });
    });

    req.on("error", (err) => {
      resolve({
        projectId,
        status: "unhealthy",
        message: err.message,
        checkedAt: new Date(),
        responseTimeMs: Date.now() - start,
      });
    });

    req.end();
  });
}

// ── ContainerMonitor ──────────────────────────

interface MonitoredProject {
  projectId: string;
  containerId: string;
  stopStats?: () => void;
}

interface MonitorConfig {
  projectId: string;
  containerId: string;
  healthCheck?: {
    enabled: boolean;
    path: string;
    port: number;
    intervalMs: number;
    timeoutMs: number;
  };
}

export class ContainerMonitor {
  private projects = new Map<string, MonitoredProject>();
  private healthTimers = new Map<string, NodeJS.Timeout>();
  private lastStats = new Map<string, ContainerStats>();
  private lastHealth = new Map<string, HealthCheckResult>();
  private statsCollector: StatsCollector;
  private docker: Dockerode;

  constructor(dockerConfig?: Pick<GlobalConfig, "dockerSocket">) {
    const socketPath =
      dockerConfig?.dockerSocket ??
      getConfigManager().getGlobal().dockerSocket;
    this.docker = new Dockerode({ socketPath });
    this.statsCollector = new StatsCollector(this.docker);
  }

  /** Begin monitoring a container. */
  watch(config: MonitorConfig): void {
    const { projectId, containerId } = config;

    if (this.projects.has(projectId)) {
      this.unwatch(projectId);
    }

    const stopStats = this.statsCollector.streamStats(
      containerId,
      projectId,
      (stats) => {
        this.lastStats.set(projectId, stats);
      },
    );

    this.projects.set(projectId, { projectId, containerId, stopStats });

    // Start health check timer if configured
    if (config.healthCheck?.enabled && config.healthCheck.path) {
      const hc = config.healthCheck;
      const runCheck = async () => {
        const result = await httpHealthCheck({
          projectId,
          containerId,
          host: "localhost",
          port: hc.port,
          path: hc.path,
          timeoutMs: hc.timeoutMs,
        });

        const prev = this.lastHealth.get(projectId);
        this.lastHealth.set(projectId, result);

        // Emit event on status change
        if (!prev || prev.status !== result.status) {
          if (result.status === "healthy") {
            eventBus.emit("container:healthy", projectId, result);
          } else if (result.status === "unhealthy") {
            eventBus.emit("container:unhealthy", projectId, result);
          }
        }
      };

      const timer = setInterval(runCheck, hc.intervalMs);
      timer.unref();
      this.healthTimers.set(projectId, timer);
      runCheck().catch(() => { /* ignore */ });
    }
  }

  /** Stop monitoring a container. */
  unwatch(projectId: string): void {
    const project = this.projects.get(projectId);
    if (project) {
      project.stopStats?.();
      this.projects.delete(projectId);
    }
    const timer = this.healthTimers.get(projectId);
    if (timer) {
      clearInterval(timer);
      this.healthTimers.delete(projectId);
    }
    this.lastStats.delete(projectId);
    this.lastHealth.delete(projectId);
  }

  getStats(projectId: string): ContainerStats | null {
    return this.lastStats.get(projectId) ?? null;
  }

  getHealth(projectId: string): HealthCheckResult | null {
    return this.lastHealth.get(projectId) ?? null;
  }

  getAllStats(): ContainerStats[] {
    return Array.from(this.lastStats.values());
  }

  getAllHealth(): HealthCheckResult[] {
    return Array.from(this.lastHealth.values());
  }

  /** Check Docker container health status via inspect. */
  async inspectHealth(containerId: string, projectId: string): Promise<HealthCheckResult> {
    try {
      const container = this.docker.getContainer(containerId);
      const info = await container.inspect();
      const health = info.State.Health;
      let status: HealthStatus = "unknown";
      if (!health) {
        // No healthcheck defined – infer from running state
        status = info.State.Running ? "healthy" : "unhealthy";
      } else {
        switch (health.Status) {
          case "healthy": status = "healthy"; break;
          case "unhealthy": status = "unhealthy"; break;
          case "starting": status = "starting"; break;
          default: status = "unknown";
        }
      }
      return {
        projectId,
        status,
        message: health?.Log?.[0]?.Output ?? null,
        checkedAt: new Date(),
        responseTimeMs: null,
      };
    } catch {
      return {
        projectId,
        status: "unknown",
        message: "Failed to inspect container",
        checkedAt: new Date(),
        responseTimeMs: null,
      };
    }
  }

  /** Aggregate global stats across all monitored projects. */
  globalSummary(): {
    totalCpuPercent: number;
    totalMemoryUsedBytes: number;
    monitoredCount: number;
  } {
    const stats = Array.from(this.lastStats.values());
    return {
      totalCpuPercent: stats.reduce((s, x) => s + x.cpuPercent, 0),
      totalMemoryUsedBytes: stats.reduce((s, x) => s + x.memoryUsedBytes, 0),
      monitoredCount: stats.length,
    };
  }
}

export type { ContainerStats, HealthCheckResult, HealthStatus };
