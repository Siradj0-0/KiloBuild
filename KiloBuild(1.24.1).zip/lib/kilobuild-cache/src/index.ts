import { readFile, writeFile, mkdir } from "node:fs/promises";
import { join } from "node:path";

interface CacheEntry<T> {
  value: T;
  expiresAt: number | null;
  createdAt: number;
}

/**
 * TTL-aware in-memory cache with optional JSON disk persistence.
 * Used to avoid hitting the Docker API on every request for hot data
 * (container IDs, image IDs, last-known stats, health results).
 */
export class MemoryCache<T = unknown> {
  private store = new Map<string, CacheEntry<T>>();
  private readonly defaultTtlMs: number | null;

  constructor(defaultTtlMs: number | null = null) {
    this.defaultTtlMs = defaultTtlMs;
  }

  set(key: string, value: T, ttlMs?: number): void {
    const ttl = ttlMs ?? this.defaultTtlMs;
    this.store.set(key, {
      value,
      expiresAt: ttl !== null ? Date.now() + ttl : null,
      createdAt: Date.now(),
    });
  }

  get(key: string): T | undefined {
    const entry = this.store.get(key);
    if (!entry) return undefined;
    if (entry.expiresAt !== null && Date.now() > entry.expiresAt) {
      this.store.delete(key);
      return undefined;
    }
    return entry.value;
  }

  has(key: string): boolean {
    return this.get(key) !== undefined;
  }

  delete(key: string): boolean {
    return this.store.delete(key);
  }

  clear(): void {
    this.store.clear();
  }

  /** Remove all expired entries. */
  evict(): number {
    let removed = 0;
    const now = Date.now();
    for (const [key, entry] of this.store) {
      if (entry.expiresAt !== null && now > entry.expiresAt) {
        this.store.delete(key);
        removed++;
      }
    }
    return removed;
  }

  keys(): string[] {
    this.evict();
    return Array.from(this.store.keys());
  }

  size(): number {
    this.evict();
    return this.store.size;
  }

  /** Get all non-expired entries. */
  entries(): Array<[string, T]> {
    this.evict();
    return Array.from(this.store.entries()).map(([k, v]) => [k, v.value]);
  }

  /** Convenience: get or compute and cache. */
  async getOrSet(
    key: string,
    factory: () => Promise<T>,
    ttlMs?: number,
  ): Promise<T> {
    const existing = this.get(key);
    if (existing !== undefined) return existing;
    const value = await factory();
    this.set(key, value, ttlMs);
    return value;
  }
}

/** Disk-backed JSON cache for data that should survive restarts. */
export class DiskCache<T = unknown> {
  private memory: MemoryCache<T>;
  private readonly filePath: string;
  private dirty = false;
  private flushTimer: NodeJS.Timeout | null = null;

  constructor(cacheDir: string, namespace: string, defaultTtlMs?: number) {
    this.filePath = join(cacheDir, `${namespace}.json`);
    this.memory = new MemoryCache<T>(defaultTtlMs ?? null);
  }

  async load(): Promise<void> {
    try {
      const raw = await readFile(this.filePath, "utf8");
      const data = JSON.parse(raw) as Record<string, CacheEntry<T>>;
      const now = Date.now();
      for (const [key, entry] of Object.entries(data)) {
        if (entry.expiresAt === null || entry.expiresAt > now) {
          // re-hydrate: remaining TTL
          const remaining =
            entry.expiresAt !== null ? entry.expiresAt - now : undefined;
          this.memory.set(key, entry.value, remaining);
        }
      }
    } catch {
      // Cache file missing or corrupt – start fresh
    }
  }

  async flush(): Promise<void> {
    if (!this.dirty) return;
    try {
      await mkdir(this.filePath.replace(/\/[^/]+$/, ""), { recursive: true });
      const data: Record<string, CacheEntry<T>> = {};
      for (const [key, value] of this.memory.entries()) {
        const entry = (this.memory as unknown as {
          store: Map<string, CacheEntry<T>>;
        }).store.get(key);
        data[key] = {
          value,
          expiresAt: entry?.expiresAt ?? null,
          createdAt: entry?.createdAt ?? Date.now(),
        };
      }
      await writeFile(this.filePath, JSON.stringify(data, null, 2), "utf8");
      this.dirty = false;
    } catch {
      // Non-fatal – cache is best-effort
    }
  }

  private scheduledFlush(): void {
    if (this.flushTimer) return;
    this.flushTimer = setTimeout(async () => {
      this.flushTimer = null;
      await this.flush();
    }, 2_000);
  }

  set(key: string, value: T, ttlMs?: number): void {
    this.memory.set(key, value, ttlMs);
    this.dirty = true;
    this.scheduledFlush();
  }

  get(key: string): T | undefined {
    return this.memory.get(key);
  }

  delete(key: string): boolean {
    const result = this.memory.delete(key);
    if (result) {
      this.dirty = true;
      this.scheduledFlush();
    }
    return result;
  }

  clear(): void {
    this.memory.clear();
    this.dirty = true;
    this.scheduledFlush();
  }

  async getOrSet(
    key: string,
    factory: () => Promise<T>,
    ttlMs?: number,
  ): Promise<T> {
    return this.memory.getOrSet(key, factory, ttlMs);
  }
}

/** Namespaced registry of caches used across KiloBuild. */
export class CacheRegistry {
  private caches = new Map<string, MemoryCache<unknown>>();
  private evictInterval: NodeJS.Timeout | null = null;

  getOrCreate<T>(
    namespace: string,
    defaultTtlMs?: number,
  ): MemoryCache<T> {
    if (!this.caches.has(namespace)) {
      this.caches.set(namespace, new MemoryCache<unknown>(defaultTtlMs ?? null));
    }
    return this.caches.get(namespace) as MemoryCache<T>;
  }

  /** Start a background eviction sweep every minute. */
  startEviction(intervalMs = 60_000): void {
    if (this.evictInterval) return;
    this.evictInterval = setInterval(() => {
      for (const cache of this.caches.values()) cache.evict();
    }, intervalMs);
    this.evictInterval.unref();
  }

  stopEviction(): void {
    if (this.evictInterval) {
      clearInterval(this.evictInterval);
      this.evictInterval = null;
    }
  }
}

export const cacheRegistry = new CacheRegistry();
