import {
  createWriteStream,
  createReadStream,
  existsSync,
  statSync,
  readdirSync,
} from "node:fs";
import {
  mkdir,
  readdir,
  rename,
  unlink,
  access,
  stat,
} from "node:fs/promises";
import { join } from "node:path";
import { createInterface } from "node:readline";
import { constants } from "node:fs";
import type { LogEntry, LogSource, LogLevel, LogQuery } from "@workspace/kilobuild-types";

// ── LogManager ────────────────────────────────

export class LogManager {
  private writers = new Map<string, NodeJS.WritableStream>();
  private readonly logDir: string;

  constructor(logDir: string) {
    this.logDir = logDir;
  }

  private projectLogDir(projectId: string): string {
    return join(this.logDir, projectId);
  }

  private logFilePath(projectId: string, source: LogSource): string {
    return join(this.projectLogDir(projectId), `${source}.log`);
  }

  /** Ensure the log directory for a project exists. */
  async ensureDir(projectId: string): Promise<void> {
    await mkdir(this.projectLogDir(projectId), { recursive: true });
  }

  /** Write a log entry to disk. */
  async write(entry: LogEntry): Promise<void> {
    await this.ensureDir(entry.projectId);
    const key = `${entry.projectId}:${entry.source}`;
    let writer = this.writers.get(key);
    if (!writer) {
      writer = createWriteStream(
        this.logFilePath(entry.projectId, entry.source),
        { flags: "a" },
      ).on("error", (error) => {
        console.error(
          `[kilobuild] log writer error for ${entry.projectId}/${entry.source}: ${String(error)}`,
        );
        this.writers.delete(key);
      });
      this.writers.set(key, writer);
    }
    const line =
      JSON.stringify({
        t: entry.timestamp.toISOString(),
        l: entry.level,
        s: entry.source,
        m: entry.message,
      }) + "\n";
    writer.write(line);
  }

  /** Read log entries matching a query (last N lines by default). */
  async query(q: LogQuery): Promise<LogEntry[]> {
    const sources: LogSource[] = q.source
      ? [q.source]
      : ["stdout", "stderr", "system", "build", "startup", "shutdown", "health"];

    const allEntries: LogEntry[] = [];

    for (const source of sources) {
      const path = this.logFilePath(q.projectId, source);
      try {
        await access(path, constants.F_OK);
      } catch {
        continue;
      }

      const entries = await this.readLog(path, q);
      allEntries.push(
        ...entries.map((e) => ({
          projectId: q.projectId,
          source,
          message: e.m,
          timestamp: new Date(e.t),
          level: (e.l ?? "info") as LogLevel,
        })),
      );
    }

    // Sort by timestamp
    allEntries.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());

    // Apply tail limit
    const limit = q.tail ?? q.limit ?? 500;
    return allEntries.slice(-limit);
  }

  private async readLog(
    path: string,
    q: LogQuery,
  ): Promise<Array<{ t: string; l: string; s: string; m: string }>> {
    return new Promise((resolve) => {
      const results: Array<{ t: string; l: string; s: string; m: string }> = [];
      const rl = createInterface({ input: createReadStream(path) });
      rl.on("line", (line) => {
        try {
          const entry = JSON.parse(line) as { t: string; l: string; s: string; m: string };
          const ts = new Date(entry.t);
          if (q.since && ts < q.since) return;
          if (q.until && ts > q.until) return;
          if (q.level && entry.l !== q.level) return;
          results.push(entry);
        } catch {
          // Ignore corrupt lines
        }
      });
      rl.on("close", () => resolve(results));
      rl.on("error", () => resolve(results));
    });
  }

  /** Rotate a log file when it exceeds maxSizeBytes. */
  async rotate(projectId: string, source: LogSource, maxSizeBytes: number): Promise<boolean> {
    const path = this.logFilePath(projectId, source);
    try {
      const s = await stat(path);
      if (s.size < maxSizeBytes) return false;

      // Close any open writer for this log
      const key = `${projectId}:${source}`;
      const writer = this.writers.get(key);
      if (writer) {
        await new Promise<void>((res) => (writer as import("node:stream").Writable).end(res));
        this.writers.delete(key);
      }

      // Move current log to timestamped archive
      const ts = new Date().toISOString().replace(/[:.]/g, "-");
      await rename(path, path.replace(/\.log$/, `.${ts}.log`));
      return true;
    } catch {
      return false;
    }
  }

  /** Delete log files older than retentionDays for a project. */
  async prune(projectId: string, retentionDays: number): Promise<number> {
    const dir = this.projectLogDir(projectId);
    try {
      const files = await readdir(dir);
      const cutoff = Date.now() - retentionDays * 86_400_000;
      let deleted = 0;
      for (const file of files) {
        if (!file.endsWith(".log")) continue;
        try {
          const s = await stat(join(dir, file));
          if (s.mtimeMs < cutoff) {
            await unlink(join(dir, file));
            deleted++;
          }
        } catch {
          // ignore
        }
      }
      return deleted;
    } catch {
      return 0;
    }
  }

  /** Get total size of logs for a project in bytes. */
  getLogSizeBytes(projectId: string): number {
    const dir = this.projectLogDir(projectId);
    if (!existsSync(dir)) return 0;
    try {
      const sizeOf = (path: string): number => {
        const entry = statSync(path);
        if (!entry.isDirectory()) return entry.size;
        return readdirSync(path).reduce((total, child) => total + sizeOf(join(path, child)), 0);
      };
      return sizeOf(dir);
    } catch {
      return 0;
    }
  }

  /** Close all open writers cleanly. */
  async closeAll(): Promise<void> {
    const promises: Promise<void>[] = [];
    for (const writer of this.writers.values()) {
      promises.push(
        new Promise<void>((res) => (writer as import("node:stream").Writable).end(res)),
      );
    }
    await Promise.all(promises);
    this.writers.clear();
  }
}

// ── LogTailer ─────────────────────────────────

/** Tail a log source in real-time, calling onLine for each new line. */
export class LogTailer {
  private running = false;
  private lastSize = 0;
  private timer: NodeJS.Timeout | null = null;

  constructor(
    private readonly filePath: string,
    private readonly onLine: (line: LogEntry) => void,
    private readonly projectId: string,
    private readonly source: LogSource,
  ) {}

  start(pollMs = 250): void {
    if (this.running) return;
    this.running = true;

    try {
      this.lastSize = statSync(this.filePath).size;
    } catch {
      this.lastSize = 0;
    }

    this.timer = setInterval(() => this.poll(), pollMs);
    this.timer.unref();
  }

  stop(): void {
    this.running = false;
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  private poll(): void {
    try {
      const size = statSync(this.filePath).size;
      if (size <= this.lastSize) return;

      const stream = createReadStream(this.filePath, {
        start: this.lastSize,
        end: size - 1,
      });
      const rl = createInterface({ input: stream });
      rl.on("line", (line) => {
        try {
          const e = JSON.parse(line) as { t: string; l: string; m: string };
          this.onLine({
            projectId: this.projectId,
            source: this.source,
            message: e.m,
            timestamp: new Date(e.t),
            level: (e.l ?? "info") as LogLevel,
          });
        } catch {
          this.onLine({
            projectId: this.projectId,
            source: this.source,
            message: line,
            timestamp: new Date(),
            level: "info",
          });
        }
      });
      this.lastSize = size;
    } catch {
      // File may not exist yet
    }
  }
}

export type { LogEntry, LogSource, LogLevel, LogQuery };
