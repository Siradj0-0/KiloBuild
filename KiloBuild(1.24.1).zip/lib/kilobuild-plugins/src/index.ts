import { readdir, access } from "node:fs/promises";
import { join } from "node:path";
import { constants } from "node:fs";
import { randomUUID } from "node:crypto";
import type {
  Plugin,
  PluginDefinition,
  PluginHooks,
  Project,
  Container,
  HealthCheckResult,
  Backup,
} from "@workspace/kilobuild-types";
import { eventBus } from "@workspace/kilobuild-events";

export function createDiscordWebhookPlugin(webhookUrl: string): PluginDefinition {
  const post = async (event: string, projectId: string | null, payload: unknown) => {
    await fetch(webhookUrl, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        username: "KiloBuild",
        content: `KiloBuild ${event}${projectId ? ` for ${projectId}` : ""}`,
        embeds: [{
          title: event,
          description: "KiloBuild lifecycle notification",
          fields: [{
            name: "Payload",
            value: JSON.stringify(payload).slice(0, 1024),
          }],
        }],
      }),
    });
  };

  return {
    name: "discord-webhook",
    version: "1.0.0",
    description: "Posts crash, exhausted recovery, and backup failure alerts to Discord",
    hooks: {
      onContainerCrashed: (payload) => post("container:crashed", null, payload),
      onRecoveryExhausted: (payload) => post("recovery:exhausted", null, payload),
      onBackupFailed: (payload) => post("backup:failed", null, payload),
    },
  };
}

// ── PluginAPI ─────────────────────────────────

/**
 * The API surface exposed to plugins. Plugins interact with KiloBuild
 * exclusively through this interface – never through direct module imports.
 */
export interface PluginAPI {
  /** Subscribe to a KiloBuild event. */
  on: typeof eventBus.subscribe;
  /** Emit a custom event (prefixed with "plugin:<name>:"). */
  emit: (type: string, projectId: string | null, payload: unknown) => void;
  /** Get the plugin's own configuration. */
  getConfig: () => Record<string, unknown>;
}

// ── PluginManager ─────────────────────────────

interface LoadedPlugin {
  id: string;
  definition: PluginDefinition;
  config: Record<string, unknown>;
  enabled: boolean;
  loadedAt: Date;
}

export class PluginManager {
  private plugins = new Map<string, LoadedPlugin>();
  private readonly pluginsDir: string;
  private unsubscribers = new Map<string, Array<() => void>>();

  constructor(pluginsDir: string) {
    this.pluginsDir = pluginsDir;
    this.wireEventBridges();
  }

  /** Wire KiloBuild events to plugin hooks. */
  private wireEventBridges(): void {
    eventBus.on("project:created", async (event) => {
      for (const p of this.activePlugins()) {
        await p.definition.hooks.onProjectCreated?.(event.payload as Project);
      }
    });

    eventBus.on("project:deleted", async (event) => {
      for (const p of this.activePlugins()) {
        await p.definition.hooks.onProjectDeleted?.(event.projectId ?? "");
      }
    });

    eventBus.on("container:started", async (event) => {
      for (const p of this.activePlugins()) {
        await p.definition.hooks.onContainerStarted?.(event.payload as Container);
      }
    });

    eventBus.on("container:stopped", async (event) => {
      for (const p of this.activePlugins()) {
        await p.definition.hooks.onContainerStopped?.(event.payload as Container);
      }
    });

    eventBus.on("container:crashed", async (event) => {
      for (const p of this.activePlugins()) {
        await p.definition.hooks.onContainerCrashed?.({
          projectId: event.projectId,
          ...(event.payload as Record<string, unknown>),
        } as unknown as Container);
      }
    });

    eventBus.on("container:healthy", async (event) => {
      for (const p of this.activePlugins()) {
        await p.definition.hooks.onHealthChanged?.(event.payload as HealthCheckResult);
      }
    });

    eventBus.on("container:unhealthy", async (event) => {
      for (const p of this.activePlugins()) {
        await p.definition.hooks.onHealthChanged?.(event.payload as HealthCheckResult);
      }
    });

    eventBus.on("backup:created", async (event) => {
      for (const p of this.activePlugins()) {
        await p.definition.hooks.onBackupCreated?.(event.payload as Backup);
      }
    });

    eventBus.on("recovery:exhausted", async (event) => {
      for (const p of this.activePlugins()) {
        await p.definition.hooks.onRecoveryExhausted?.({
          projectId: event.projectId,
          ...(event.payload as Record<string, unknown>),
        });
      }
    });

    eventBus.on("backup:failed", async (event) => {
      for (const p of this.activePlugins()) {
        await p.definition.hooks.onBackupFailed?.({
          projectId: event.projectId,
          ...(event.payload as Record<string, unknown>),
        });
      }
    });
  }

  /** Scan the pluginsDir and load all enabled plugins. */
  async loadAll(): Promise<void> {
    try {
      const entries = await readdir(this.pluginsDir, { withFileTypes: true });
      for (const entry of entries) {
        if (!entry.isDirectory()) continue;
        const pkgPath = join(this.pluginsDir, entry.name, "package.json");
        try {
          await access(pkgPath, constants.F_OK);
          await this.loadPlugin(join(this.pluginsDir, entry.name));
        } catch {
          // Skip directories without package.json
        }
      }
    } catch {
      // pluginsDir may not exist – that's fine
    }
  }

  /** Load a single plugin from a directory path. */
  async loadPlugin(pluginPath: string, config: Record<string, unknown> = {}): Promise<Plugin> {
    const indexPath = join(pluginPath, "index.js");

    try {
      await access(indexPath, constants.F_OK);
    } catch {
      throw new Error(`Plugin at ${pluginPath} has no index.js`);
    }

    const mod = (await import(indexPath)) as { default?: PluginDefinition } & PluginDefinition;
    const definition: PluginDefinition = mod.default ?? (mod as unknown as PluginDefinition);

    if (!definition.name || !definition.hooks) {
      throw new Error(`Invalid plugin at ${pluginPath}: missing name or hooks`);
    }

    const id = randomUUID();
    const loaded: LoadedPlugin = {
      id,
      definition,
      config,
      enabled: true,
      loadedAt: new Date(),
    };

    this.plugins.set(definition.name, loaded);

    // Call plugin initialize hook
    const api = this.buildApi(definition.name, config);
      await definition.initialize?.(config, api);

    eventBus.emit("plugin:loaded", null, { name: definition.name, version: definition.version });

    return {
      id,
      name: definition.name,
      version: definition.version,
      description: definition.description ?? null,
      path: pluginPath,
      enabled: true,
      status: "active",
      config,
      installedAt: loaded.loadedAt,
    };
  }

  async loadDefinition(
    definition: PluginDefinition,
    config: Record<string, unknown> = {},
  ): Promise<Plugin> {
    const id = randomUUID();
    const loaded: LoadedPlugin = {
      id,
      definition,
      config,
      enabled: true,
      loadedAt: new Date(),
    };
    this.plugins.set(definition.name, loaded);
    await definition.initialize?.(config, this.buildApi(definition.name, config));
    eventBus.emit("plugin:loaded", null, { name: definition.name, version: definition.version });
    return {
      id,
      name: definition.name,
      version: definition.version,
      description: definition.description ?? null,
      path: null,
      enabled: true,
      status: "active",
      config,
      installedAt: loaded.loadedAt,
    };
  }

  /** Unload a plugin by name. */
  async unloadPlugin(name: string): Promise<void> {
    const loaded = this.plugins.get(name);
    if (!loaded) return;

    await loaded.definition.destroy?.();

    const unsubs = this.unsubscribers.get(name) ?? [];
    for (const u of unsubs) u();
    this.unsubscribers.delete(name);

    this.plugins.delete(name);
    eventBus.emit("plugin:unloaded", null, { name });
  }

  /** Enable or disable a plugin. */
  setEnabled(name: string, enabled: boolean): void {
    const plugin = this.plugins.get(name);
    if (plugin) plugin.enabled = enabled;
  }

  list(): Plugin[] {
    return Array.from(this.plugins.values()).map((p) => ({
      id: p.id,
      name: p.definition.name,
      version: p.definition.version,
      description: p.definition.description ?? null,
      path: null,
      enabled: p.enabled,
      status: (p.enabled ? "active" : "inactive") as "active" | "inactive" | "error",
      config: p.config,
      installedAt: p.loadedAt,
    }));
  }

  private activePlugins(): LoadedPlugin[] {
    return Array.from(this.plugins.values()).filter((p) => p.enabled);
  }

  private buildApi(name: string, config: Record<string, unknown>): PluginAPI {
    return {
      on: eventBus.subscribe.bind(eventBus),
      emit: (type, projectId, payload) => {
        // Plugins emit using the raw EventEmitter so we skip type checks
        (eventBus as unknown as { emit: (type: string, ...args: unknown[]) => void })
          .emit(`plugin:${name}:${type}`, projectId, payload);
      },
      getConfig: () => config,
    };
  }
}

export type { Plugin, PluginDefinition, PluginHooks };
