import { EventEmitter } from "node:events";
import { randomUUID } from "node:crypto";
import type {
  KiloBuildEventType,
  KiloBuildEvent,
} from "@workspace/kilobuild-types";

type EventPayloadMap = {
  [K in KiloBuildEventType]: KiloBuildEvent;
} & {
  "*": KiloBuildEvent;
};

type EventListener<T = unknown> = (event: KiloBuildEvent<T>) => void;

/**
 * Type-safe internal event bus for KiloBuild.
 * All subsystems communicate through this central bus.
 */
export class KiloBuildEventBus extends EventEmitter {
  private static _instance: KiloBuildEventBus | null = null;

  private constructor() {
    super();
    // Allow many listeners (monitoring, plugins, recovery all listen)
    this.setMaxListeners(100);
  }

  /** Singleton accessor for process-wide event bus. */
  static instance(): KiloBuildEventBus {
    if (!KiloBuildEventBus._instance) {
      KiloBuildEventBus._instance = new KiloBuildEventBus();
    }
    return KiloBuildEventBus._instance;
  }

  /**
   * Emit a typed KiloBuild event. Automatically assigns an ID and timestamp,
   * and also fires the wildcard "*" listener so subscribers can catch all events.
   */
  emit<T = unknown>(
    type: KiloBuildEventType,
    projectId: string | null,
    payload: T,
  ): boolean {
    const event: KiloBuildEvent<T> = {
      id: randomUUID(),
      type,
      projectId,
      payload,
      timestamp: new Date(),
    };
    const result = super.emit(type, event);
    super.emit("*", event);
    return result;
  }

  /** Subscribe to a specific event type. */
  on<T = unknown>(
    type: KiloBuildEventType | "*",
    listener: EventListener<T>,
  ): this {
    return super.on(type, listener as (...args: unknown[]) => void);
  }

  /** Subscribe to a specific event type once. */
  once<T = unknown>(
    type: KiloBuildEventType | "*",
    listener: EventListener<T>,
  ): this {
    return super.once(type, listener as (...args: unknown[]) => void);
  }

  /** Remove a listener. */
  off<T = unknown>(
    type: KiloBuildEventType | "*",
    listener: EventListener<T>,
  ): this {
    return super.off(type, listener as (...args: unknown[]) => void);
  }

  /** Convenience: subscribe and return an unsubscribe function. */
  subscribe<T = unknown>(
    type: KiloBuildEventType | "*",
    listener: EventListener<T>,
  ): () => void {
    this.on(type, listener);
    return () => this.off(type, listener);
  }

  /** Wait for a specific event type (returns a Promise). */
  waitFor<T = unknown>(
    type: KiloBuildEventType,
    timeoutMs = 30_000,
  ): Promise<KiloBuildEvent<T>> {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.off(type, handler);
        reject(new Error(`Timeout waiting for event: ${type}`));
      }, timeoutMs);

      const handler = (event: KiloBuildEvent<T>) => {
        clearTimeout(timer);
        resolve(event);
      };

      this.once(type, handler);
    });
  }
}

export type { KiloBuildEvent, KiloBuildEventType, EventPayloadMap };

/** Singleton event bus. Import and use directly. */
export const eventBus = KiloBuildEventBus.instance();
