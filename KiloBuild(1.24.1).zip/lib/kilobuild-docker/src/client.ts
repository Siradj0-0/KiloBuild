import Dockerode from "dockerode";
import type { GlobalConfig } from "@workspace/kilobuild-types";

let _client: Dockerode | null = null;

/** Get or create the singleton Dockerode client. */
export function DockerClient(config?: Pick<GlobalConfig, "dockerSocket">): Dockerode {
  if (!_client) {
    const socketPath = config?.dockerSocket ?? process.env["DOCKER_SOCKET"] ?? "/var/run/docker.sock";
    _client = new Dockerode({ socketPath });
  }
  return _client;
}

/** Verify Docker daemon is reachable. */
export async function pingDocker(config?: Pick<GlobalConfig, "dockerSocket">): Promise<boolean> {
  try {
    await DockerClient(config).ping();
    return true;
  } catch {
    return false;
  }
}

/** Get Docker version info. */
export async function getDockerVersion(config?: Pick<GlobalConfig, "dockerSocket">): Promise<{
  version: string;
  apiVersion: string;
  os: string;
  arch: string;
}> {
  const info = await DockerClient(config).version();
  return {
    version: info.Version,
    apiVersion: info.ApiVersion,
    os: info.Os,
    arch: info.Arch,
  };
}
