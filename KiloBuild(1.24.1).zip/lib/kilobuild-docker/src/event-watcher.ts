import Dockerode from "dockerode";

export type DockerEventAction =
  | "start"
  | "stop"
  | "die"
  | "kill"
  | "restart"
  | "pause"
  | "unpause"
  | "destroy"
  | "create"
  | "health_status"
  | string;

export interface DockerContainerEvent {
  action: DockerEventAction;
  containerId: string;
  projectId: string | null;
  projectSlug: string | null;
  exitCode: number | null;
  healthStatus: string | null;
  timestamp: Date;
}

type DockerEventCallback = (event: DockerContainerEvent) => void;

/**
 * Watches the Docker event stream and re-emits KiloBuild-relevant events.
 * Only tracks containers labelled with "kilobuild.managed=true".
 */
export class DockerEventWatcher {
  private running = false;
  private streamObj: NodeJS.EventEmitter | null = null;
  private listeners: DockerEventCallback[] = [];

  constructor(private docker: Dockerode) {}

  addListener(cb: DockerEventCallback): () => void {
    this.listeners.push(cb);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== cb);
    };
  }

  async start(): Promise<void> {
    if (this.running) return;
    this.running = true;
    await this.connect();
  }

  stop(): void {
    this.running = false;
    if (this.streamObj) {
      (this.streamObj as unknown as { destroy: () => void }).destroy?.();
      this.streamObj = null;
    }
  }

  private async connect(): Promise<void> {
    try {
      const stream = await this.docker.getEvents({
        filters: JSON.stringify({
          type: ["container"],
          label: ["kilobuild.managed=true"],
        }),
      });

      this.streamObj = stream;
      let buffer = "";

      stream.on("data", (chunk: Buffer) => {
        buffer += chunk.toString();
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.trim()) continue;
          this.processEvent(line);
        }
      });

      stream.on("error", () => this.reconnect());
      stream.on("end", () => this.reconnect());
    } catch {
      this.reconnect();
    }
  }

  private reconnect(): void {
    if (!this.running) return;
    setTimeout(() => {
      if (this.running) this.connect().catch(() => this.reconnect());
    }, 5_000);
  }

  private processEvent(line: string): void {
    try {
      const raw = JSON.parse(line) as {
        Action: string;
        Actor: {
          ID: string;
          Attributes: Record<string, string>;
        };
        time: number;
      };

      const attrs = raw.Actor.Attributes;
      if (!attrs["kilobuild.managed"]) return;

      const event: DockerContainerEvent = {
        action: raw.Action as DockerEventAction,
        containerId: raw.Actor.ID,
        projectId: attrs["kilobuild.project.id"] ?? null,
        projectSlug: attrs["kilobuild.project.slug"] ?? null,
        exitCode: attrs["exitCode"] ? parseInt(attrs["exitCode"]!, 10) : null,
        healthStatus: attrs["health_status"] ?? null,
        timestamp: new Date(raw.time * 1000),
      };

      for (const listener of this.listeners) {
        try {
          listener(event);
        } catch {
          // Listener errors must never crash the watcher
        }
      }
    } catch {
      // Ignore malformed events
    }
  }
}
