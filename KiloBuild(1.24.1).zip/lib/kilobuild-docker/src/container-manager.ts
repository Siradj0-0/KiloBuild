import Dockerode from "dockerode";
import { Writable } from "node:stream";
import type {
  ProjectConfig,
  ContainerStatus,
  BuildResult,
} from "@workspace/kilobuild-types";

export interface CreateContainerOptions {
  projectId: string;
  projectSlug: string;
  imageName: string;
  config: ProjectConfig;
  projectPath: string;
}

export interface ContainerInfo {
  containerId: string;
  imageId: string | null;
  imageName: string | null;
  status: ContainerStatus;
  startedAt: Date | null;
  finishedAt: Date | null;
  exitCode: number | null;
  restartCount: number;
}

function mapStatus(state: string): ContainerStatus {
  const s = state.toLowerCase();
  const map: Record<string, ContainerStatus> = {
    created: "created",
    running: "running",
    paused: "paused",
    restarting: "restarting",
    removing: "removing",
    exited: "exited",
    dead: "dead",
  };
  return map[s] ?? "unknown";
}

export class ContainerManager {
  constructor(private docker: Dockerode) {}

  containerName(projectSlug: string): string {
    return `kilobuild-${projectSlug}`;
  }

  /** Create and optionally start a new container for a project. */
  async create(opts: CreateContainerOptions): Promise<string> {
    const { projectId, projectSlug, imageName, config } = opts;
    const name = this.containerName(projectSlug);

    // Port bindings
    const ExposedPorts: Record<string, Record<string, never>> = {};
    const PortBindings: Record<string, Array<{ HostPort: string }>> = {};
    for (const pb of config.portBindings) {
      const key = `${pb.containerPort}/${pb.protocol}`;
      ExposedPorts[key] = {};
      PortBindings[key] = [{ HostPort: pb.hostPort ? String(pb.hostPort) : "" }];
    }

    // Volume bindings
    const Binds: string[] = config.volumeBindings.map(
      (vb) => `${vb.hostPath}:${vb.containerPath}${vb.readOnly ? ":ro" : ""}`,
    );

    // Env vars
    const Env: string[] = Object.entries(config.envVars).map(
      ([k, v]) => `${k}=${v}`,
    );
    Env.push(`KILOBUILD_PROJECT_ID=${projectId}`);
    Env.push(`KILOBUILD_PROJECT_SLUG=${projectSlug}`);

    // Labels
    const Labels: Record<string, string> = {
      ...config.labels,
      "kilobuild.managed": "true",
      "kilobuild.project.id": projectId,
      "kilobuild.project.slug": projectSlug,
    };

    // Resource limits
    const HostConfig: Dockerode.HostConfig = {
      RestartPolicy: this.buildRestartPolicy(config),
      Binds,
      PortBindings,
      NetworkMode: config.networkMode,
    };
    let Healthcheck: Dockerode.HealthConfig | undefined;
    if (config.memoryLimit) {
      HostConfig.Memory = this.parseMemoryBytes(config.memoryLimit);
    }
    if (config.memorySwapLimit) {
      HostConfig.MemorySwap = this.parseMemoryBytes(config.memorySwapLimit);
    }
    if (config.cpuLimit) {
      HostConfig.NanoCpus = Math.floor(parseFloat(config.cpuLimit) * 1e9);
    }

    // Healthcheck
    if (config.healthCheckEnabled && config.healthCheckPath) {
      Healthcheck = {
        Test: [
          "CMD-SHELL",
          `curl -sf http://localhost${config.healthCheckPath} || exit 1`,
        ],
        Interval: config.healthCheckIntervalSeconds * 1e9,
        Timeout: config.healthCheckTimeoutSeconds * 1e9,
        Retries: config.healthCheckRetries,
        StartPeriod: 5_000_000_000,
      };
    }

    const container = await this.docker.createContainer({
      name,
      Image: imageName,
      Env,
      ExposedPorts,
      Labels,
      HostConfig,
      Healthcheck,
    });

    return container.id;
  }

  /** Start an existing container by Docker container ID. */
  async start(containerId: string): Promise<void> {
    const container = this.docker.getContainer(containerId);
    await container.start();
  }

  /** Stop a container gracefully (SIGTERM + timeout). */
  async stop(containerId: string, timeoutSecs = 10): Promise<void> {
    const container = this.docker.getContainer(containerId);
    await container.stop({ t: timeoutSecs });
  }

  /** Kill a container immediately. */
  async kill(containerId: string, signal = "SIGKILL"): Promise<void> {
    const container = this.docker.getContainer(containerId);
    await container.kill({ signal });
  }

  /** Restart a container. */
  async restart(containerId: string, timeoutSecs = 10): Promise<void> {
    const container = this.docker.getContainer(containerId);
    await container.restart({ t: timeoutSecs });
  }

  /** Remove a container (must be stopped first). */
  async remove(containerId: string, force = false): Promise<void> {
    const container = this.docker.getContainer(containerId);
    await container.remove({ force });
  }

  /** Inspect a container and return structured info. */
  async inspect(containerId: string): Promise<ContainerInfo | null> {
    try {
      const container = this.docker.getContainer(containerId);
      const data = await container.inspect();
      return {
        containerId: data.Id,
        imageId: data.Image,
        imageName: data.Config.Image,
        status: mapStatus(data.State.Status),
        startedAt:
          data.State.StartedAt && data.State.StartedAt !== "0001-01-01T00:00:00Z"
            ? new Date(data.State.StartedAt)
            : null,
        finishedAt:
          data.State.FinishedAt && data.State.FinishedAt !== "0001-01-01T00:00:00Z"
            ? new Date(data.State.FinishedAt)
            : null,
        exitCode: data.State.ExitCode ?? null,
        restartCount: data.RestartCount ?? 0,
      };
    } catch {
      return null;
    }
  }

  /** Find the container ID for a project slug. */
  async findBySlug(projectSlug: string): Promise<string | null> {
    try {
      const containers = await this.docker.listContainers({
        all: true,
        filters: JSON.stringify({
          label: [`kilobuild.project.slug=${projectSlug}`],
        }),
      });
      return containers[0]?.Id ?? null;
    } catch {
      return null;
    }
  }

  /** List all KiloBuild-managed containers. */
  async listManaged(): Promise<
    Array<{ containerId: string; projectSlug: string; status: ContainerStatus }>
  > {
    const containers = await this.docker.listContainers({
      all: true,
      filters: JSON.stringify({ label: ["kilobuild.managed=true"] }),
    });
    return containers.map((c) => ({
      containerId: c.Id,
      projectSlug: c.Labels["kilobuild.project.slug"] ?? "unknown",
      status: mapStatus(c.State),
    }));
  }

  /** Stream logs for a container. Calls onChunk with each log chunk. */
  async streamLogs(
    containerId: string,
    opts: {
      tail?: number;
      since?: number;
      follow?: boolean;
      onChunk: (chunk: string, isStderr: boolean) => void;
    },
  ): Promise<void> {
    const container = this.docker.getContainer(containerId);
    const logOptions = {
      stdout: true,
      stderr: true,
      tail: opts.tail ?? 100,
      since: opts.since ?? 0,
      timestamps: true,
    };
    const stream = opts.follow
      ? await container.logs({ ...logOptions, follow: true })
      : await container.logs({ ...logOptions, follow: false });

    return new Promise((resolve, reject) => {
      const out = new Writable({
        write(chunk: Buffer, _enc, cb) {
          opts.onChunk(chunk.toString(), false);
          cb();
        },
      });
      const err = new Writable({
        write(chunk: Buffer, _enc, cb) {
          opts.onChunk(chunk.toString(), true);
          cb();
        },
      });
      this.docker.modem.demuxStream(stream as unknown as NodeJS.ReadableStream, out, err);
      (stream as unknown as NodeJS.EventEmitter).on("end", resolve);
      (stream as unknown as NodeJS.EventEmitter).on("error", reject);
    });
  }

  /** Execute a command inside a running container. */
  async exec(
    containerId: string,
    cmd: string[],
  ): Promise<{ exitCode: number; output: string }> {
    const container = this.docker.getContainer(containerId);
    const exec = await container.exec({
      Cmd: cmd,
      AttachStdout: true,
      AttachStderr: true,
    });
    const stream = await exec.start({ hijack: true, stdin: false });

    return new Promise((resolve, reject) => {
      const chunks: string[] = [];
      const out = new Writable({
        write(chunk: Buffer, _enc, cb) {
          chunks.push(chunk.toString());
          cb();
        },
      });
      this.docker.modem.demuxStream(stream as unknown as NodeJS.ReadableStream, out, out);
      (stream as unknown as NodeJS.EventEmitter).on("end", async () => {
        const info = await exec.inspect();
        resolve({ exitCode: info.ExitCode ?? -1, output: chunks.join("") });
      });
      (stream as unknown as NodeJS.EventEmitter).on("error", reject);
    });
  }

  private buildRestartPolicy(
    config: ProjectConfig,
  ): Dockerode.HostRestartPolicy {
    switch (config.restartPolicy) {
      case "always":
        return { Name: "always" };
      case "unless-stopped":
        return { Name: "unless-stopped" };
      case "on-failure":
        return { Name: "on-failure", MaximumRetryCount: config.maxRestarts };
      case "no":
      default:
        return { Name: "no" };
    }
  }

  private parseMemoryBytes(limit: string): number {
    const match = limit.match(/^(\d+(?:\.\d+)?)\s*([kmg]?)b?$/i);
    if (!match) return 0;
    const [, num, unit] = match;
    const value = parseFloat(num!);
    switch ((unit ?? "").toLowerCase()) {
      case "k": return Math.floor(value * 1024);
      case "m": return Math.floor(value * 1024 * 1024);
      case "g": return Math.floor(value * 1024 * 1024 * 1024);
      default: return Math.floor(value);
    }
  }
}

export type { BuildResult };
