import Dockerode from "dockerode";
import type { ContainerStats } from "@workspace/kilobuild-types";

interface DockerStatsData {
  cpu_stats: {
    cpu_usage: { total_usage: number };
    system_cpu_usage: number;
    online_cpus: number;
  };
  precpu_stats: {
    cpu_usage: { total_usage: number };
    system_cpu_usage: number;
  };
  memory_stats: {
    usage: number;
    limit: number;
  };
  networks?: Record<string, { rx_bytes: number; tx_bytes: number }>;
  blkio_stats?: {
    io_service_bytes_recursive?: Array<{ op: string; value: number }>;
  };
  pids_stats?: { current: number };
}

export class StatsCollector {
  constructor(private docker: Dockerode) {}

  /** Collect a single stats snapshot for a container (non-streaming). */
  async collect(containerId: string, projectId: string): Promise<ContainerStats | null> {
    try {
      const container = this.docker.getContainer(containerId);
      const raw = await new Promise<DockerStatsData>((resolve, reject) => {
        container.stats({ stream: false }, (err: Error | null, data: unknown) => {
          if (err) reject(err);
          else resolve(data as DockerStatsData);
        });
      });

      return this.parse(raw, projectId, containerId);
    } catch {
      return null;
    }
  }

  /** Stream stats, calling onStats for each update. Returns a stop function. */
  streamStats(
    containerId: string,
    projectId: string,
    onStats: (stats: ContainerStats) => void,
  ): () => void {
    let stopped = false;
    let streamObj: NodeJS.EventEmitter | null = null;

    const start = async () => {
      try {
        const container = this.docker.getContainer(containerId);
        const stream = await new Promise<NodeJS.ReadableStream>((resolve, reject) => {
          container.stats({ stream: true }, (err: Error | null, data: unknown) => {
            if (err) reject(err);
            else resolve(data as NodeJS.ReadableStream);
          });
        });

        streamObj = stream;
        let buffer = "";

        stream.on("data", (chunk: Buffer) => {
          if (stopped) return;
          buffer += chunk.toString();
          const lines = buffer.split("\n");
          buffer = lines.pop() ?? "";
          for (const line of lines) {
            if (!line.trim()) continue;
            try {
              const raw = JSON.parse(line) as DockerStatsData;
              const stats = this.parse(raw, projectId, containerId);
              if (stats) onStats(stats);
            } catch {
              // Ignore parse errors
            }
          }
        });

        stream.on("error", () => { /* ignore */ });
        stream.on("end", () => {
          if (!stopped) {
            // Container exited – restart after a short delay
            setTimeout(() => {
              if (!stopped) start().catch(() => { /* ignore */ });
            }, 5_000);
          }
        });
      } catch {
        if (!stopped) {
          setTimeout(() => {
            if (!stopped) start().catch(() => { /* ignore */ });
          }, 10_000);
        }
      }
    };

    start().catch(() => { /* ignore */ });

    return () => {
      stopped = true;
      if (streamObj) {
        (streamObj as unknown as { destroy: () => void }).destroy?.();
      }
    };
  }

  private parse(
    raw: DockerStatsData,
    projectId: string,
    containerId: string,
  ): ContainerStats | null {
    try {
      // CPU %
      const cpuDelta =
        raw.cpu_stats.cpu_usage.total_usage - raw.precpu_stats.cpu_usage.total_usage;
      const systemDelta =
        raw.cpu_stats.system_cpu_usage - raw.precpu_stats.system_cpu_usage;
      const numCpus = raw.cpu_stats.online_cpus || 1;
      const cpuPercent = systemDelta > 0 ? (cpuDelta / systemDelta) * numCpus * 100 : 0;

      // Memory
      const memUsed = raw.memory_stats.usage ?? 0;
      const memLimit = raw.memory_stats.limit ?? 0;
      const memPercent = memLimit > 0 ? (memUsed / memLimit) * 100 : 0;

      // Network I/O
      let netRx = 0;
      let netTx = 0;
      if (raw.networks) {
        for (const net of Object.values(raw.networks)) {
          netRx += net.rx_bytes;
          netTx += net.tx_bytes;
        }
      }

      // Block I/O
      let blkRead = 0;
      let blkWrite = 0;
      if (raw.blkio_stats?.io_service_bytes_recursive) {
        for (const item of raw.blkio_stats.io_service_bytes_recursive) {
          if (item.op === "Read") blkRead += item.value;
          if (item.op === "Write") blkWrite += item.value;
        }
      }

      return {
        projectId,
        containerId,
        cpuPercent: Math.round(cpuPercent * 100) / 100,
        memoryUsedBytes: memUsed,
        memoryLimitBytes: memLimit,
        memoryPercent: Math.round(memPercent * 100) / 100,
        networkRxBytes: netRx,
        networkTxBytes: netTx,
        blockReadBytes: blkRead,
        blockWriteBytes: blkWrite,
        pids: raw.pids_stats?.current ?? 0,
        recordedAt: new Date(),
      };
    } catch {
      return null;
    }
  }
}
