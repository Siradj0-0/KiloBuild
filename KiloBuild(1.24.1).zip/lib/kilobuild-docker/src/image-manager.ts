import Dockerode from "dockerode";
import { createReadStream } from "node:fs";
import { join } from "node:path";
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import type { BuildResult } from "@workspace/kilobuild-types";

export interface BuildImageOptions {
  buildId?: string;
  projectId: string;
  projectSlug: string;
  contextPath: string;
  dockerfile?: string;
  buildArgs?: Record<string, string>;
  labels?: Record<string, string>;
  onLog?: (line: string) => void;
}

export class ImageManager {
  constructor(private docker: Dockerode) {}

  imageName(projectSlug: string): string {
    return `kilobuild/${projectSlug}:latest`;
  }

  /** Build a Docker image from a project directory. */
  async build(opts: BuildImageOptions): Promise<BuildResult> {
    const { projectId, projectSlug, contextPath, dockerfile, buildArgs, labels, onLog } = opts;
    const buildId = opts.buildId ?? randomUUID();
    const imageName = this.imageName(projectSlug);
    const startedAt = new Date();
    const logs: string[] = [];

    const logLine = (line: string) => {
      logs.push(line);
      onLog?.(line);
    };

    try {
      // Pack the context as a tar stream (Docker API requires a tar archive)
      const tarStream = await this.packContext(contextPath);

      const stream = await this.docker.buildImage(tarStream, {
        t: imageName,
        dockerfile: dockerfile ?? "Dockerfile",
        buildargs: buildArgs ?? {},
        labels: {
          "kilobuild.managed": "true",
          "kilobuild.project.id": projectId,
          "kilobuild.project.slug": projectSlug,
          ...(labels ?? {}),
        },
      });

      let imageId: string | null = null;

      await new Promise<void>((resolve, reject) => {
        this.docker.modem.followProgress(
          stream,
          (err: Error | null, output: Array<{ stream?: string; aux?: { ID: string }; error?: string }>) => {
            if (err) {
              reject(err);
              return;
            }
            const buildError = output.find((item) => item.error);
            if (buildError?.error) {
              reject(new Error(buildError.error));
              return;
            }
            // Extract image ID from the final aux message
            for (const item of output) {
              if (item.aux?.ID) imageId = item.aux.ID;
            }
            resolve();
          },
          (event: { stream?: string; error?: string }) => {
            if (event.stream) logLine(event.stream.trimEnd());
            if (event.error) logLine(`ERROR: ${event.error}`);
          },
        );
      });

      const finishedAt = new Date();
      return {
        buildId,
        projectId,
        status: "success",
        imageId,
        imageName,
        startedAt,
        finishedAt,
        durationMs: finishedAt.getTime() - startedAt.getTime(),
        error: null,
        logs,
      };
    } catch (err) {
      const finishedAt = new Date();
      return {
        buildId,
        projectId,
        status: "failed",
        imageId: null,
        imageName,
        startedAt,
        finishedAt,
        durationMs: finishedAt.getTime() - startedAt.getTime(),
        error: String(err),
        logs,
      };
    }
  }

  /** Remove an image by name or ID. */
  async remove(nameOrId: string, force = false): Promise<void> {
    const image = this.docker.getImage(nameOrId);
    await image.remove({ force });
  }

  /** Check if an image exists. */
  async exists(nameOrId: string): Promise<boolean> {
    try {
      await this.docker.getImage(nameOrId).inspect();
      return true;
    } catch {
      return false;
    }
  }

  /** List all KiloBuild-managed images. */
  async listManaged(): Promise<Array<{ id: string; name: string; size: number; createdAt: Date }>> {
    const images = await this.docker.listImages({
      filters: JSON.stringify({ label: ["kilobuild.managed=true"] }),
    });
    return images.map((img) => ({
      id: img.Id,
      name: img.RepoTags?.[0] ?? "untagged",
      size: img.Size,
      createdAt: new Date(img.Created * 1000),
    }));
  }

  /** Pull a base image (used during template generation). */
  async pull(
    imageName: string,
    onProgress?: (status: string) => void,
  ): Promise<void> {
    const stream = await this.docker.pull(imageName);
    await new Promise<void>((resolve, reject) => {
      this.docker.modem.followProgress(
        stream,
        (err: Error | null) => (err ? reject(err) : resolve()),
        (event: { status?: string }) => onProgress?.(event.status ?? ""),
      );
    });
  }

  /** Pack a directory as a tar stream for Docker build context. */
  private async packContext(contextPath: string): Promise<NodeJS.ReadableStream> {
    // Dockerode accepts a tar stream. Use the host tar utility so KiloBuild
    // does not need a native or third-party archive dependency.
    const process = spawn(
      "tar",
      [
        "-cf",
        "-",
        "--exclude=./node_modules",
        "--exclude=./.git",
        "--exclude=./dist",
        "--exclude=./.cache",
        ".",
      ],
      { cwd: contextPath, stdio: ["ignore", "pipe", "pipe"] },
    );
    process.stderr.resume();
    return process.stdout;
  }
}
