import type {
  RecoveryState,
  RestartRecord,
  ProjectConfig,
} from "@workspace/kilobuild-types";
import { eventBus } from "@workspace/kilobuild-events";
import { getConfigManager } from "@workspace/kilobuild-config";
import { db, recoveryStatesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

// ── Backoff calculator ─────────────────────────

export function calculateBackoffMs(
  attempt: number,
  baseMs: number,
  multiplier: number,
  maxMs = 300_000,
): number {
  const delay = Math.min(baseMs * Math.pow(multiplier, attempt - 1), maxMs);
  // Add jitter ±20% to avoid thundering herd
  const jitter = delay * 0.2 * (Math.random() * 2 - 1);
  return Math.round(delay + jitter);
}

// ── RecoveryManager ───────────────────────────

type RestartCallback = (projectId: string) => Promise<void>;

export class RecoveryManager {
  private states = new Map<string, RecoveryState>();
  private timers = new Map<string, NodeJS.Timeout>();

  constructor(
    private readonly restartFn: RestartCallback,
  ) {}

  /** Register a project with the recovery manager. */
  register(projectId: string): void {
    if (!this.states.has(projectId)) {
      const state: RecoveryState = {
        projectId,
        restartCount: 0,
        lastRestartAt: null,
        nextAllowedRestartAt: null,
        exhausted: false,
        windowStartAt: null,
      };
      this.states.set(projectId, state);
      void this.persistState(state);
    }
  }

  /** Unregister and cancel any pending recovery for a project. */
  unregister(projectId: string): void {
    this.cancelPending(projectId);
    this.states.delete(projectId);
    void db.delete(recoveryStatesTable).where(eq(recoveryStatesTable.projectId, projectId));
  }

  /**
   * Called when a container exits unexpectedly.
   * Evaluates the restart policy and schedules a restart if applicable.
   */
  async onContainerDied(
    projectId: string,
    exitCode: number | null,
    reason: string,
  ): Promise<void> {
    await this.hydrate(projectId);
    const state = this.states.get(projectId);
    if (!state) return;

    const config = getConfigManager().getProject(projectId);

    // Honour Docker's own restart policy – if it's "always" or "unless-stopped",
    // Docker handles restarts natively. KiloBuild recovery handles "no" + "on-failure".
    if (
      config.restartPolicy === "always" ||
      config.restartPolicy === "unless-stopped"
    ) {
      return; // Docker manages this
    }

    if (config.restartPolicy === "no") {
      eventBus.emit("container:crashed", projectId, { exitCode, reason });
      return;
    }

    // restartPolicy === "on-failure"
    if (exitCode === 0) return; // Clean exit – don't restart

    if (state.exhausted) {
      return; // Already gave up
    }

    // Check restart window
    const now = Date.now();
    if (state.windowStartAt === null) {
      state.windowStartAt = new Date(now);
      await this.persistState(state);
    } else if (now - state.windowStartAt.valueOf() > config.restartWindowSeconds * 1000) {
      // Window expired – reset counters
      state.restartCount = 0;
      state.windowStartAt = new Date(now);
      state.exhausted = false;
      await this.persistState(state);
    }

    if (state.restartCount >= config.maxRestarts) {
      state.exhausted = true;
      await this.persistState(state);
      eventBus.emit("recovery:exhausted", projectId, {
        restartCount: state.restartCount,
        maxRestarts: config.maxRestarts,
        exitCode,
        reason,
      });
      return;
    }

    const attempt = state.restartCount + 1;
    const delayMs = calculateBackoffMs(
      attempt,
      config.cooldownSeconds * 1000,
      config.backoffMultiplier,
    );

    state.restartCount++;
    state.lastRestartAt = new Date();
    state.nextAllowedRestartAt = new Date(now + delayMs);
    await this.persistState(state);

    eventBus.emit("recovery:triggered", projectId, {
      attempt,
      delayMs,
      exitCode,
      reason,
    });

    this.scheduleRestart(projectId, delayMs);
  }

  /** Manually reset a project's recovery state (e.g. after a clean start). */
  reset(projectId: string): void {
    this.cancelPending(projectId);
    const state: RecoveryState = {
      projectId,
      restartCount: 0,
      lastRestartAt: null,
      nextAllowedRestartAt: null,
      exhausted: false,
      windowStartAt: null,
    };
    this.states.set(projectId, state);
    void this.persistState(state);
  }

  getState(projectId: string): RecoveryState | null {
    return this.states.get(projectId) ?? null;
  }

  getHistory(projectId: string): RestartRecord[] {
    // The full history is persisted in the DB; this returns in-memory snapshot
    const state = this.states.get(projectId);
    if (!state || !state.lastRestartAt) return [];
    return [
      {
        projectId,
        timestamp: state.lastRestartAt,
        reason: "container_died",
        exitCode: null,
        attempt: state.restartCount,
      },
    ];
  }

  private scheduleRestart(projectId: string, delayMs: number): void {
    this.cancelPending(projectId);
    const timer = setTimeout(async () => {
      this.timers.delete(projectId);
      try {
        await this.restartFn(projectId);
      } catch (err) {
        // Restart failed – mark as exhausted
        const state = this.states.get(projectId);
        if (state) {
          state.exhausted = true;
          void this.persistState(state);
        }
        eventBus.emit("recovery:exhausted", projectId, {
          reason: String(err),
          restartCount: state?.restartCount ?? 0,
        });
      }
    }, delayMs);
    timer.unref();
    this.timers.set(projectId, timer);
  }

  private cancelPending(projectId: string): void {
    const timer = this.timers.get(projectId);
    if (timer) {
      clearTimeout(timer);
      this.timers.delete(projectId);
    }
  }

  private async hydrate(projectId: string): Promise<void> {
    if (this.states.has(projectId)) return;

    const [row] = await db
      .select()
      .from(recoveryStatesTable)
      .where(eq(recoveryStatesTable.projectId, projectId))
      .limit(1);

    if (!row) {
      this.register(projectId);
      return;
    }

    this.states.set(projectId, {
      projectId,
      restartCount: row.restartCount,
      lastRestartAt: row.lastRestartAt,
      nextAllowedRestartAt: row.nextAllowedRestartAt,
      exhausted: row.exhausted,
      windowStartAt: row.windowStartAt,
    });
  }

  private async persistState(state: RecoveryState): Promise<void> {
    await db
      .insert(recoveryStatesTable)
      .values({
        projectId: state.projectId,
        restartCount: state.restartCount,
        lastRestartAt: state.lastRestartAt,
        nextAllowedRestartAt: state.nextAllowedRestartAt,
        exhausted: state.exhausted,
        windowStartAt: state.windowStartAt,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: recoveryStatesTable.projectId,
        set: {
          restartCount: state.restartCount,
          lastRestartAt: state.lastRestartAt,
          nextAllowedRestartAt: state.nextAllowedRestartAt,
          exhausted: state.exhausted,
          windowStartAt: state.windowStartAt,
          updatedAt: new Date(),
        },
      });
  }
}

export type { RecoveryState, RestartRecord, ProjectConfig };
