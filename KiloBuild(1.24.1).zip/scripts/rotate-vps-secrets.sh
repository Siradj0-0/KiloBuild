#!/usr/bin/env bash
#
# Rotate both KiloBuild bearer credentials on a VPS.
#
# Rotation intentionally invalidates existing CLI and KiloBuilder credentials.
# Run only when you are ready to update those clients:
#   bash scripts/rotate-vps-secrets.sh --yes
set -Eeuo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run this script as root." >&2
  exit 1
fi

if [[ "${1:-}" != "--yes" ]]; then
  echo "This rotates the API and internal tokens and invalidates old clients."
  echo "Re-run with --yes when you are ready."
  exit 2
fi

DATA_DIR="${KILOBUILD_DATA_DIR:-/opt/kilobuild/.kilobuild}"
CONFIG_PATH="${DATA_DIR}/config.json"
SERVICE_NAME="kilobuild.service"

if [[ ! -f "${CONFIG_PATH}" ]]; then
  echo "Config file not found: ${CONFIG_PATH}" >&2
  exit 1
fi

BACKUP="${CONFIG_PATH}.before-secret-rotation.$(date +%Y%m%d%H%M%S)"
cp -a "${CONFIG_PATH}" "${BACKUP}"

node --input-type=module - "${CONFIG_PATH}" "${CONFIG_PATH}.tmp" <<'NODE'
import { randomBytes } from "node:crypto";
import { readFile, writeFile, rename, chmod } from "node:fs/promises";

const [configPath, tempPath] = process.argv.slice(2);
const config = JSON.parse(await readFile(configPath, "utf8"));
config.global ??= {};
config.global.apiSecret = randomBytes(32).toString("hex");
config.global.internalToken = randomBytes(32).toString("hex");
await writeFile(tempPath, `${JSON.stringify(config, null, 2)}\n`, { mode: 0o600 });
await chmod(tempPath, 0o600);
await rename(tempPath, configPath);
NODE

chmod 0600 "${CONFIG_PATH}"
if systemctl list-unit-files "${SERVICE_NAME}" --no-legend 2>/dev/null | grep -q "${SERVICE_NAME}"; then
  systemctl restart "${SERVICE_NAME}"
  echo "Credentials rotated and ${SERVICE_NAME} restarted."
else
  echo "Credentials rotated. Restart the KiloBuild daemon before using it."
fi
echo "Backup saved at: ${BACKUP}"
echo "Read the new values locally from ${CONFIG_PATH}; they are not printed by this script."