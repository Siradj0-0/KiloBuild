#!/usr/bin/env bash
#
# Install or update KiloBuild on an Ubuntu VPS.
#
# Run as root from the KiloBuild checkout:
#   cd /opt/kilobuild
#   bash scripts/install-vps.sh
#
# This script deliberately does not overwrite .kilobuild/config.json. Existing
# projects, tokens, and settings are preserved.
set -Eeuo pipefail

REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SERVICE_NAME="kilobuild.service"
SERVICE_PATH="/etc/systemd/system/${SERVICE_NAME}"
DATA_DIR="${KILOBUILD_DATA_DIR:-${REPO}/.kilobuild}"
API_PORT="${KILOBUILD_API_PORT:-}"
API_HOST="${KILOBUILD_API_HOST:-}"
PUBLIC_BASE_URL="${KILOBUILD_PUBLIC_BASE_URL:-}"
PUBLIC_STATUS_PORT="${KILOBUILD_PUBLIC_STATUS_PORT:-}"
PUBLIC_STATUS_HOST="${KILOBUILD_PUBLIC_STATUS_HOST:-}"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run this installer as root." >&2
  exit 1
fi

if [[ ! -f "${REPO}/package.json" || ! -f "${REPO}/pnpm-workspace.yaml" ]]; then
  echo "This does not look like a KiloBuild checkout: ${REPO}" >&2
  exit 1
fi

require_command() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "Missing required command: $1" >&2
    exit 1
  fi
}

require_command node
require_command pnpm
require_command docker
require_command systemctl
require_command curl
NODE_BIN="$(command -v node)"

if [[ -z "${API_PORT}" ]]; then
  API_PORT="3001"
  if [[ -f "${DATA_DIR}/config.json" ]]; then
    API_PORT="$(node --input-type=module - "${DATA_DIR}/config.json" <<'NODE'
import { readFile } from "node:fs/promises";
const path = process.argv[2];
try {
  const config = JSON.parse(await readFile(path, "utf8"));
  const port = config?.global?.apiPort;
  process.stdout.write(Number.isInteger(port) ? String(port) : "3001");
} catch {
  process.stdout.write("3001");
}
NODE
)"
  fi
fi

if [[ -z "${API_HOST}" ]]; then
  API_HOST="127.0.0.1"
  if [[ -f "${DATA_DIR}/config.json" ]]; then
    API_HOST="$(node --input-type=module - "${DATA_DIR}/config.json" <<'NODE'
import { readFile } from "node:fs/promises";
const path = process.argv[2];
try {
  const config = JSON.parse(await readFile(path, "utf8"));
  process.stdout.write(typeof config?.global?.apiHost === "string" ? config.global.apiHost : "127.0.0.1");
} catch {
  process.stdout.write("127.0.0.1");
}
NODE
)"
  fi
fi

if [[ -z "${PUBLIC_STATUS_PORT}" && -f "${DATA_DIR}/config.json" ]]; then
  PUBLIC_STATUS_PORT="$(node --input-type=module - "${DATA_DIR}/config.json" <<'NODE'
import { readFile } from "node:fs/promises";
const path = process.argv[2];
try {
  const config = JSON.parse(await readFile(path, "utf8"));
  const port = config?.global?.publicStatusPort;
  process.stdout.write(Number.isInteger(port) ? String(port) : "");
} catch {
  process.stdout.write("");
}
NODE
)"
fi

if [[ -z "${PUBLIC_STATUS_HOST}" && -f "${DATA_DIR}/config.json" ]]; then
  PUBLIC_STATUS_HOST="$(node --input-type=module - "${DATA_DIR}/config.json" <<'NODE'
import { readFile } from "node:fs/promises";
const path = process.argv[2];
try {
  const config = JSON.parse(await readFile(path, "utf8"));
  process.stdout.write(typeof config?.global?.publicStatusHost === "string" ? config.global.publicStatusHost : "127.0.0.1");
} catch {
  process.stdout.write("127.0.0.1");
}
NODE
)"
fi

if [[ -z "${PUBLIC_STATUS_HOST}" ]]; then
  PUBLIC_STATUS_HOST="127.0.0.1"
fi

if ! docker info >/dev/null 2>&1; then
  echo "Docker is installed but the daemon is not reachable." >&2
  exit 1
fi

echo "Installing workspace dependencies..."
cd "${REPO}"
pnpm install --frozen-lockfile

echo "Building KiloBuild libraries, CLI, and API..."
pnpm run typecheck:libs
pnpm --filter @workspace/kilobuild-cli run build
pnpm --filter @workspace/kilobuild-status run build
pnpm --filter @workspace/api-server run build

cat > /usr/local/bin/kilo <<EOF
#!/usr/bin/env bash
exec "${NODE_BIN}" "${REPO}/lib/kilobuild-cli/dist/index.mjs" "\$@"
EOF
chmod 0755 /usr/local/bin/kilo
mkdir -p "${DATA_DIR}" "${DATA_DIR}/projects" "${DATA_DIR}/logs" "${DATA_DIR}/backups" "${DATA_DIR}/plugins"
chmod 0700 "${DATA_DIR}"
if [[ -f "${DATA_DIR}/config.json" ]]; then
  chmod 0600 "${DATA_DIR}/config.json"
fi

cat > "${SERVICE_PATH}" <<EOF
[Unit]
Description=KiloBuild management daemon
Documentation=file://${REPO}/KILOBUILD_SETUP.md
Wants=network-online.target
After=network-online.target docker.service
Requires=docker.service

[Service]
Type=simple
WorkingDirectory=${REPO}
ExecStart=${NODE_BIN} ${REPO}/artifacts/api-server/dist/index.mjs
Environment=NODE_ENV=production
Environment=KILOBUILD_DATA_DIR=${DATA_DIR}
Environment=KILOBUILD_STATUS_DIR=${REPO}/artifacts/kilobuild-status/dist/public
Environment=KILOBUILD_API_HOST=${API_HOST}
Environment=KILOBUILD_PUBLIC_BASE_URL=${PUBLIC_BASE_URL}
Environment=KILOBUILD_PUBLIC_STATUS_HOST=${PUBLIC_STATUS_HOST}
Environment=KILOBUILD_PUBLIC_STATUS_PORT=${PUBLIC_STATUS_PORT}
Environment=PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin
Restart=on-failure
RestartSec=5
TimeoutStopSec=30
KillSignal=SIGTERM
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

chmod 0644 "${SERVICE_PATH}"
systemctl daemon-reload
systemctl enable "${SERVICE_NAME}" >/dev/null
systemctl restart "${SERVICE_NAME}"

echo "Waiting for the daemon health check..."
for _ in {1..30}; do
  if curl --fail --silent "http://127.0.0.1:${API_PORT}/api/healthz" >/dev/null; then
    echo "KiloBuild is running on 127.0.0.1:${API_PORT}."
    echo "CLI installed at /usr/local/bin/kilo."
    echo
    echo "Useful checks:"
    echo "  systemctl status ${SERVICE_NAME} --no-pager"
    echo "  journalctl -u ${SERVICE_NAME} -n 100 --no-pager"
    echo "  kilo list"
    exit 0
  fi
  sleep 1
done

echo "KiloBuild did not become healthy. Recent service logs:" >&2
journalctl -u "${SERVICE_NAME}" -n 100 --no-pager >&2 || true
exit 1